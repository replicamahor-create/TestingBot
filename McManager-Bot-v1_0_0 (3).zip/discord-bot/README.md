# 🦕 McManager — Pterodactyl Discord Bot
> **Made by DipuXPro** | 150+ Commands | Node.js + Discord.js v14

---

## ⚡ Quick Setup

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure .env
Open `.env` and fill in:
```env
DISCORD_BOT_TOKEN=your_token_here
DISCORD_CLIENT_ID=your_client_id_here
DISCORD_GUILD_ID=your_guild_id_here   # optional, for faster deploy
```

### 3. Deploy Slash Commands
```bash
node src/deploy.js
```

### 4. Start the Bot
```bash
node src/index.js
```

---

## 🔑 Getting Your Discord Bot Token

1. Go to https://discord.com/developers/applications
2. Click **New Application** → name it `McManager`
3. Go to **Bot** section → click **Reset Token** → copy token
4. Go to **OAuth2** → copy the **Client ID**
5. Under **OAuth2 → URL Generator**: select `bot` + `applications.commands`
6. Permissions: `Send Messages`, `Embed Links`, `Attach Files`
7. Copy the generated URL and invite the bot to your server

---

## 🔑 Getting Your Pterodactyl API Key

1. Login to your Pterodactyl panel
2. Click your name → **Account**
3. Go to **API Credentials** tab
4. Create a new key → copy it
5. Use `/mcmanager login` in Discord to connect

---

## 📋 All Commands

See `COMMANDS.md` for the full list of 150+ commands.

All commands use `/mcmanager [subcommand]`

---

## 🌐 GitHub / Hosting

Works anywhere Node.js runs:
- Local machine
- GitHub Codespaces
- VPS / Dedicated server
- Railway / Render / Heroku
- Replit

Just make sure the `.env` file has your tokens before starting.

---

> 🦕 **McManager v1.0.0** — Built with ❤️ by **DipuXPro**
