# 🦕 McManager Bot — Full Command List
> **Made by DipuXPro** | Pterodactyl Panel Discord Manager
> All commands start with `/mcmanager`

---

## ⚙️ SETUP & LOGIN
| Command | Description |
|---|---|
| `/mcmanager login` | 🔑 Opens login menu — enter Panel URL + API Key (per user, private) |
| `/mcmanager logout` | 🚪 Logout and clear your saved credentials |
| `/mcmanager profile` | 👤 View your saved panel URL and masked API key |
| `/mcmanager help` | 📖 Full help menu with all commands list |
| `/mcmanager ping` | 📶 Check bot latency and panel connection status |
| `/mcmanager info` | ℹ️ Bot info, version, uptime, total users |

---

## 🖥️ SERVER LIST & SELECTION
| Command | Description |
|---|---|
| `/mcmanager servers` | 📋 List all your servers with status, CPU, RAM badges |
| `/mcmanager select [server]` | 🎯 Set a default server for faster commands |
| `/mcmanager selected` | 🔎 Show currently selected server |
| `/mcmanager deselect` | ❌ Clear selected server |

---

## ⚡ SERVER POWER CONTROL
| Command | Description |
|---|---|
| `/mcmanager start [server]` | ▶️ Start a server |
| `/mcmanager stop [server]` | ⏹️ Gracefully stop a server |
| `/mcmanager restart [server]` | 🔄 Restart a server |
| `/mcmanager kill [server]` | 💀 Force kill a server (emergency stop) |
| `/mcmanager reinstall [server]` | 🔁 Reinstall server (WARNING: wipes data) |
| `/mcmanager suspend [server]` | 🔒 Suspend server (admin only) |
| `/mcmanager unsuspend [server]` | 🔓 Unsuspend server (admin only) |

---

## 📊 SERVER STATUS & STATS
| Command | Description |
|---|---|
| `/mcmanager status [server]` | 🟢 Full server status embed (CPU, RAM, disk, uptime) |
| `/mcmanager stats [server]` | 📈 Real-time resource usage with progress bars |
| `/mcmanager resources [server]` | 💎 Server resource limits (max CPU, RAM, disk) |
| `/mcmanager uptime [server]` | ⏱️ Server uptime display |
| `/mcmanager players [server]` | 👥 Player count (if MCST configured) |
| `/mcmanager ip [server]` | 🌍 Server IP and port info |

---

## 💻 CONSOLE
| Command | Description |
|---|---|
| `/mcmanager console [server]` | 💻 View last 50 lines of server console |
| `/mcmanager console-live [server]` | 🔴 Live console watcher (auto-updates every 5s) |
| `/mcmanager cmd [server] [command]` | ➤ Send a command to the server console |
| `/mcmanager say [server] [message]` | 💬 Broadcast a message in-game via console |
| `/mcmanager logs [server]` | 📜 Get recent console logs as a file |
| `/mcmanager logs-tail [server] [lines]` | 📃 Get last N lines of logs (max 200) |
| `/mcmanager crash-detect [server]` | 🔍 Detect crash keywords in recent logs |

---

## 📁 FILE MANAGER
| Command | Description |
|---|---|
| `/mcmanager files [server] [path]` | 📂 List files and folders at given path |
| `/mcmanager read [server] [file]` | 📄 Read a file's content (shown in embed) |
| `/mcmanager write [server] [file]` | ✏️ Edit/write content to a file (opens modal) |
| `/mcmanager upload [server] [path]` | 📤 Upload a file to the server (attach in Discord) |
| `/mcmanager download [server] [file]` | 📥 Download a file from server to Discord |
| `/mcmanager delete [server] [file]` | 🗑️ Delete a file or empty folder |
| `/mcmanager rename [server] [file] [new]` | 🏷️ Rename a file or folder |
| `/mcmanager mkdir [server] [path]` | 📁 Create a new directory |
| `/mcmanager copy [server] [src] [dest]` | 📋 Copy a file to another location |
| `/mcmanager move [server] [src] [dest]` | 🚚 Move a file to another location |
| `/mcmanager search-file [server] [name]` | 🔎 Search for a file by name |
| `/mcmanager compress [server] [path]` | 🗜️ Compress folder/file into .tar.gz |
| `/mcmanager decompress [server] [file]` | 📦 Decompress a .tar.gz archive |
| `/mcmanager chmod [server] [file] [mode]` | 🔐 Change file permissions |

---

## 💾 BACKUPS
| Command | Description |
|---|---|
| `/mcmanager backups [server]` | 💾 List all backups with size and date |
| `/mcmanager backup-create [server]` | ➕ Create a new backup |
| `/mcmanager backup-create-named [server] [name]` | ➕ Create named backup |
| `/mcmanager backup-delete [server] [id]` | 🗑️ Delete a backup |
| `/mcmanager backup-restore [server] [id]` | 🔁 Restore server from a backup |
| `/mcmanager backup-download [server] [id]` | 📥 Get download link for a backup |
| `/mcmanager backup-lock [server] [id]` | 🔒 Lock a backup (protect from deletion) |
| `/mcmanager backup-unlock [server] [id]` | 🔓 Unlock a backup |
| `/mcmanager backup-info [server] [id]` | ℹ️ Detailed info about a backup |

---

## 🗄️ DATABASES
| Command | Description |
|---|---|
| `/mcmanager databases [server]` | 🗄️ List all databases |
| `/mcmanager db-create [server] [name]` | ➕ Create a new database |
| `/mcmanager db-delete [server] [id]` | 🗑️ Delete a database |
| `/mcmanager db-password [server] [id]` | 🔐 Rotate database password |
| `/mcmanager db-info [server] [id]` | ℹ️ Database connection info (host, port, name, user) |

---

## 📅 SCHEDULES
| Command | Description |
|---|---|
| `/mcmanager schedules [server]` | 📅 List all schedules |
| `/mcmanager schedule-info [server] [id]` | ℹ️ View schedule details and tasks |
| `/mcmanager schedule-create [server]` | ➕ Create a new schedule (opens modal) |
| `/mcmanager schedule-delete [server] [id]` | 🗑️ Delete a schedule |
| `/mcmanager schedule-toggle [server] [id]` | 🔄 Enable/disable a schedule |
| `/mcmanager schedule-run [server] [id]` | ▶️ Trigger a schedule immediately |

---

## 👥 SUBUSERS
| Command | Description |
|---|---|
| `/mcmanager subusers [server]` | 👥 List all subusers on a server |
| `/mcmanager subuser-add [server] [email]` | ➕ Add a subuser to server |
| `/mcmanager subuser-remove [server] [uuid]` | ❌ Remove a subuser |
| `/mcmanager subuser-perms [server] [uuid]` | 🔑 View subuser permissions |
| `/mcmanager subuser-update [server] [uuid]` | ✏️ Update subuser permissions |

---

## 📡 NETWORK / ALLOCATIONS
| Command | Description |
|---|---|
| `/mcmanager allocations [server]` | 📡 List all network allocations |
| `/mcmanager allocation-add [server]` | ➕ Add a new allocation |
| `/mcmanager allocation-remove [server] [id]` | ❌ Remove an allocation |
| `/mcmanager allocation-primary [server] [id]` | ⭐ Set allocation as primary |
| `/mcmanager allocation-note [server] [id] [note]` | 📝 Set a note on an allocation |

---

## 👑 ADMIN — APPLICATION API
| Command | Description |
|---|---|
| `/mcmanager admin-servers` | 🖥️ List ALL servers on panel (admin) |
| `/mcmanager admin-server-info [id]` | ℹ️ Detailed info about any server |
| `/mcmanager admin-server-create` | ➕ Create a new server (opens modal) |
| `/mcmanager admin-server-delete [id]` | 🗑️ Delete a server permanently |
| `/mcmanager admin-server-suspend [id]` | 🔒 Suspend any server |
| `/mcmanager admin-server-unsuspend [id]` | 🔓 Unsuspend any server |
| `/mcmanager admin-server-rebuild [id]` | 🔧 Rebuild server container |
| `/mcmanager admin-server-reinstall [id]` | 🔁 Reinstall any server |
| `/mcmanager admin-server-update [id]` | ✏️ Update server build config |
| `/mcmanager admin-users` | 👥 List all panel users |
| `/mcmanager admin-user-info [id]` | 👤 Detailed user info |
| `/mcmanager admin-user-create` | ➕ Create a new panel user |
| `/mcmanager admin-user-delete [id]` | 🗑️ Delete a panel user |
| `/mcmanager admin-user-update [id]` | ✏️ Update user details |
| `/mcmanager admin-nodes` | 🌐 List all nodes |
| `/mcmanager admin-node-info [id]` | ℹ️ Node details (memory, disk, CPU) |
| `/mcmanager admin-node-config [id]` | ⚙️ Get node Wings config |
| `/mcmanager admin-node-allocations [id]` | 📡 List allocations on a node |
| `/mcmanager admin-locations` | 📍 List all locations |
| `/mcmanager admin-location-create [name]` | ➕ Create a new location |
| `/mcmanager admin-location-delete [id]` | 🗑️ Delete a location |
| `/mcmanager admin-nests` | 🥚 List all nests |
| `/mcmanager admin-nest-info [id]` | ℹ️ Nest details |
| `/mcmanager admin-eggs [nest-id]` | 🦕 List all eggs in a nest |
| `/mcmanager admin-egg-info [nest] [egg]` | ℹ️ Egg details and variables |

---

## 🔥 EXTENDED / BONUS FEATURES
| Command | Description |
|---|---|
| `/mcmanager monitor [server]` | 📊 Start resource monitoring (alerts on high CPU/RAM) |
| `/mcmanager monitor-stop [server]` | ⏹️ Stop monitoring |
| `/mcmanager alert-set [server] [cpu] [ram]` | 🔔 Set alert thresholds |
| `/mcmanager alert-clear [server]` | 🔕 Clear alert thresholds |
| `/mcmanager server-compare [s1] [s2]` | ⚖️ Compare two servers side by side |
| `/mcmanager bulk-start` | ▶️ Start ALL your servers at once |
| `/mcmanager bulk-stop` | ⏹️ Stop ALL your servers at once |
| `/mcmanager bulk-restart` | 🔄 Restart ALL your servers at once |
| `/mcmanager quickcmd [server]` | ⚡ Quick common command menu (op, whitelist, etc.) |
| `/mcmanager whitelist-add [server] [name]` | ➕ Whitelist a player via console |
| `/mcmanager whitelist-remove [server] [name]` | ❌ Remove player from whitelist via console |
| `/mcmanager op [server] [name]` | 👑 OP a player via console |
| `/mcmanager deop [server] [name]` | ❌ De-OP a player via console |
| `/mcmanager ban [server] [name]` | 🚫 Ban a player via console |
| `/mcmanager kick [server] [name]` | 👟 Kick a player via console |
| `/mcmanager pardon [server] [name]` | ✅ Pardon a banned player via console |
| `/mcmanager time-set [server] [day/night]` | 🌙 Set game time via console |
| `/mcmanager weather [server] [clear/rain]` | ⛅ Set weather via console |
| `/mcmanager gamemode [server] [player] [mode]` | 🎮 Set gamemode via console |
| `/mcmanager give [server] [player] [item]` | 🎁 Give item to player via console |
| `/mcmanager tp [server] [player1] [player2]` | 🌀 Teleport player via console |
| `/mcmanager save [server]` | 💾 Force world save via console |
| `/mcmanager panel-status` | 🌐 Check if your panel is online/reachable |
| `/mcmanager changelog` | 📋 View bot changelog and updates |
| `/mcmanager invite` | 🔗 Get bot invite link |
| `/mcmanager support` | 💬 Get support server link |

---

## 📌 NOTES
- **All data is per-user** — your API key and panel URL are stored separately for each Discord user
- **Login once** with `/mcmanager login` — credentials are saved securely
- **No server selected?** Commands will show a server picker dropdown automatically
- **Admin commands** require Application API key with admin permissions
- **File editing** uses Discord modals — up to 4000 characters per edit
- **File uploads** — attach the file directly in the same message as the command

---

> 🦕 **McManager v1.0.0** — Built with ❤️ by **DipuXPro**
> Pterodactyl Panel Discord Manager | Node.js + Discord.js v14
