require('dotenv').config();
const { REST, Routes } = require('discord.js');
const mcmanager = require('./commands/mcmanager');

const token = process.env.DISCORD_BOT_TOKEN;
const clientId = process.env.DISCORD_CLIENT_ID;
const guildId = process.env.DISCORD_GUILD_ID?.trim() || null;

if (!token || !clientId) {
  console.error('❌ Missing DISCORD_BOT_TOKEN or DISCORD_CLIENT_ID in .env');
  process.exit(1);
}

const commands = [mcmanager.data.toJSON()];
const rest = new REST().setToken(token);

(async () => {
  try {
    console.log('');
    console.log('╔══════════════════════════════════════════╗');
    console.log('║    McManager — Command Deployer          ║');
    console.log('║           by DipuXPro                   ║');
    console.log('╚══════════════════════════════════════════╝');
    console.log('');
    console.log(`🔄 Deploying ${commands[0].options.reduce((s, g) => s + (g.options?.length || 0), 0)} slash commands...`);

    let data;
    if (guildId) {
      data = await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands });
      console.log(`✅ Deployed ${data.length} command(s) to guild ${guildId} (instant)`);
    } else {
      data = await rest.put(Routes.applicationCommands(clientId), { body: commands });
      console.log(`✅ Deployed ${data.length} command(s) globally (up to 1 hour to appear)`);
    }

    console.log('');
    console.log('🦕 Done! McManager commands are live.');
    console.log('🚀 Now run: node src/index.js');
    console.log('');
  } catch (err) {
    console.error('❌ Deploy failed:', err?.message || err);
  }
})();
