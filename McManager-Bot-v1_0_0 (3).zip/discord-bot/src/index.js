require('dotenv').config();
const { Client, GatewayIntentBits, Collection, Events, ActivityType } = require('discord.js');
const mcmanager = require('./commands/mcmanager');

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages],
});

client.commands = new Collection();
client.commands.set(mcmanager.data.name, mcmanager);

// ── ROTATING STATUS MESSAGES ──────────────────────────────────
const STATUSES = [
  { text: '🦕 115 Commands Ready | /mcmanager', type: ActivityType.Watching },
  { text: '⚡ Pterodactyl Panel | DipuXPro', type: ActivityType.Watching },
  { text: '🖥️ Your Servers 24/7', type: ActivityType.Watching },
  { text: '🔥 /mcmanager — Try it!', type: ActivityType.Playing },
  { text: '💎 Made by DipuXPro', type: ActivityType.Watching },
  { text: '🛡️ Keeping Servers Alive', type: ActivityType.Watching },
  { text: '🚀 Pterodactyl Manager v4', type: ActivityType.Playing },
  { text: '📊 Server Stats in Real Time', type: ActivityType.Watching },
];

let statusIndex = 0;

function rotateStatus() {
  const s = STATUSES[statusIndex % STATUSES.length];
  client.user.setPresence({
    status: 'online',
    activities: [{ name: s.text, type: s.type }],
  });
  statusIndex++;
}

client.once(Events.ClientReady, (c) => {
  console.log('');
  console.log('╔══════════════════════════════════════════╗');
  console.log('║       McManager Bot — by DipuXPro        ║');
  console.log('╠══════════════════════════════════════════╣');
  console.log(`║  ✅ Online as : ${c.user.tag.padEnd(24)}║`);
  console.log(`║  🌐 Guilds    : ${String(c.guilds.cache.size).padEnd(24)}║`);
  console.log(`║  🦕 Commands  : 120 Slash Commands       ║`);
  console.log(`║  🔥 Author    : DipuXPro                 ║`);
  console.log(`║  📦 Version   : v1.0.0                   ║`);
  console.log('╚══════════════════════════════════════════╝');
  console.log('');

  rotateStatus();
  setInterval(rotateStatus, 15000);
});

client.on(Events.GuildCreate, (guild) => {
  console.log(`➕ Joined new guild: ${guild.name} (${guild.memberCount} members)`);
});

client.on(Events.GuildDelete, (guild) => {
  console.log(`➖ Left guild: ${guild.name}`);
});

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;
      await command.execute(interaction);
    } else if (interaction.isModalSubmit()) {
      await mcmanager.handleModal(interaction);
    } else if (interaction.isButton()) {
      await mcmanager.handleButton(interaction);
    } else if (interaction.isStringSelectMenu()) {
      await mcmanager.handleSelectMenu(interaction);
    }
  } catch (err) {
    console.error('❌ Interaction Error:', err?.message || err);
    try {
      const reply = { content: '❌ Something went wrong. Please try again.', ephemeral: true };
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(reply);
      } else {
        await interaction.reply(reply);
      }
    } catch {}
  }
});

client.on('error', (err) => console.error('⚠️ Client Error:', err?.message));
client.on('warn', (msg) => console.warn('⚠️ Warn:', msg));
client.on('shardError', (err) => console.error('⚠️ Shard Error:', err?.message));

process.on('unhandledRejection', (err) => console.error('⚠️ Unhandled Rejection:', err?.message || err));
process.on('uncaughtException', (err) => console.error('⚠️ Uncaught Exception:', err?.message || err));
process.on('SIGTERM', () => console.log('⚠️ SIGTERM received — bot staying alive...'));
process.on('SIGINT', () => {
  console.log('🔴 Shutting down McManager...');
  client.destroy();
  process.exit(0);
});

const token = process.env.DISCORD_BOT_TOKEN;
if (!token) {
  console.error('❌ ERROR: DISCORD_BOT_TOKEN not found in .env file!');
  console.error('📝 Add your token: echo "DISCORD_BOT_TOKEN=your_token" > .env');
  process.exit(1);
}

client.login(token);
