const {
  SlashCommandBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
} = require('discord.js');
const ptero = require('../handlers/ptero');
const store = require('../handlers/userStore');
const E = require('../utils/embeds');
const mcVersions = require('../utils/mcVersions');

// In-memory state for multi-step flows (create-server wizard)
const createServerState = new Map();

const data = new SlashCommandBuilder()
  .setName('mcmanager')
  .setDescription('🦕 McManager — Pterodactyl Panel Manager by DipuXPro')

  // ── SETUP GROUP ───────────────────────────────────────────
  .addSubcommandGroup(g => g.setName('setup').setDescription('⚙️ Bot setup and configuration')
    .addSubcommand(s => s.setName('login').setDescription('🔑 Login with your panel URL and API key'))
    .addSubcommand(s => s.setName('logout').setDescription('🚪 Logout and clear your credentials'))
    .addSubcommand(s => s.setName('profile').setDescription('👤 View your saved panel profile'))
    .addSubcommand(s => s.setName('ping').setDescription('📶 Check bot latency'))
    .addSubcommand(s => s.setName('info').setDescription('ℹ️ Bot info and stats'))
    .addSubcommand(s => s.setName('help').setDescription('📖 View all commands'))
    .addSubcommand(s => s.setName('panel-status').setDescription('🌐 Check if panel is online'))
    .addSubcommand(s => s.setName('invite').setDescription('🔗 Get bot invite link'))
    .addSubcommand(s => s.setName('changelog').setDescription('📋 View bot changelog'))
    .addSubcommand(s => s.setName('trust-add').setDescription('🤝 Trust a Discord user to use your panel').addUserOption(o => o.setName('user').setDescription('Discord user to trust').setRequired(true)))
    .addSubcommand(s => s.setName('trust-remove').setDescription('❌ Remove trust from a Discord user').addUserOption(o => o.setName('user').setDescription('User to untrust').setRequired(true)))
    .addSubcommand(s => s.setName('trust-list').setDescription('📋 View all users you have trusted'))
  )

  // ── SERVER GROUP ──────────────────────────────────────────
  .addSubcommandGroup(g => g.setName('server').setDescription('🖥️ Server management')
    .addSubcommand(s => s.setName('list').setDescription('📋 List all your servers'))
    .addSubcommand(s => s.setName('manage').setDescription('🎛️ Pick & switch your active server from a dropdown'))
    .addSubcommand(s => s.setName('deselect').setDescription('❌ Clear your active server selection'))
    .addSubcommand(s => s.setName('status').setDescription('📊 Live status & stats of your active server'))
    .addSubcommand(s => s.setName('start').setDescription('▶️ Start your active server'))
    .addSubcommand(s => s.setName('stop').setDescription('⏹️ Stop your active server'))
    .addSubcommand(s => s.setName('restart').setDescription('🔄 Restart your active server'))
    .addSubcommand(s => s.setName('kill').setDescription('💀 Force kill your active server'))
    .addSubcommand(s => s.setName('reinstall').setDescription('🔁 Reinstall active server (wipes data!)'))
    .addSubcommand(s => s.setName('suspend').setDescription('🔒 Suspend active server (admin)'))
    .addSubcommand(s => s.setName('unsuspend').setDescription('🔓 Unsuspend active server (admin)'))
    .addSubcommand(s => s.setName('bulk-start').setDescription('▶️ Start ALL your servers'))
    .addSubcommand(s => s.setName('bulk-stop').setDescription('⏹️ Stop ALL your servers'))
    .addSubcommand(s => s.setName('bulk-restart').setDescription('🔄 Restart ALL your servers'))
    .addSubcommand(s => s.setName('sftp').setDescription('🔌 SFTP connection details of active server'))
    .addSubcommand(s => s.setName('all-status').setDescription('📊 Show status of ALL your servers at once'))
    .addSubcommand(s => s.setName('limits').setDescription('⚖️ Resource limits (CPU/RAM/Disk) of active server'))
    .addSubcommand(s => s.setName('rename').setDescription('✏️ Rename active server').addStringOption(o => o.setName('name').setDescription('New server name').setRequired(true)))
    .addSubcommand(s => s.setName('variables').setDescription('🔧 View startup/egg variables of active server'))
    .addSubcommand(s => s.setName('variable-set').setDescription('✏️ Change a startup variable value').addStringOption(o => o.setName('key').setDescription('Variable key (env name)').setRequired(true)).addStringOption(o => o.setName('value').setDescription('New value').setRequired(true)))
    .addSubcommand(s => s.setName('info').setDescription('📋 Detailed info of active server (node, egg, allocation)'))
    .addSubcommand(s => s.setName('notes').setDescription('📝 Save/view notes for active server').addStringOption(o => o.setName('text').setDescription('Note text (leave empty to view)')))
    .addSubcommand(s => s.setName('startup').setDescription('🚀 View startup command of active server'))
    .addSubcommand(s => s.setName('resources').setDescription('📈 Live CPU / RAM / Disk / Network of active server'))
    .addSubcommand(s => s.setName('pin').setDescription('📌 Pin or unpin active server to your favourites'))
  )

  // ── CONSOLE GROUP ─────────────────────────────────────────
  .addSubcommandGroup(g => g.setName('console').setDescription('💻 Console management')
    .addSubcommand(s => s.setName('view').setDescription('💻 View console info of active server'))
    .addSubcommand(s => s.setName('cmd').setDescription('➤ Send a command to active server').addStringOption(o => o.setName('command').setDescription('Command to send').setRequired(true)))
    .addSubcommand(s => s.setName('say').setDescription('💬 Broadcast message in-game on active server').addStringOption(o => o.setName('message').setDescription('Message').setRequired(true)))
    .addSubcommand(s => s.setName('latest-log').setDescription('📜 Read logs/latest.log from active server'))
    .addSubcommand(s => s.setName('broadcast').setDescription('📢 Send a message to ALL servers at once').addStringOption(o => o.setName('message').setDescription('Message to broadcast').setRequired(true)))
    .addSubcommand(s => s.setName('send-all').setDescription('⚡ Send same command to ALL servers at once').addStringOption(o => o.setName('command').setDescription('Command to send').setRequired(true)))
    .addSubcommand(s => s.setName('logs-link').setDescription('🔗 Get download link for latest.log of active server'))
  )

  // ── FILES GROUP ───────────────────────────────────────────
  .addSubcommandGroup(g => g.setName('files').setDescription('📁 File manager')
    .addSubcommand(s => s.setName('list').setDescription('📂 List files in directory of active server').addStringOption(o => o.setName('path').setDescription('Directory path (default: /)')))
    .addSubcommand(s => s.setName('read').setDescription('📄 Read file content on active server').addStringOption(o => o.setName('file').setDescription('File path').setRequired(true)))
    .addSubcommand(s => s.setName('write').setDescription('✏️ Edit a file on active server').addStringOption(o => o.setName('file').setDescription('File path').setRequired(true)))
    .addSubcommand(s => s.setName('delete').setDescription('🗑️ Delete a file on active server').addStringOption(o => o.setName('file').setDescription('File path').setRequired(true)))
    .addSubcommand(s => s.setName('rename').setDescription('🏷️ Rename a file on active server').addStringOption(o => o.setName('file').setDescription('File path').setRequired(true)).addStringOption(o => o.setName('newname').setDescription('New name').setRequired(true)))
    .addSubcommand(s => s.setName('mkdir').setDescription('📂 Create a folder on active server').addStringOption(o => o.setName('path').setDescription('Parent path').setRequired(true)).addStringOption(o => o.setName('name').setDescription('Folder name').setRequired(true)))
    .addSubcommand(s => s.setName('upload').setDescription('📤 Upload a file from Discord to active server')
      .addAttachmentOption(o => o.setName('file').setDescription('File to upload').setRequired(true))
      .addStringOption(o => o.setName('path').setDescription('Upload directory on server (default: /)')))
    .addSubcommand(s => s.setName('download').setDescription('📥 Get download link for a file').addStringOption(o => o.setName('file').setDescription('File path').setRequired(true)))
    .addSubcommand(s => s.setName('compress').setDescription('🗜️ Compress a file/folder').addStringOption(o => o.setName('path').setDescription('Path to compress').setRequired(true)))
    .addSubcommand(s => s.setName('decompress').setDescription('📦 Decompress an archive').addStringOption(o => o.setName('file').setDescription('Archive path').setRequired(true)))
    .addSubcommand(s => s.setName('search').setDescription('🔍 Search for files by name').addStringOption(o => o.setName('query').setDescription('File name to search for').setRequired(true)).addStringOption(o => o.setName('path').setDescription('Directory to search in (default: /)')))
    .addSubcommand(s => s.setName('copy').setDescription('📋 Copy a file in same directory').addStringOption(o => o.setName('file').setDescription('File path to copy').setRequired(true)))
    .addSubcommand(s => s.setName('move').setDescription('✂️ Move a file to another directory').addStringOption(o => o.setName('file').setDescription('Source file path').setRequired(true)).addStringOption(o => o.setName('destination').setDescription('Destination path').setRequired(true)))
    .addSubcommand(s => s.setName('stats').setDescription('📊 Get file info (size, type, modified date)').addStringOption(o => o.setName('file').setDescription('File path').setRequired(true)))
    .addSubcommand(s => s.setName('bulk-delete').setDescription('🗑️ Delete multiple files at once (comma-separated)').addStringOption(o => o.setName('files').setDescription('File paths separated by comma e.g. /a.txt,/b.log').setRequired(true)))
  )

  // ── BACKUP GROUP ──────────────────────────────────────────
  .addSubcommandGroup(g => g.setName('backup').setDescription('💾 Backup management')
    .addSubcommand(s => s.setName('list').setDescription('💾 List all backups of active server'))
    .addSubcommand(s => s.setName('create').setDescription('➕ Create a new backup').addStringOption(o => o.setName('name').setDescription('Backup name (optional)')))
    .addSubcommand(s => s.setName('delete').setDescription('🗑️ Delete a backup').addStringOption(o => o.setName('uuid').setDescription('Backup UUID').setRequired(true)))
    .addSubcommand(s => s.setName('restore').setDescription('🔁 Restore from a backup').addStringOption(o => o.setName('uuid').setDescription('Backup UUID').setRequired(true)))
    .addSubcommand(s => s.setName('download').setDescription('📥 Get backup download link').addStringOption(o => o.setName('uuid').setDescription('Backup UUID').setRequired(true)))
    .addSubcommand(s => s.setName('lock').setDescription('🔒 Toggle backup lock').addStringOption(o => o.setName('uuid').setDescription('Backup UUID').setRequired(true)))
    .addSubcommand(s => s.setName('info').setDescription('📋 Detailed info about a backup').addStringOption(o => o.setName('uuid').setDescription('Backup UUID').setRequired(true)))
  )

  // ── DATABASE GROUP ────────────────────────────────────────
  .addSubcommandGroup(g => g.setName('db').setDescription('🗄️ Database management')
    .addSubcommand(s => s.setName('list').setDescription('🗄️ List all databases of active server'))
    .addSubcommand(s => s.setName('create').setDescription('➕ Create a database').addStringOption(o => o.setName('name').setDescription('Database name').setRequired(true)))
    .addSubcommand(s => s.setName('delete').setDescription('🗑️ Delete a database').addStringOption(o => o.setName('dbid').setDescription('Database ID').setRequired(true)))
    .addSubcommand(s => s.setName('password').setDescription('🔐 Rotate database password').addStringOption(o => o.setName('dbid').setDescription('Database ID').setRequired(true)))
    .addSubcommand(s => s.setName('info').setDescription('🔑 Show DB connection details & password').addStringOption(o => o.setName('dbid').setDescription('Database ID').setRequired(true)))
  )

  // ── SCHEDULE GROUP ────────────────────────────────────────
  .addSubcommandGroup(g => g.setName('schedule').setDescription('📅 Schedule management')
    .addSubcommand(s => s.setName('list').setDescription('📅 List all schedules of active server'))
    .addSubcommand(s => s.setName('run').setDescription('▶️ Trigger a schedule now').addStringOption(o => o.setName('scheduleid').setDescription('Schedule ID').setRequired(true)))
    .addSubcommand(s => s.setName('delete').setDescription('🗑️ Delete a schedule').addStringOption(o => o.setName('scheduleid').setDescription('Schedule ID').setRequired(true)))
    .addSubcommand(s => s.setName('toggle').setDescription('🔄 Enable or disable a schedule').addStringOption(o => o.setName('scheduleid').setDescription('Schedule ID').setRequired(true)).addBooleanOption(o => o.setName('active').setDescription('true = enable, false = disable').setRequired(true)))
    .addSubcommand(s => s.setName('tasks').setDescription('📋 List all tasks inside a schedule').addStringOption(o => o.setName('scheduleid').setDescription('Schedule ID').setRequired(true)))
    .addSubcommand(s => s.setName('add-task').setDescription('➕ Add a task to a schedule').addStringOption(o => o.setName('scheduleid').setDescription('Schedule ID').setRequired(true)).addStringOption(o => o.setName('action').setDescription('command / power / backup').setRequired(true)).addStringOption(o => o.setName('payload').setDescription('e.g. say Hello / start / create').setRequired(true)).addIntegerOption(o => o.setName('offset').setDescription('Time offset in seconds (default 0)')))
  )

  // ── SUBUSER GROUP ─────────────────────────────────────────
  .addSubcommandGroup(g => g.setName('subuser').setDescription('👥 Subuser management')
    .addSubcommand(s => s.setName('list').setDescription('👥 List all subusers of active server'))
    .addSubcommand(s => s.setName('add').setDescription('➕ Add a subuser').addStringOption(o => o.setName('email').setDescription('User email').setRequired(true)))
    .addSubcommand(s => s.setName('remove').setDescription('❌ Remove a subuser').addStringOption(o => o.setName('uuid').setDescription('Subuser UUID').setRequired(true)))
    .addSubcommand(s => s.setName('permissions').setDescription('🔑 View a subuser\'s permissions').addStringOption(o => o.setName('uuid').setDescription('Subuser UUID').setRequired(true)))
    .addSubcommand(s => s.setName('count').setDescription('🔢 Total subusers on active server'))
  )

  // ── NETWORK GROUP ─────────────────────────────────────────
  .addSubcommandGroup(g => g.setName('network').setDescription('📡 Network & allocation management')
    .addSubcommand(s => s.setName('list').setDescription('📡 List all allocations of active server'))
    .addSubcommand(s => s.setName('add').setDescription('➕ Add an allocation to active server'))
    .addSubcommand(s => s.setName('remove').setDescription('❌ Remove an allocation').addStringOption(o => o.setName('allocid').setDescription('Allocation ID').setRequired(true)))
    .addSubcommand(s => s.setName('primary').setDescription('⭐ Set primary allocation').addStringOption(o => o.setName('allocid').setDescription('Allocation ID').setRequired(true)))
    .addSubcommand(s => s.setName('status').setDescription('🌐 Show primary IP:Port of active server'))
  )

  // ── ADMIN GROUP ───────────────────────────────────────────
  .addSubcommandGroup(g => g.setName('admin').setDescription('👑 Admin Application API')
    .addSubcommand(s => s.setName('servers').setDescription('🖥️ List all servers on panel'))
    .addSubcommand(s => s.setName('users').setDescription('👥 List all panel users'))
    .addSubcommand(s => s.setName('nodes').setDescription('🌐 List all nodes'))
    .addSubcommand(s => s.setName('locations').setDescription('📍 List all locations'))
    .addSubcommand(s => s.setName('nests').setDescription('🥚 List all nests'))
    .addSubcommand(s => s.setName('eggs').setDescription('🦕 List eggs in a nest').addIntegerOption(o => o.setName('nestid').setDescription('Nest ID').setRequired(true)))
    .addSubcommand(s => s.setName('suspend').setDescription('🔒 Suspend active server'))
    .addSubcommand(s => s.setName('unsuspend').setDescription('🔓 Unsuspend active server'))
    .addSubcommand(s => s.setName('rebuild').setDescription('🔧 Rebuild active server container'))
    .addSubcommand(s => s.setName('create-user').setDescription('➕ Create a new panel user (opens form)'))
    .addSubcommand(s => s.setName('create-server').setDescription('🖥️ Create a new server on panel (multi-step)'))
    .addSubcommand(s => s.setName('create-node').setDescription('🌐 Create a new node on panel (opens form)'))
    .addSubcommand(s => s.setName('delete-server').setDescription('🗑️ Delete active server permanently').addBooleanOption(o => o.setName('force').setDescription('Force delete?')))
    .addSubcommand(s => s.setName('delete-user').setDescription('🗑️ Delete a panel user').addIntegerOption(o => o.setName('userid').setDescription('User integer ID').setRequired(true)))
    .addSubcommand(s => s.setName('node-stats').setDescription('🖥️ View memory/disk usage per node'))
    .addSubcommand(s => s.setName('transfer').setDescription('🔄 Transfer active server to a different node').addIntegerOption(o => o.setName('nodeid').setDescription('Target node ID').setRequired(true)))
    .addSubcommand(s => s.setName('server-info').setDescription('🖥️ Full details of active server'))
    .addSubcommand(s => s.setName('user-info').setDescription('👤 Full details of any panel user by ID').addIntegerOption(o => o.setName('userid').setDescription('User integer ID').setRequired(true)))
    .addSubcommand(s => s.setName('node-info').setDescription('🌐 Full details of a node by ID').addIntegerOption(o => o.setName('nodeid').setDescription('Node integer ID').setRequired(true)))
    .addSubcommand(s => s.setName('update-build').setDescription('⚙️ Update active server resource limits').addIntegerOption(o => o.setName('memory').setDescription('Memory in MB (0=unlimited)')).addIntegerOption(o => o.setName('disk').setDescription('Disk in MB (0=unlimited)')).addIntegerOption(o => o.setName('cpu').setDescription('CPU limit % (0=unlimited)')).addIntegerOption(o => o.setName('swap').setDescription('Swap in MB (-1=disabled)')).addIntegerOption(o => o.setName('io').setDescription('IO weight (10-1000, default 500)')))
    .addSubcommand(s => s.setName('create-nest').setDescription('🥚 Create a new nest on panel (opens form)'))
    .addSubcommand(s => s.setName('create-egg').setDescription('🦕 Create a new egg in a nest (opens form)'))
  )

  // ── MINECRAFT GROUP ───────────────────────────────────────
  .addSubcommandGroup(g => g.setName('mc').setDescription('⛏️ Quick Minecraft commands')
    .addSubcommand(s => s.setName('op').setDescription('👑 OP a player on active server').addStringOption(o => o.setName('player').setDescription('Player name').setRequired(true)))
    .addSubcommand(s => s.setName('deop').setDescription('❌ DeOP a player on active server').addStringOption(o => o.setName('player').setDescription('Player name').setRequired(true)))
    .addSubcommand(s => s.setName('ban').setDescription('🚫 Ban a player on active server').addStringOption(o => o.setName('player').setDescription('Player name').setRequired(true)))
    .addSubcommand(s => s.setName('kick').setDescription('👟 Kick a player on active server').addStringOption(o => o.setName('player').setDescription('Player name').setRequired(true)))
    .addSubcommand(s => s.setName('pardon').setDescription('✅ Unban a player on active server').addStringOption(o => o.setName('player').setDescription('Player name').setRequired(true)))
    .addSubcommand(s => s.setName('whitelist-add').setDescription('➕ Add to whitelist on active server').addStringOption(o => o.setName('player').setDescription('Player name').setRequired(true)))
    .addSubcommand(s => s.setName('whitelist-remove').setDescription('❌ Remove from whitelist on active server').addStringOption(o => o.setName('player').setDescription('Player name').setRequired(true)))
    .addSubcommand(s => s.setName('save').setDescription('💾 Force world save on active server'))
    .addSubcommand(s => s.setName('software').setDescription('📦 Browse Minecraft server software & download versions'))
    .addSubcommand(s => s.setName('ping').setDescription('🏓 Check if a Minecraft server is online by IP').addStringOption(o => o.setName('ip').setDescription('Server IP (e.g. play.example.com or 1.2.3.4:25565)').setRequired(true)))
    .addSubcommand(s => s.setName('time').setDescription('🕐 Set in-game time on active server').addStringOption(o => o.setName('time').setDescription('Time to set').setRequired(true).addChoices({ name: '☀️ Day', value: 'day' }, { name: '🌙 Night', value: 'night' }, { name: '🌅 Noon', value: 'noon' }, { name: '🌃 Midnight', value: 'midnight' })))
    .addSubcommand(s => s.setName('weather').setDescription('🌦️ Set in-game weather on active server').addStringOption(o => o.setName('weather').setDescription('Weather type').setRequired(true).addChoices({ name: '☀️ Clear', value: 'clear' }, { name: '🌧️ Rain', value: 'rain' }, { name: '⛈️ Thunder', value: 'thunder' })))
    .addSubcommand(s => s.setName('gamemode').setDescription('🎮 Set gamemode for a player on active server').addStringOption(o => o.setName('player').setDescription('Player name').setRequired(true)).addStringOption(o => o.setName('mode').setDescription('Gamemode').setRequired(true).addChoices({ name: '⚔️ Survival', value: 'survival' }, { name: '🎨 Creative', value: 'creative' }, { name: '🗺️ Adventure', value: 'adventure' }, { name: '👁️ Spectator', value: 'spectator' })))
  );

// ── EXECUTE ────────────────────────────────────────────────────────────────

async function execute(interaction) {
  const group = interaction.options.getSubcommandGroup();
  const sub = interaction.options.getSubcommand();
  const userId = interaction.user.id;

  // ── NO LOGIN NEEDED ────────────────────────────────────────
  if (group === 'setup') {
    if (sub === 'login') return handleLogin(interaction);
    if (sub === 'help') return interaction.reply({ embeds: [E.helpEmbed()], ephemeral: true });
    if (sub === 'ping') return interaction.reply({ embeds: [E.pingEmbed(interaction.client)], ephemeral: true });
    if (sub === 'info') return interaction.reply({ embeds: [E.botInfo(interaction.client, store.totalUsers())], ephemeral: true });
    if (sub === 'changelog') return interaction.reply({ embeds: [E.changelogEmbed()], ephemeral: true });
    if (sub === 'invite') return interaction.reply({ embeds: [E.inviteEmbed(process.env.DISCORD_CLIENT_ID)], ephemeral: true });
  }

  // ── CHECK LOGIN (own or trusted) ───────────────────────────
  const creds = store.resolveCredentials(userId);
  if (!creds) {
    return interaction.reply({ embeds: [E.notLoggedIn()], ephemeral: true });
  }

  const user = store.getUser(userId) || creds;
  const { panelUrl, apiKey } = creds;

  // ── SETUP (needs login) ────────────────────────────────────
  if (group === 'setup') {
    if (sub === 'logout') {
      if (creds.isTrusted) return interaction.reply({ embeds: [E.error('Cannot Logout', '> You are using a trusted panel. Ask the owner to remove your trust.')], ephemeral: true });
      store.deleteUser(userId);
      return interaction.reply({ embeds: [E.logoutSuccess()], ephemeral: true });
    }
    if (sub === 'profile') return interaction.reply({ embeds: [E.profileEmbed(user, creds)], ephemeral: true });
    if (sub === 'panel-status') return handlePanelStatus(interaction, panelUrl, apiKey);

    // ── TRUST COMMANDS ──────────────────────────────────────
    if (sub === 'trust-add') {
      if (creds.isTrusted) return interaction.reply({ embeds: [E.error('No Permission', '> Only the panel owner can manage trust.')], ephemeral: true });
      const target = interaction.options.getUser('user');
      if (target.id === userId) return interaction.reply({ embeds: [E.error('Invalid', '> You cannot trust yourself.')], ephemeral: true });
      store.addTrustedUser(userId, target.id, target.tag);
      return interaction.reply({ embeds: [E.success('User Trusted ✅', `> 🤝 **${target.tag}** (<@${target.id}>) can now use your panel!\n> They can access all commands with your credentials.`)], ephemeral: true });
    }
    if (sub === 'trust-remove') {
      if (creds.isTrusted) return interaction.reply({ embeds: [E.error('No Permission', '> Only the panel owner can manage trust.')], ephemeral: true });
      const target = interaction.options.getUser('user');
      const removed = store.removeTrustedUser(userId, target.id);
      return interaction.reply({ embeds: [removed ? E.success('Trust Removed', `> ❌ **${target.tag}** can no longer use your panel.`) : E.warning('Not Found', `> **${target.tag}** was not in your trust list.`)], ephemeral: true });
    }
    if (sub === 'trust-list') {
      if (creds.isTrusted) return interaction.reply({ embeds: [E.error('No Permission', '> Only the panel owner can view the trust list.')], ephemeral: true });
      const trusted = store.getTrustedUsers(userId);
      return interaction.reply({ embeds: [E.trustListEmbed(trusted, interaction.user.tag)], ephemeral: true });
    }
  }

  // ── RESOLVE SERVER ID ──────────────────────────────────────
  const serverId = store.getSelectedServer(userId);

  // ── ADMIN CREATE: must show modal BEFORE deferReply ────────
  if (group === 'admin' && sub === 'create-user') return await handleAdminCreateUser(interaction);
  if (group === 'admin' && sub === 'create-node') return await handleAdminCreateNode(interaction);
  if (group === 'admin' && sub === 'create-server') return await handleAdminCreateServer(interaction, panelUrl, apiKey, userId);
  if (group === 'admin' && sub === 'create-nest') return await handleAdminCreateNest(interaction);
  if (group === 'admin' && sub === 'create-egg') return await handleAdminCreateEgg(interaction);

  // ── MC SOFTWARE: must reply BEFORE deferReply ─────────────
  if (group === 'mc' && sub === 'software') {
    const servers = await ptero.listServers(panelUrl, apiKey).catch(() => []);
    if (!servers || servers.length === 0) {
      return interaction.reply({ embeds: [E.warning('No Servers', '> 📭 No servers on this panel. Check your API key or contact admin.')], ephemeral: true });
    }
    return interaction.reply({ embeds: [E.softwareSelectEmbed()], components: [E.softwareSelectMenu(mcVersions.SOFTWARE)], ephemeral: true });
  }

  // ── FILE WRITE: must show modal BEFORE deferReply ──────────
  if (group === 'files' && sub === 'write') {
    const filePath = interaction.options.getString('file');
    const targetId = serverId;
    if (!targetId) {
      return interaction.reply({ embeds: [E.error('No Active Server', '> No server selected.\n> Use `/mcmanager server manage` to pick your server from a dropdown.')], ephemeral: true });
    }
    let existing = '';
    try {
      existing = String(await ptero.getFileContents(panelUrl, apiKey, targetId, filePath)).slice(0, 3900);
    } catch {
      existing = '';
    }
    const fname = filePath.split('/').pop();
    const modal = new ModalBuilder()
      .setCustomId(`write_file:${targetId}:${encodeURIComponent(filePath)}`)
      .setTitle(`✏️ ${fname.slice(0, 43)}`);
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('file_content')
          .setLabel(`Editing: ${fname.slice(0, 40)}`)
          .setStyle(TextInputStyle.Paragraph)
          .setValue(existing)
          .setRequired(false)
          .setMaxLength(4000)
      )
    );
    return interaction.showModal(modal);
  }

  await interaction.deferReply({ ephemeral: true });

  try {
    // ── SERVER GROUP ─────────────────────────────────────────
    if (group === 'server') {
      if (sub === 'list') return await handleServers(interaction, panelUrl, apiKey, userId);
      if (sub === 'manage') return await handleManage(interaction, panelUrl, apiKey, userId);
      if (sub === 'select') return await handleManage(interaction, panelUrl, apiKey, userId);
      if (sub === 'deselect') { store.clearSelectedServer(userId); return interaction.editReply({ embeds: [E.success('Cleared', '> Default server cleared.')] }); }
      if (sub === 'bulk-start') return await handleBulkPower(interaction, panelUrl, apiKey, 'start');
      if (sub === 'bulk-stop') return await handleBulkPower(interaction, panelUrl, apiKey, 'stop');
      if (sub === 'bulk-restart') return await handleBulkPower(interaction, panelUrl, apiKey, 'restart');
      if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
      if (sub === 'status') return await handleStatus(interaction, panelUrl, apiKey, serverId);
      if (sub === 'start') return await handlePower(interaction, panelUrl, apiKey, serverId, 'start');
      if (sub === 'stop') return await handlePower(interaction, panelUrl, apiKey, serverId, 'stop');
      if (sub === 'restart') return await handlePower(interaction, panelUrl, apiKey, serverId, 'restart');
      if (sub === 'kill') return await handlePower(interaction, panelUrl, apiKey, serverId, 'kill');
      if (sub === 'reinstall') { await ptero.clientReinstallServer(panelUrl, apiKey, serverId); return interaction.editReply({ embeds: [E.warning('Reinstall Triggered', `> ⚠️ Server \`${serverId}\` reinstall triggered. Data may be wiped!`)] }); }
      if (sub === 'suspend') { await ptero.appSuspendServer(panelUrl, apiKey, serverId); return interaction.editReply({ embeds: [E.success('Suspended', `> 🔒 Server \`${serverId}\` suspended.`)] }); }
      if (sub === 'unsuspend') { await ptero.appUnsuspendServer(panelUrl, apiKey, serverId); return interaction.editReply({ embeds: [E.success('Unsuspended', `> 🔓 Server \`${serverId}\` unsuspended.`)] }); }
      // ── NEW FEATURES ────────────────────────────────────────
      if (sub === 'sftp') {
        if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
        const servers = await ptero.listServers(panelUrl, apiKey);
        const server = servers.find(s => s.attributes.identifier === serverId);
        if (!server) return interaction.editReply({ embeds: [E.error('Not Found', `> No server with ID \`${serverId}\``)] });
        return interaction.editReply({ embeds: [E.sftpEmbed(server, panelUrl)] });
      }
      if (sub === 'all-status') {
        const servers = await ptero.listServers(panelUrl, apiKey);
        if (!servers.length) return interaction.editReply({ embeds: [E.warning('No Servers', '> No servers found.')] });
        const resourcesMap = {};
        await Promise.allSettled(servers.map(async s => {
          try { resourcesMap[s.attributes.identifier] = (await ptero.getServerResources(panelUrl, apiKey, s.attributes.identifier)); } catch {}
        }));
        return interaction.editReply({ embeds: [E.allStatusEmbed(servers, resourcesMap)] });
      }
      if (sub === 'limits') {
        if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
        const servers = await ptero.listServers(panelUrl, apiKey);
        const server = servers.find(s => s.attributes.identifier === serverId);
        if (!server) return interaction.editReply({ embeds: [E.error('Not Found', `> No server with ID \`${serverId}\``)] });
        return interaction.editReply({ embeds: [E.serverLimitsEmbed(server)] });
      }
      if (sub === 'rename') {
        if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
        const newName = interaction.options.getString('name');
        const resolved = await resolveAdminIntId(panelUrl, apiKey, serverId);
        if (!resolved) return interaction.editReply({ embeds: [E.error('Not Found', `> Could not find active server \`${serverId}\` via admin API.\n> Check your Application API key.`)] });
        const renamed = await ptero.appRenameServer(panelUrl, apiKey, resolved.intId, newName);
        return interaction.editReply({ embeds: [E.success('Server Renamed ✏️', `> **${renamed.name || newName}** renamed successfully!`)] });
      }
      if (sub === 'variables') {
        if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
        const data = await ptero.getServerVariables(panelUrl, apiKey, serverId);
        return interaction.editReply({ embeds: [E.serverVariablesEmbed(data, serverId)] });
      }
      if (sub === 'variable-set') {
        if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
        const key = interaction.options.getString('key');
        const value = interaction.options.getString('value');
        const updated = await ptero.updateServerVariable(panelUrl, apiKey, serverId, key, value);
        return interaction.editReply({ embeds: [E.success('Variable Updated ✅', `> **${updated.name || key}**\n> Key: \`${key}\`\n> New value: \`${value}\``)] });
      }
      if (sub === 'info') {
        if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
        const [servers, resources] = await Promise.all([ptero.listServers(panelUrl, apiKey), ptero.getServerResources(panelUrl, apiKey, serverId).catch(() => null)]);
        const server = servers.find(s => s.attributes.identifier === serverId);
        if (!server) return interaction.editReply({ embeds: [E.error('Not Found', `> No server with ID \`${serverId}\``)] });
        const a = server.attributes;
        return interaction.editReply({ embeds: [E.info(`📋 Server Info — ${a.name}`, [
          `> 🆔 **Identifier:** \`${a.identifier}\``,
          `> 🌐 **Node:** \`${a.node}\``,
          `> 📦 **Egg:** \`${a.egg || '?'}\`  **Nest:** \`${a.nest || '?'}\``,
          `> 📡 **SFTP:** \`${a.sftp_details?.ip || '?'}:${a.sftp_details?.port || 2022}\``,
          `> 📊 **Status:** ${resources?.current_state || 'offline'}`,
          `> 🧠 **RAM:** ${a.limits.memory} MB  💾 **Disk:** ${a.limits.disk} MB  ⚡ **CPU:** ${a.limits.cpu}%`,
          `> 💾 **Backups:** ${a.feature_limits.backups}  🗄️ **DBs:** ${a.feature_limits.databases}`,
          `> 🔁 **Reinstall on deploy:** ${a.container?.image || '—'}`,
        ].join('\n'))] });
      }
      if (sub === 'notes') {
        const text = interaction.options.getString('text');
        const noteKey = `note_${serverId}`;
        if (text) {
          store.setExtra(userId, noteKey, text);
          return interaction.editReply({ embeds: [E.success('Note Saved 📝', `> Server \`${serverId}\`:\n> ${text}`)] });
        }
        const note = store.getExtra(userId, noteKey);
        return interaction.editReply({ embeds: [E.info(`📝 Notes — \`${serverId}\``, note ? `> ${note}` : '> No notes saved yet. Use `/mcmanager server notes text:<your note>` to save one.')] });
      }
      if (sub === 'startup') {
        if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
        const data = await ptero.getServerVariables(panelUrl, apiKey, serverId);
        return interaction.editReply({ embeds: [E.info(`🚀 Startup Command — \`${serverId}\``, `\`\`\`\n${data.startup || 'No startup command found.'}\n\`\`\``)] });
      }
      if (sub === 'resources') {
        if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
        const r = await ptero.getServerResources(panelUrl, apiKey, serverId);
        const res = r.resources || {};
        const mb = b => `${(b / 1024 / 1024).toFixed(1)} MB`;
        return interaction.editReply({ embeds: [E.info(`📈 Resources — \`${serverId}\``, [
          `> ⚡ **CPU:** \`${res.cpu_absolute?.toFixed(2) || 0}%\``,
          `> 🧠 **RAM:** \`${mb(res.memory_bytes || 0)}\``,
          `> 💾 **Disk:** \`${mb(res.disk_bytes || 0)}\``,
          `> 🌐 **Net ↑:** \`${mb(res.network_tx_bytes || 0)}\`  **↓:** \`${mb(res.network_rx_bytes || 0)}\``,
          `> 🔌 **State:** \`${r.current_state || 'offline'}\``,
        ].join('\n'))] });
      }
      if (sub === 'pin') {
        if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
        const pins = store.getExtra(userId, 'pinnedServers') || [];
        const already = pins.includes(serverId);
        const updated = already ? pins.filter(id => id !== serverId) : [...pins, serverId];
        store.setExtra(userId, 'pinnedServers', updated);
        const servers = await ptero.listServers(panelUrl, apiKey);
        const sName = servers.find(s => s.attributes.identifier === serverId)?.attributes?.name || serverId;
        return interaction.editReply({ embeds: [E.success(already ? 'Server Unpinned 📌' : 'Server Pinned 📌', [
          `> Server **${sName}** (\`${serverId}\`) is now **${already ? 'unpinned' : 'pinned'}**.`,
          already ? '' : `> 📌 Pinned servers: ${updated.map(id => `\`${id}\``).join(', ')}`,
        ].filter(Boolean).join('\n'))] });
      }
    }

    // ── CONSOLE GROUP ─────────────────────────────────────────
    if (group === 'console') {
      if (sub === 'broadcast') {
        const msg = interaction.options.getString('message');
        const servers = await ptero.listServers(panelUrl, apiKey);
        if (!servers.length) return interaction.editReply({ embeds: [E.warning('No Servers', '> No servers to broadcast to.')] });
        let done = 0, failed = 0;
        await Promise.allSettled(servers.map(async s => {
          try { await ptero.sendCommand(panelUrl, apiKey, s.attributes.identifier, `say ${msg}`); done++; } catch { failed++; }
        }));
        return interaction.editReply({ embeds: [E.success('Broadcast Sent 📢', `> 💬 **"${msg}"**\n\n> ✅ Sent to **${done}** servers\n> ❌ Failed: **${failed}**`)] });
      }
      if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
      if (sub === 'view') return interaction.editReply({ embeds: [E.info('Console Access', `> 💻 **Server:** \`${serverId}\`\n\n> Use \`/mcmanager console cmd\` to send commands.\n> Use \`/mcmanager console say\` to broadcast in-game.`)] });
      if (sub === 'cmd') { const cmd = interaction.options.getString('command'); await ptero.sendCommand(panelUrl, apiKey, serverId, cmd); return interaction.editReply({ embeds: [E.success('Command Sent', `> ➤ Sent to \`${serverId}\`:\n> \`\`\`${cmd}\`\`\``)] }); }
      if (sub === 'say') { const msg = interaction.options.getString('message'); await ptero.sendCommand(panelUrl, apiKey, serverId, `say ${msg}`); return interaction.editReply({ embeds: [E.success('Message Broadcast', `> 💬 In-game message sent:\n> **"${msg}"**`)] }); }
      if (sub === 'latest-log') {
        try {
          const log = await ptero.getFileContents(panelUrl, apiKey, serverId, '/logs/latest.log');
          const lines = String(log).split('\n').slice(-40).join('\n');
          const truncated = lines.length > 3800 ? '...[truncated]\n' + lines.slice(-3800) : lines;
          return interaction.editReply({ embeds: [E.info(`📜 latest.log — \`${serverId}\``, `\`\`\`\n${truncated || 'Log is empty.'}\n\`\`\``)] });
        } catch { return interaction.editReply({ embeds: [E.error('Log Not Found', '> Could not read `/logs/latest.log`.\n> Make sure the server has run at least once.')] }); }
      }
      if (sub === 'send-all') {
        const cmd = interaction.options.getString('command');
        const servers = await ptero.listServers(panelUrl, apiKey);
        if (!servers.length) return interaction.editReply({ embeds: [E.warning('No Servers', '> No servers found.')] });
        let done = 0, failed = 0;
        await Promise.allSettled(servers.map(async s => {
          try { await ptero.sendCommand(panelUrl, apiKey, s.attributes.identifier, cmd); done++; } catch { failed++; }
        }));
        return interaction.editReply({ embeds: [E.success('Command Sent ⚡', `> Command: \`${cmd}\`\n\n> ✅ Sent to **${done}** servers\n> ❌ Failed: **${failed}**`)] });
      }
      if (sub === 'logs-link') {
        if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
        const url = await ptero.getFileDownloadUrl(panelUrl, apiKey, serverId, '/logs/latest.log');
        return interaction.editReply({ embeds: [E.info(`🔗 Download latest.log — \`${serverId}\``, `> [Click here to download latest.log](${url})\n\n> ⚠️ Link expires in a few minutes.`)] });
      }
    }

    // ── FILES GROUP ───────────────────────────────────────────
    if (group === 'files') {
      if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
      if (sub === 'list') {
        const dir = interaction.options.getString('path') || '/';
        const [servers, files] = await Promise.all([ptero.listServers(panelUrl, apiKey), ptero.listFiles(panelUrl, apiKey, serverId, dir)]);
        const sName = servers.find(s => s.attributes.identifier === serverId)?.attributes?.name || serverId;
        return interaction.editReply({ embeds: [E.fileList(files, dir, sName)] });
      }
      if (sub === 'read') {
        const fp = interaction.options.getString('file');
        const [servers, content] = await Promise.all([ptero.listServers(panelUrl, apiKey), ptero.getFileContents(panelUrl, apiKey, serverId, fp)]);
        const sName = servers.find(s => s.attributes.identifier === serverId)?.attributes?.name || serverId;
        return interaction.editReply({ embeds: [E.fileContent(fp, String(content), sName)] });
      }
      if (sub === 'write') return handleWrite(interaction, panelUrl, apiKey, serverId);
      if (sub === 'delete') {
        const fp = interaction.options.getString('file');
        const parts = fp.split('/'); const fn = parts.pop(); const root = parts.join('/') || '/';
        store.setExtra(userId, 'pendingDelete', { filePath: fp, root, fileName: fn, serverId });
        const confirmRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('cancel_delete').setLabel('❌ Cancel (Default)').setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId('confirm_delete').setLabel('🗑️ Yes, Delete').setStyle(ButtonStyle.Danger),
        );
        return interaction.editReply({ embeds: [E.deleteConfirmEmbed(fp)], components: [confirmRow] });
      }
      if (sub === 'rename') {
        const fp = interaction.options.getString('file'); const nn = interaction.options.getString('newname');
        const parts = fp.split('/'); const fn = parts.pop(); const root = parts.join('/') || '/';
        await ptero.renameFile(panelUrl, apiKey, serverId, root, [{ from: fn, to: nn }]);
        return interaction.editReply({ embeds: [E.success('Renamed', `> 🏷️ \`${fn}\` → \`${nn}\``)] });
      }
      if (sub === 'mkdir') {
        const path = interaction.options.getString('path'); const name = interaction.options.getString('name');
        await ptero.createFolder(panelUrl, apiKey, serverId, path, name);
        return interaction.editReply({ embeds: [E.success('Folder Created', `> 📂 Created \`${name}\` at \`${path}\``)] });
      }
      if (sub === 'upload') {
        const attachment = interaction.options.getAttachment('file');
        const uploadPath = interaction.options.getString('path') || '/';
        const result = await ptero.uploadDiscordFile(panelUrl, apiKey, serverId, attachment.url, attachment.name, uploadPath);
        const sizeStr = result.size > 1024 * 1024
          ? `${(result.size / 1024 / 1024).toFixed(2)} MB`
          : `${(result.size / 1024).toFixed(1)} KB`;
        return interaction.editReply({ embeds: [E.success('File Uploaded ✅', [
          `> 📁 **File:** \`${result.fileName}\``,
          `> 📂 **Uploaded to:** \`${result.path}\``,
          `> 📦 **Size:** \`${sizeStr}\``,
          `> ✅ Successfully uploaded to your server!`,
        ].join('\n'))] });
      }
      if (sub === 'download') {
        const fp = interaction.options.getString('file');
        const url = await ptero.getDownloadUrl(panelUrl, apiKey, serverId, fp);
        return interaction.editReply({ embeds: [E.success('Download Ready', `> 📥 **File:** \`${fp}\`\n\n> [Click to Download](${url})\n> ⚠️ Link expires soon!`)] });
      }
      if (sub === 'compress') {
        const fp = interaction.options.getString('path'); const parts = fp.split('/'); const n = parts.pop(); const root = parts.join('/') || '/';
        const res = await ptero.compressFiles(panelUrl, apiKey, serverId, root, [n]);
        return interaction.editReply({ embeds: [E.success('Compressed', `> 🗜️ Created \`${res?.name || 'archive.tar.gz'}\``)] });
      }
      if (sub === 'decompress') {
        const fp = interaction.options.getString('file'); const parts = fp.split('/'); const n = parts.pop(); const root = parts.join('/') || '/';
        await ptero.decompressFile(panelUrl, apiKey, serverId, root, n);
        return interaction.editReply({ embeds: [E.success('Decompressed', `> 📦 Decompressed \`${n}\``)] });
      }
      if (sub === 'search') {
        const query = interaction.options.getString('query').toLowerCase();
        const dir = interaction.options.getString('path') || '/';
        const [servers, files] = await Promise.all([ptero.listServers(panelUrl, apiKey), ptero.listFiles(panelUrl, apiKey, serverId, dir)]);
        const sName = servers.find(s => s.attributes.identifier === serverId)?.attributes?.name || serverId;
        const matches = files.filter(f => f.attributes.name.toLowerCase().includes(query));
        return interaction.editReply({ embeds: [E.fileSearchEmbed(query, matches, dir, sName)] });
      }
      if (sub === 'copy') {
        const fp = interaction.options.getString('file');
        await ptero.copyFile(panelUrl, apiKey, serverId, fp);
        return interaction.editReply({ embeds: [E.success('File Copied 📋', `> \`${fp}\` has been copied.\n> A new copy exists in the same directory.`)] });
      }
      if (sub === 'move') {
        const fp = interaction.options.getString('file');
        const dest = interaction.options.getString('destination');
        const parts = fp.split('/'); const name = parts.pop(); const root = parts.join('/') || '/';
        await ptero.renameFile(panelUrl, apiKey, serverId, root, name, dest);
        return interaction.editReply({ embeds: [E.success('File Moved ✂️', `> \`${fp}\` → \`${dest}\``)] });
      }
      if (sub === 'bulk-delete') {
        const rawPaths = interaction.options.getString('files');
        const paths = rawPaths.split(',').map(p => p.trim()).filter(Boolean);
        if (!paths.length) return interaction.editReply({ embeds: [E.error('No Files', '> Please provide comma-separated file paths.')] });
        let deleted = 0, failed = [];
        await Promise.allSettled(paths.map(async fp => {
          try {
            const parts = fp.split('/'); const fn = parts.pop(); const root = parts.join('/') || '/';
            await ptero.deleteFiles(panelUrl, apiKey, serverId, root, [fn]);
            deleted++;
          } catch { failed.push(fp); }
        }));
        return interaction.editReply({ embeds: [E.success('Bulk Delete Done 🗑️', [
          `> ✅ **Deleted:** \`${deleted}\` file(s)`,
          failed.length ? `> ❌ **Failed:** ${failed.map(f => `\`${f}\``).join(', ')}` : '',
        ].filter(Boolean).join('\n'))] });
      }
      if (sub === 'stats') {
        const fp = interaction.options.getString('file');
        const file = await ptero.getFileStats(panelUrl, apiKey, serverId, fp);
        if (!file) return interaction.editReply({ embeds: [E.error('Not Found', `> File \`${fp}\` not found.`)] });
        const a = file.attributes;
        const size = a.size ? `\`${(a.size / 1024).toFixed(2)} KB\` (${a.size} bytes)` : '`—`';
        return interaction.editReply({ embeds: [E.info(`📊 File Stats — ${a.name}`, [
          `> 📄 **Name:** \`${a.name}\``,
          `> 📦 **Type:** \`${a.is_file ? (a.mimetype || 'file') : 'directory'}\``,
          `> 💾 **Size:** ${size}`,
          `> 📅 **Modified:** \`${a.modified_at || '—'}\``,
          `> 🔒 **Permissions:** \`${a.mode || '—'}\``,
        ].join('\n'))] });
      }
    }

    // ── BACKUP GROUP ──────────────────────────────────────────
    if (group === 'backup') {
      if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
      if (sub === 'list') {
        const [servers, backups] = await Promise.all([ptero.listServers(panelUrl, apiKey), ptero.listBackups(panelUrl, apiKey, serverId)]);
        const sName = servers.find(s => s.attributes.identifier === serverId)?.attributes?.name || serverId;
        const { items, page: p, totalPages } = paginateList(backups, 0, PER_PAGE.backup);
        return interaction.editReply(withPagination(E.backupList(items, sName, p, totalPages, backups.length), [], 'backup', p, totalPages, serverId));
      }
      if (sub === 'create') { const name = interaction.options.getString('name'); const b = await ptero.createBackup(panelUrl, apiKey, serverId, name); return interaction.editReply({ embeds: [E.success('Backup Started', `> 💾 **"${b.name}"** is being created!\n> UUID: \`${b.uuid}\``)] }); }
      if (sub === 'delete') { await ptero.deleteBackup(panelUrl, apiKey, serverId, interaction.options.getString('uuid')); return interaction.editReply({ embeds: [E.success('Backup Deleted', `> 🗑️ Backup deleted.`)] }); }
      if (sub === 'restore') { await ptero.restoreBackup(panelUrl, apiKey, serverId, interaction.options.getString('uuid')); return interaction.editReply({ embeds: [E.warning('Restoring', `> 🔁 Restoring backup — server will restart.`)] }); }
      if (sub === 'download') { const url = await ptero.getBackupDownload(panelUrl, apiKey, serverId, interaction.options.getString('uuid')); return interaction.editReply({ embeds: [E.success('Backup Download', `> 📥 [Download Backup](${url})\n> ⚠️ Expires soon!`)] }); }
      if (sub === 'lock') { const res = await ptero.toggleBackupLock(panelUrl, apiKey, serverId, interaction.options.getString('uuid')); return interaction.editReply({ embeds: [E.success(`Backup ${res.is_locked ? 'Locked 🔒' : 'Unlocked 🔓'}`, `> Backup is now **${res.is_locked ? 'locked' : 'unlocked'}**.`)] }); }
      if (sub === 'info') {
        const b = await ptero.getBackupInfo(panelUrl, apiKey, serverId, interaction.options.getString('uuid'));
        const size = b.bytes ? `\`${(b.bytes / 1024 / 1024).toFixed(2)} MB\`` : '`—`';
        return interaction.editReply({ embeds: [E.info(`💾 Backup Info`, [
          `> 📛 **Name:** ${b.name || '—'}`,
          `> 🆔 **UUID:** \`${b.uuid}\``,
          `> 💾 **Size:** ${size}`,
          `> ✅ **Completed:** ${b.is_successful ? 'Yes' : 'No'}`,
          `> 🔒 **Locked:** ${b.is_locked ? 'Yes' : 'No'}`,
          `> 📅 **Created:** \`${b.created_at || '—'}\``,
          `> 📅 **Completed At:** \`${b.completed_at || '—'}\``,
        ].join('\n'))] });
      }
    }

    // ── DATABASE GROUP ────────────────────────────────────────
    if (group === 'db') {
      if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
      if (sub === 'list') {
        const [servers, dbs] = await Promise.all([ptero.listServers(panelUrl, apiKey), ptero.listDatabases(panelUrl, apiKey, serverId)]);
        const sName = servers.find(s => s.attributes.identifier === serverId)?.attributes?.name || serverId;
        const { items, page: p, totalPages } = paginateList(dbs, 0, PER_PAGE.db);
        return interaction.editReply(withPagination(E.databaseList(items, sName, p, totalPages, dbs.length), [], 'db', p, totalPages, serverId));
      }
      if (sub === 'create') { const db = await ptero.createDatabase(panelUrl, apiKey, serverId, interaction.options.getString('name')); return interaction.editReply({ embeds: [E.success('Database Created', `> 🗄️ **${db.name}**\n> Host: \`${db.relationships?.host?.attributes?.address}\`\n> User: \`${db.username}\``)] }); }
      if (sub === 'delete') { await ptero.deleteDatabase(panelUrl, apiKey, serverId, interaction.options.getString('dbid')); return interaction.editReply({ embeds: [E.success('Database Deleted', '> 🗑️ Database deleted.')] }); }
      if (sub === 'password') { await ptero.rotateDatabasePassword(panelUrl, apiKey, serverId, interaction.options.getString('dbid')); return interaction.editReply({ embeds: [E.success('Password Rotated', '> 🔐 New password set. Check panel for credentials.')] }); }
      if (sub === 'info') {
        const db = await ptero.getDatabaseInfo(panelUrl, apiKey, serverId, interaction.options.getString('dbid'));
        const pw = db.relationships?.password?.attributes?.password || '(rotate to reveal)';
        return interaction.editReply({ embeds: [E.info(`🗄️ Database Info — ${db.name}`, [
          `> 🆔 **ID:** \`${db.id}\``,
          `> 📛 **Name:** \`${db.name}\``,
          `> 🌐 **Host:** \`${db.host?.address || '?'}:${db.host?.port || 3306}\``,
          `> 👤 **Username:** \`${db.username}\``,
          `> 🔑 **Password:** \`${pw}\``,
          `> 🔗 **JDBC:** \`jdbc:mysql://${db.username}:${pw}@${db.host?.address || '?'}:${db.host?.port || 3306}/${db.name}\``,
        ].join('\n'))] });
      }
    }

    // ── SCHEDULE GROUP ────────────────────────────────────────
    if (group === 'schedule') {
      if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
      if (sub === 'list') {
        const [servers, scheds] = await Promise.all([ptero.listServers(panelUrl, apiKey), ptero.listSchedules(panelUrl, apiKey, serverId)]);
        const sName = servers.find(s => s.attributes.identifier === serverId)?.attributes?.name || serverId;
        const { items, page: p, totalPages } = paginateList(scheds, 0, PER_PAGE.schedule);
        return interaction.editReply(withPagination(E.scheduleList(items, sName, p, totalPages, scheds.length), [], 'schedule', p, totalPages, serverId));
      }
      if (sub === 'run') { await ptero.triggerSchedule(panelUrl, apiKey, serverId, interaction.options.getString('scheduleid')); return interaction.editReply({ embeds: [E.success('Schedule Triggered', '> ▶️ Schedule triggered now.')] }); }
      if (sub === 'delete') { await ptero.deleteSchedule(panelUrl, apiKey, serverId, interaction.options.getString('scheduleid')); return interaction.editReply({ embeds: [E.success('Schedule Deleted', '> 🗑️ Schedule deleted.')] }); }
      if (sub === 'toggle') {
        const active = interaction.options.getBoolean('active');
        const res = await ptero.toggleSchedule(panelUrl, apiKey, serverId, interaction.options.getString('scheduleid'), active);
        return interaction.editReply({ embeds: [E.success(`Schedule ${active ? 'Enabled ✅' : 'Disabled ⏸️'}`, `> **${res.name}** is now **${active ? 'enabled' : 'disabled'}**.`)] });
      }
      if (sub === 'tasks') {
        const { schedule, tasks } = await ptero.getScheduleTasks(panelUrl, apiKey, serverId, interaction.options.getString('scheduleid'));
        const lines = tasks.map((t, i) => {
          const a = t.attributes;
          return `> **${i + 1}.** Action: \`${a.action}\` | Payload: \`${a.payload || '—'}\` | Offset: \`${a.time_offset}s\``;
        });
        return interaction.editReply({ embeds: [E.info(`📋 Schedule Tasks — ${schedule.name}`, lines.join('\n') || '> No tasks found.')] });
      }
      if (sub === 'add-task') {
        const task = await ptero.createScheduleTask(panelUrl, apiKey, serverId, interaction.options.getString('scheduleid'),
          interaction.options.getString('action'), interaction.options.getString('payload'), interaction.options.getInteger('offset') || 0);
        return interaction.editReply({ embeds: [E.success('Task Added ➕', `> Action: \`${task.action}\`\n> Payload: \`${task.payload}\`\n> Offset: \`${task.time_offset}s\``)] });
      }
    }

    // ── SUBUSER GROUP ─────────────────────────────────────────
    if (group === 'subuser') {
      if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
      if (sub === 'list') {
        const [servers, users] = await Promise.all([ptero.listServers(panelUrl, apiKey), ptero.listSubusers(panelUrl, apiKey, serverId)]);
        const sName = servers.find(s => s.attributes.identifier === serverId)?.attributes?.name || serverId;
        const { items, page: p, totalPages } = paginateList(users, 0, PER_PAGE.subuser);
        return interaction.editReply(withPagination(E.subuserList(items, sName, p, totalPages, users.length), [], 'subuser', p, totalPages, serverId));
      }
      if (sub === 'add') { await ptero.addSubuser(panelUrl, apiKey, serverId, interaction.options.getString('email'), ['control.console', 'control.start', 'control.stop', 'control.restart']); return interaction.editReply({ embeds: [E.success('Subuser Added', `> 👤 **${interaction.options.getString('email')}** added!`)] }); }
      if (sub === 'remove') { await ptero.removeSubuser(panelUrl, apiKey, serverId, interaction.options.getString('uuid')); return interaction.editReply({ embeds: [E.success('Subuser Removed', '> ❌ Subuser removed.')] }); }
      if (sub === 'permissions') {
        const su = await ptero.getSubuserPermissions(panelUrl, apiKey, serverId, interaction.options.getString('uuid'));
        const perms = (su.permissions || []).map(p => `\`${p}\``).join(', ') || '`None`';
        return interaction.editReply({ embeds: [E.info(`🔑 Subuser Permissions`, `> **Email:** ${su.email}\n> **2FA:** ${su.two_factor_enabled ? 'Yes' : 'No'}\n\n**Permissions:**\n> ${perms}`)] });
      }
      if (sub === 'count') {
        const list = await ptero.listSubusers(panelUrl, apiKey, serverId);
        return interaction.editReply({ embeds: [E.info('🔢 Subuser Count', `> Server \`${serverId}\` has **${list.length}** subuser(s).`)] });
      }
    }

    // ── NETWORK GROUP ─────────────────────────────────────────
    if (group === 'network') {
      if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
      if (sub === 'list') {
        const [servers, allocs] = await Promise.all([ptero.listServers(panelUrl, apiKey), ptero.listAllocations(panelUrl, apiKey, serverId)]);
        const sName = servers.find(s => s.attributes.identifier === serverId)?.attributes?.name || serverId;
        const { items, page: p, totalPages } = paginateList(allocs, 0, PER_PAGE.network);
        return interaction.editReply(withPagination(E.allocationList(items, sName, p, totalPages, allocs.length), [], 'network', p, totalPages, serverId));
      }
      if (sub === 'add') { const a = await ptero.assignAllocation(panelUrl, apiKey, serverId); return interaction.editReply({ embeds: [E.success('Allocation Added', `> 📡 **${a.ip}:${a.port}** added.`)] }); }
      if (sub === 'remove') { await ptero.removeAllocation(panelUrl, apiKey, serverId, interaction.options.getString('allocid')); return interaction.editReply({ embeds: [E.success('Allocation Removed', '> ❌ Removed.')] }); }
      if (sub === 'primary') { await ptero.setPrimaryAllocation(panelUrl, apiKey, serverId, interaction.options.getString('allocid')); return interaction.editReply({ embeds: [E.success('Primary Set', '> ⭐ Set as primary allocation.')] }); }
      if (sub === 'status') {
        const allocs = await ptero.listAllocations(panelUrl, apiKey, serverId);
        const primary = allocs.find(a => a.attributes.is_default) || allocs[0];
        if (!primary) return interaction.editReply({ embeds: [E.warning('No Allocations', '> No allocations found for this server.')] });
        const a = primary.attributes;
        return interaction.editReply({ embeds: [E.info(`🌐 Network Status — \`${serverId}\``, [
          `> 🌍 **Primary IP:** \`${a.ip}\``,
          `> 🔌 **Port:** \`${a.port}\``,
          `> 🔗 **Address:** \`${a.ip_alias || a.ip}:${a.port}\``,
          `> 📡 **Total Allocations:** \`${allocs.length}\``,
        ].join('\n'))] });
      }
    }

    // ── ADMIN GROUP ───────────────────────────────────────────
    if (group === 'admin') {
      if (sub === 'servers') {
        const s = await ptero.appListServers(panelUrl, apiKey);
        const { items, page: p, totalPages } = paginateList(s, 0, PER_PAGE.adminservers);
        return interaction.editReply(withPagination(E.adminServerList(items, p, totalPages, s.length), [], 'adminservers', p, totalPages));
      }
      if (sub === 'users') {
        const u = await ptero.appListUsers(panelUrl, apiKey);
        const { items, page: p, totalPages } = paginateList(u, 0, PER_PAGE.adminusers);
        return interaction.editReply(withPagination(E.adminUserList(items, p, totalPages, u.length), [], 'adminusers', p, totalPages));
      }
      if (sub === 'nodes') {
        const n = await ptero.appListNodes(panelUrl, apiKey);
        const { items, page: p, totalPages } = paginateList(n, 0, PER_PAGE.adminnodes);
        return interaction.editReply(withPagination(E.adminNodeList(items, p, totalPages, n.length), [], 'adminnodes', p, totalPages));
      }
      if (sub === 'locations') { const l = await ptero.appListLocations(panelUrl, apiKey); return interaction.editReply({ embeds: [E.info(`Locations (${l.length})`, l.map(x => `> 📍 \`${x.attributes.id}\` — **${x.attributes.short}**`).join('\n') || '> None found.')] }); }
      if (sub === 'nests') { const n = await ptero.appListNests(panelUrl, apiKey); return interaction.editReply({ embeds: [E.info(`Nests (${n.length})`, n.map(x => `> 🥚 \`${x.attributes.id}\` — **${x.attributes.name}**`).join('\n') || '> None found.')] }); }
      if (sub === 'eggs') { const e = await ptero.appListEggs(panelUrl, apiKey, interaction.options.getInteger('nestid')); return interaction.editReply({ embeds: [E.info(`Eggs (${e.length})`, e.map(x => `> 🦕 \`${x.attributes.id}\` — **${x.attributes.name}**`).join('\n') || '> None found.')] }); }
      if (sub === 'suspend' || sub === 'unsuspend' || sub === 'rebuild' || sub === 'delete-server') {
        if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
        const resolved = await resolveAdminIntId(panelUrl, apiKey, serverId);
        if (!resolved) return interaction.editReply({ embeds: [E.error('Not Found', `> Active server \`${serverId}\` not found via admin API.\n> Check your Application API key.`)] });
        if (sub === 'suspend') { await ptero.appSuspendServer(panelUrl, apiKey, resolved.intId); return interaction.editReply({ embeds: [E.success('Suspended 🔒', `> **${resolved.name}** (\`${serverId}\`) has been suspended.`)] }); }
        if (sub === 'unsuspend') { await ptero.appUnsuspendServer(panelUrl, apiKey, resolved.intId); return interaction.editReply({ embeds: [E.success('Unsuspended 🔓', `> **${resolved.name}** (\`${serverId}\`) has been unsuspended.`)] }); }
        if (sub === 'rebuild') { await ptero.appRebuildServer(panelUrl, apiKey, resolved.intId); return interaction.editReply({ embeds: [E.success('Rebuild Triggered 🔧', `> **${resolved.name}** (\`${serverId}\`) container is rebuilding.`)] }); }
        if (sub === 'delete-server') { await ptero.appDeleteServer(panelUrl, apiKey, resolved.intId, interaction.options.getBoolean('force') || false); return interaction.editReply({ embeds: [E.success('Server Deleted 🗑️', `> **${resolved.name}** (\`${serverId}\`) has been permanently deleted.`)] }); }
      }
      if (sub === 'delete-user') { await ptero.appDeleteUser(panelUrl, apiKey, interaction.options.getInteger('userid')); return interaction.editReply({ embeds: [E.success('User Deleted 🗑️', `> Panel user \`${interaction.options.getInteger('userid')}\` deleted.`)] }); }
      if (sub === 'create-user' || sub === 'create-server' || sub === 'create-node' || sub === 'create-nest' || sub === 'create-egg') return; // handled pre-defer above
      if (sub === 'node-stats') {
        const nodes = await ptero.appListNodes(panelUrl, apiKey);
        return interaction.editReply({ embeds: [E.nodeStatsEmbed(nodes.map(n => ({ attributes: { ...n.attributes, allocated_resources: n.attributes.allocated_resources || {} } })))] });
      }
      if (sub === 'server-info') {
        if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
        const resolved = await resolveAdminIntId(panelUrl, apiKey, serverId);
        if (!resolved) return interaction.editReply({ embeds: [E.error('Not Found', `> Active server \`${serverId}\` not found via admin API.\n> Check your Application API key.`)] });
        const s = await ptero.appGetServer(panelUrl, apiKey, resolved.intId);
        return interaction.editReply({ embeds: [E.info(`🖥️ Server #${s.id} — ${s.name}`, [
          `> 🆔 **Identifier:** \`${s.identifier}\``,
          `> 👤 **Owner User ID:** \`${s.user}\``,
          `> 🌐 **Node:** \`${s.node}\``,
          `> 📦 **Nest:** \`${s.nest}\`  **Egg:** \`${s.egg}\``,
          `> 🧠 **RAM:** \`${s.limits.memory} MB\`  💾 **Disk:** \`${s.limits.disk} MB\`  ⚡ **CPU:** \`${s.limits.cpu}%\``,
          `> 🔒 **Suspended:** ${s.suspended ? 'Yes ⛔' : 'No ✅'}`,
          `> 📅 **Created:** \`${s.created_at || '—'}\``,
        ].join('\n'))] });
      }
      if (sub === 'user-info') {
        const u = await ptero.appGetUser(panelUrl, apiKey, interaction.options.getInteger('userid'));
        return interaction.editReply({ embeds: [E.info(`👤 User #${u.id} — ${u.username}`, [
          `> 📛 **Name:** ${u.first_name} ${u.last_name}`,
          `> 📧 **Email:** \`${u.email}\``,
          `> 👑 **Admin:** ${u.root_admin ? 'Yes 👑' : 'No'}`,
          `> 🔐 **2FA:** ${u.two_factor_enabled ? 'Enabled ✅' : 'Disabled ❌'}`,
          `> 📅 **Created:** \`${u.created_at || '—'}\``,
          `> 🌐 **Language:** \`${u.language || 'en'}\``,
        ].join('\n'))] });
      }
      if (sub === 'node-info') {
        const n = await ptero.appListNodes(panelUrl, apiKey).then(nodes => nodes.find(nd => nd.attributes.id === interaction.options.getInteger('nodeid'))?.attributes);
        if (!n) return interaction.editReply({ embeds: [E.error('Not Found', `> Node not found.`)] });
        return interaction.editReply({ embeds: [E.info(`🌐 Node #${n.id} — ${n.name}`, [
          `> 🌍 **FQDN:** \`${n.fqdn}\``,
          `> 📍 **Location:** \`${n.location_id}\``,
          `> 🧠 **Memory:** \`${n.memory} MB\`  💾 **Disk:** \`${n.disk} MB\``,
          `> 🔌 **Daemon:** \`${n.fqdn}:${n.daemon_listen}\`  SFTP: \`${n.daemon_sftp}\``,
          `> ⚡ **Maintenance:** ${n.maintenance_mode ? 'Yes 🔴' : 'No 🟢'}`,
          `> 🔒 **Scheme:** \`${n.scheme}\``,
        ].join('\n'))] });
      }
      if (sub === 'update-build') {
        if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
        const resolved = await resolveAdminIntId(panelUrl, apiKey, serverId);
        if (!resolved) return interaction.editReply({ embeds: [E.error('Not Found', `> Active server \`${serverId}\` not found via admin API.\n> Check your Application API key.`)] });
        const updated = await ptero.appUpdateServerBuild(panelUrl, apiKey, resolved.intId, {
          memory: interaction.options.getInteger('memory') ?? undefined,
          disk: interaction.options.getInteger('disk') ?? undefined,
          cpu: interaction.options.getInteger('cpu') ?? undefined,
          swap: interaction.options.getInteger('swap') ?? undefined,
          io: interaction.options.getInteger('io') ?? undefined,
        });
        return interaction.editReply({ embeds: [E.success('Build Updated ⚙️', [
          `> **${resolved.name}** (\`${serverId}\`) resource limits updated:`,
          `> 🧠 RAM: \`${updated.limits.memory} MB\`  💾 Disk: \`${updated.limits.disk} MB\`  ⚡ CPU: \`${updated.limits.cpu}%\``,
        ].join('\n'))] });
      }
      if (sub === 'transfer') {
        if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);
        const resolved = await resolveAdminIntId(panelUrl, apiKey, serverId);
        if (!resolved) return interaction.editReply({ embeds: [E.error('Not Found', `> Active server \`${serverId}\` not found via admin API.\n> Check your Application API key.`)] });
        const nodeId = interaction.options.getInteger('nodeid');
        const freeAlloc = await ptero.appGetNodeFreeAllocation(panelUrl, apiKey, nodeId);
        if (!freeAlloc) return interaction.editReply({ embeds: [E.error('No Free Allocation', `> Node \`${nodeId}\` has no free allocations.\n> Add an allocation to the node first.`)] });
        await ptero.appTransferServer(panelUrl, apiKey, resolved.intId, nodeId, freeAlloc.id);
        return interaction.editReply({ embeds: [E.success('Transfer Started 🔄', `> **${resolved.name}** (\`${serverId}\`) is being transferred to node \`${nodeId}\`.\n> This may take a few minutes. Check panel for progress.`)] });
      }
    }

    // ── MINECRAFT GROUP ───────────────────────────────────────
    if (group === 'mc') {
      // mc ping does NOT need an active server — uses external API
      if (sub === 'ping') {
        const ip = interaction.options.getString('ip').trim();
        const axios = require('axios');
        const r = await axios.get(`https://api.mcsrvstat.us/3/${encodeURIComponent(ip)}`, { timeout: 10000 });
        const d = r.data;
        if (!d.online) {
          return interaction.editReply({ embeds: [E.error('Server Offline 🔴', `> **\`${ip}\`** is **offline** or unreachable.\n> Make sure the address is correct and the server is running.`)] });
        }
        const players = d.players ? `\`${d.players.online}/${d.players.max}\`` : '`?`';
        const version = d.version || '—';
        const motd = d.motd?.clean?.[0] || '—';
        return interaction.editReply({ embeds: [E.success(`🟢 ${ip} — Online`, [
          `> 🌐 **IP:** \`${ip}\``,
          `> 🏷️ **Version:** \`${version}\``,
          `> 👥 **Players:** ${players}`,
          `> 📢 **MOTD:** ${motd}`,
          d.players?.list?.length ? `> 🎮 **Online:** ${d.players.list.slice(0,10).map(n=>`\`${n}\``).join(', ')}` : '',
        ].filter(Boolean).join('\n'))] });
      }

      if (!serverId) return handleNoServer(interaction, panelUrl, apiKey, userId);

      if (sub === 'time') {
        const t = interaction.options.getString('time');
        await ptero.sendCommand(panelUrl, apiKey, serverId, `time set ${t}`);
        const emoji = { day: '☀️', night: '🌙', noon: '🌅', midnight: '🌃' }[t] || '🕐';
        return interaction.editReply({ embeds: [E.success('Time Set 🕐', `> ${emoji} In-game time set to **${t}** on \`${serverId}\`.`)] });
      }
      if (sub === 'weather') {
        const w = interaction.options.getString('weather');
        await ptero.sendCommand(panelUrl, apiKey, serverId, `weather ${w}`);
        const emoji = { clear: '☀️', rain: '🌧️', thunder: '⛈️' }[w] || '🌦️';
        return interaction.editReply({ embeds: [E.success('Weather Set 🌦️', `> ${emoji} Weather set to **${w}** on \`${serverId}\`.`)] });
      }

      if (sub === 'gamemode') {
        const gPlayer = interaction.options.getString('player');
        const mode = interaction.options.getString('mode');
        await ptero.sendCommand(panelUrl, apiKey, serverId, `gamemode ${mode} ${gPlayer}`);
        const emoji = { survival: '⚔️', creative: '🎨', adventure: '🗺️', spectator: '👁️' }[mode] || '🎮';
        return interaction.editReply({ embeds: [E.success('Gamemode Set 🎮', `> ${emoji} **${gPlayer}** → \`${mode}\` on \`${serverId}\`.`)] });
      }
      const player = interaction.options.getString('player');
      const cmds = { op: `op ${player}`, deop: `deop ${player}`, ban: `ban ${player}`, kick: `kick ${player}`, pardon: `pardon ${player}`, 'whitelist-add': `whitelist add ${player}`, 'whitelist-remove': `whitelist remove ${player}`, save: 'save-all' };
      const command = cmds[sub];
      await ptero.sendCommand(panelUrl, apiKey, serverId, command);
      return interaction.editReply({ embeds: [E.success('Command Executed', `> ➤ Ran \`${command}\` on \`${serverId}\`.`)] });
    }

  } catch (err) {
    const OFFLINE = ['ECONNREFUSED', 'ETIMEDOUT', 'ENOTFOUND', 'ECONNRESET', 'EHOSTUNREACH', 'ECONNABORTED'];
    const isOffline = OFFLINE.includes(err.code) || (err.message || '').toLowerCase().includes('timeout');
    const title = isOffline ? '🔴 Panel Offline' : 'Panel Error';
    const msg = isOffline
      ? '> Your panel is **offline or unreachable**.\n> Make sure your panel/VPS is running and try again.'
      : `> \`\`\`${err?.response?.data?.errors?.[0]?.detail || err.message || 'Unknown error'}\`\`\``;
    const isRepl = interaction.deferred || interaction.replied;
    const reply = { embeds: [E.error(title, msg)] };
    return isRepl ? interaction.editReply(reply) : interaction.reply({ ...reply, ephemeral: true });
  }
}

// ── HANDLERS ───────────────────────────────────────────────────────────────

async function handleLogin(interaction) {
  const modal = new ModalBuilder().setCustomId('login_modal').setTitle('🦕 McManager — Panel Login');
  modal.addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('panel_url').setLabel('Panel URL').setPlaceholder('https://panel.yourhost.com').setStyle(TextInputStyle.Short).setRequired(true)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('api_key').setLabel('Client API Key').setPlaceholder('ptlc_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx').setStyle(TextInputStyle.Short).setRequired(true))
  );
  await interaction.showModal(modal);
}

async function handlePanelStatus(interaction, panelUrl, apiKey) {
  await interaction.deferReply({ ephemeral: true });
  const result = await ptero.testConnection(panelUrl, apiKey);
  return interaction.editReply({ embeds: [result.ok ? E.success('Panel Online ✅', `> Panel is **online**!\n> \`${panelUrl}\``) : E.error('Panel Offline ❌', `> Cannot reach panel.\n> Error: \`${result.error}\``)] });
}

// ── ADMIN CREATE HANDLERS ────────────────────────────────────────────────────

async function handleAdminCreateUser(interaction) {
  const modal = new ModalBuilder().setCustomId('admin_create_user').setTitle('👤 Create Panel User');
  modal.addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('username').setLabel('Username').setPlaceholder('johndoe').setStyle(TextInputStyle.Short).setRequired(true).setMinLength(1).setMaxLength(32)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('email').setLabel('Email Address').setPlaceholder('john@example.com').setStyle(TextInputStyle.Short).setRequired(true)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('password').setLabel('Password').setPlaceholder('SecurePassword123!').setStyle(TextInputStyle.Short).setRequired(true).setMinLength(8)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('first_name').setLabel('First Name').setPlaceholder('John').setStyle(TextInputStyle.Short).setRequired(true)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('last_name').setLabel('Last Name').setPlaceholder('Doe').setStyle(TextInputStyle.Short).setRequired(true)),
  );
  await interaction.showModal(modal);
}

async function handleAdminCreateServer(interaction, panelUrl, apiKey, userId) {
  createServerState.set(userId, { panelUrl, apiKey, step: 1 });
  const modal = new ModalBuilder().setCustomId('admin_create_server_step1').setTitle('🖥️ Create Server (Step 1/3)');
  modal.addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('name').setLabel('Server Name').setPlaceholder('My Minecraft Server').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(200)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('owner_email').setLabel('Owner Email (panel user email)').setPlaceholder('owner@example.com').setStyle(TextInputStyle.Short).setRequired(true)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('memory').setLabel('Memory (MB) — e.g. 2048').setPlaceholder('2048').setStyle(TextInputStyle.Short).setRequired(true)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('disk').setLabel('Disk (MB) — e.g. 10240').setPlaceholder('10240').setStyle(TextInputStyle.Short).setRequired(true)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('nest_egg').setLabel('Nest ID : Egg ID (e.g. 1:3)').setPlaceholder('1:3').setStyle(TextInputStyle.Short).setRequired(true)),
  );
  await interaction.showModal(modal);
}

async function handleAdminCreateNest(interaction) {
  const modal = new ModalBuilder().setCustomId('admin_create_nest').setTitle('🥚 Create Nest');
  modal.addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('name').setLabel('Nest Name').setPlaceholder('Minecraft').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(100)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('description').setLabel('Description (optional)').setPlaceholder('Official Minecraft eggs').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(255)),
  );
  await interaction.showModal(modal);
}

async function handleAdminCreateEgg(interaction) {
  const modal = new ModalBuilder().setCustomId('admin_create_egg').setTitle('🦕 Create Egg');
  modal.addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('nest_id').setLabel('Nest ID (integer)').setPlaceholder('1').setStyle(TextInputStyle.Short).setRequired(true)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('name').setLabel('Egg Name').setPlaceholder('Vanilla Minecraft').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(100)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('docker_image').setLabel('Docker Image').setPlaceholder('ghcr.io/pterodactyl/yolks:java_21').setStyle(TextInputStyle.Short).setRequired(true)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('startup').setLabel('Startup Command').setPlaceholder('java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar server.jar').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(500)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('description').setLabel('Description (optional)').setPlaceholder('Vanilla Minecraft server').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(255)),
  );
  await interaction.showModal(modal);
}

async function handleAdminCreateNode(interaction) {
  const modal = new ModalBuilder().setCustomId('admin_create_node').setTitle('🌐 Create Node');
  modal.addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('name').setLabel('Node Name').setPlaceholder('Node-US-1').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(100)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('location_id').setLabel('Location ID (integer)').setPlaceholder('1').setStyle(TextInputStyle.Short).setRequired(true)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('fqdn').setLabel('FQDN / IP Address').setPlaceholder('node1.yourhost.com').setStyle(TextInputStyle.Short).setRequired(true)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('memory').setLabel('Memory (MB) — e.g. 8192').setPlaceholder('8192').setStyle(TextInputStyle.Short).setRequired(true)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('disk').setLabel('Disk (MB) — e.g. 51200').setPlaceholder('51200').setStyle(TextInputStyle.Short).setRequired(true)),
  );
  await interaction.showModal(modal);
}

// ── PAGINATION HELPERS ──────────────────────────────────────────────────────

const PER_PAGE = {
  serverlist: 8, manage: 25, files: 20, backup: 6,
  db: 8, schedule: 6, subuser: 8, network: 10,
  adminservers: 8, adminusers: 8, adminnodes: 8,
};

async function resolveAdminIntId(panelUrl, apiKey, identifier) {
  const servers = await ptero.appListServers(panelUrl, apiKey);
  const match = servers.find(s => s.attributes.identifier === identifier);
  return match ? { intId: match.attributes.id, name: match.attributes.name } : null;
}

function paginateList(list, page, perPage) {
  const total = list.length;
  const totalPages = Math.max(1, Math.ceil(total / perPage));
  const safePage = Math.max(0, Math.min(page, totalPages - 1));
  const items = list.slice(safePage * perPage, (safePage + 1) * perPage);
  return { items, page: safePage, totalPages, total };
}

function buildPageRow(type, page, totalPages, extraId = '') {
  const id = extraId ? `${extraId}` : '';
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`pg_${type}_${page - 1}_${id}`)
      .setLabel('◀ Prev')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page === 0),
    new ButtonBuilder()
      .setCustomId(`pg_${type}_info_${id}`)
      .setLabel(`Page ${page + 1} / ${totalPages}`)
      .setStyle(ButtonStyle.Primary)
      .setDisabled(true),
    new ButtonBuilder()
      .setCustomId(`pg_${type}_${page + 1}_${id}`)
      .setLabel('Next ▶')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page >= totalPages - 1),
  );
}

function withPagination(embed, components, type, page, totalPages, extraId) {
  const rows = components ? (Array.isArray(components) ? [...components] : [components]) : [];
  if (totalPages > 1) rows.push(buildPageRow(type, page, totalPages, extraId));
  return { embeds: [embed], components: rows };
}

// ── SERVER LIST ─────────────────────────────────────────────────────────────

async function handleServers(interaction, panelUrl, apiKey, userId, page = 0) {
  const servers = await ptero.listServers(panelUrl, apiKey);
  if (!servers || servers.length === 0) {
    return interaction.editReply({
      embeds: [E.warning('No Servers Found', [
        '> 📭 No servers found on your panel.',
        '',
        '**Possible reasons:**',
        '> • No servers assigned to your account',
        '> • API key has no server access',
        '> • Contact your panel admin',
        '',
        '> Try `/mcmanager admin servers` if you have an Application API key.',
      ].join('\n'))],
    });
  }
  const { items, page: p, totalPages } = paginateList(servers, page, PER_PAGE.serverlist);
  const selectRow = E.serverSelectMenuPage(items, servers.length);
  return interaction.editReply(withPagination(E.serverList(items, p, totalPages, servers.length), [selectRow], 'serverlist', p, totalPages));
}

const PAGE_SIZE = 25;

function buildServerPage(servers, page, selectedId) {
  const totalPages = Math.ceil(servers.length / PAGE_SIZE);
  const safePage = Math.max(0, Math.min(page, totalPages - 1));
  const pageServers = servers.slice(safePage * PAGE_SIZE, (safePage + 1) * PAGE_SIZE);

  const statusEmoji = (s) => {
    const st = s.attributes?.status;
    if (st === 'running') return '🟢';
    if (st === 'offline' || st === 'stopped') return '🔴';
    return '🟡';
  };

  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId('server_select')
    .setPlaceholder(`🖥️ Choose a server to manage... (${servers.length} total)`)
    .addOptions(pageServers.map(s => {
      const attr = s.attributes;
      const opt = {
        label: attr.name.slice(0, 100),
        description: `${statusEmoji(s)} ${attr.status || 'unknown'} | ID: ${attr.identifier}`.slice(0, 100),
        value: attr.identifier,
      };
      if (attr.identifier === selectedId) opt.default = true;
      return opt;
    }));

  const components = [new ActionRowBuilder().addComponents(selectMenu)];

  if (totalPages > 1) {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`manage_page_${safePage - 1}`)
        .setLabel('◀ Previous')
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(safePage === 0),
      new ButtonBuilder()
        .setCustomId('manage_page_info')
        .setLabel(`Page ${safePage + 1} / ${totalPages}`)
        .setStyle(ButtonStyle.Primary)
        .setDisabled(true),
      new ButtonBuilder()
        .setCustomId(`manage_page_${safePage + 1}`)
        .setLabel('Next ▶')
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(safePage >= totalPages - 1),
    );
    components.push(row);
  }

  const embed = E.info(
    '🎛️ Server Manager',
    [
      `> Select a server from the dropdown below to set it as your **active server**.`,
      `> Currently active: ${selectedId ? `\`${selectedId}\`` : '**None** (not selected)'}`,
      totalPages > 1
        ? `> Showing page **${safePage + 1}** of **${totalPages}** — **${servers.length}** servers total`
        : `> **${servers.length}** server(s) found`,
    ].join('\n'),
  );

  return { embeds: [embed], components };
}

async function handleManage(interaction, panelUrl, apiKey, userId) {
  const servers = await ptero.listServers(panelUrl, apiKey);
  if (!servers || servers.length === 0) {
    return interaction.editReply({ embeds: [E.warning('No Servers', '> 📭 No servers found on this panel.\n> Check your API key or contact your admin.')] });
  }
  const selected = store.getSelectedServer(userId);
  return interaction.editReply(buildServerPage(servers, 0, selected));
}

async function handleNoServer(interaction, panelUrl, apiKey, userId) {
  try {
    const servers = await ptero.listServers(panelUrl, apiKey);
    if (!servers || servers.length === 0) {
      return interaction.editReply({ embeds: [E.warning('No Servers', '> 📭 No servers on this panel. Check your API key or contact admin.')] });
    }
    return interaction.editReply({ embeds: [E.info('🖥️ No Active Server', '> Pick your server from the dropdown below.\n> It will be set as your active server automatically.')], components: [E.serverSelectMenu(servers)] });
  } catch (err) {
    return interaction.editReply({ embeds: [E.error('Error', `> \`${err.message}\``)] });
  }
}

async function handleStatus(interaction, panelUrl, apiKey, serverId) {
  const [servers, resources] = await Promise.all([ptero.listServers(panelUrl, apiKey), ptero.getServerResources(panelUrl, apiKey, serverId)]);
  const server = servers.find(s => s.attributes.identifier === serverId);
  if (!server) return interaction.editReply({ embeds: [E.error('Not Found', `> No server with ID \`${serverId}\``)] });
  const components = [E.powerButtons(serverId), E.serverActionButtons(serverId)];
  if (servers.length > 1) components.push(E.serverInlineSwitcher(servers, serverId));
  return interaction.editReply({ embeds: [E.serverStatus(server, resources)], components });
}

async function handlePower(interaction, panelUrl, apiKey, serverId, signal) {
  await ptero.sendPowerAction(panelUrl, apiKey, serverId, signal);
  const labels = { start: '▶️ Starting', stop: '⏹️ Stopping', restart: '🔄 Restarting', kill: '💀 Killed' };
  return interaction.editReply({ embeds: [E.success(`Server ${labels[signal]}`, `> Signal **${signal.toUpperCase()}** sent to \`${serverId}\`.`)] });
}

// handleWrite is now handled pre-defer via showModal() in execute()
// This stub is kept for reference only — never called
async function handleWrite() {}

async function handleBulkPower(interaction, panelUrl, apiKey, signal) {
  const servers = await ptero.listServers(panelUrl, apiKey);
  if (!servers || servers.length === 0) return interaction.editReply({ embeds: [E.warning('No Servers', '> No servers found.')] });
  let done = 0, failed = 0;
  for (const s of servers) { try { await ptero.sendPowerAction(panelUrl, apiKey, s.attributes.identifier, signal); done++; } catch { failed++; } }
  return interaction.editReply({ embeds: [E.success(`Bulk ${signal} Done`, `> ⚡ **${signal.toUpperCase()}** sent to **${done}** servers.\n> ❌ Failed: **${failed}**`)] });
}

// ── MODAL HANDLER ──────────────────────────────────────────────────────────

async function handleModal(interaction) {
  if (interaction.customId === 'login_modal') {
    const panelUrl = interaction.fields.getTextInputValue('panel_url').trim().replace(/\/$/, '');
    const apiKey = interaction.fields.getTextInputValue('api_key').trim();
    await interaction.deferReply({ ephemeral: true });
    const result = await ptero.testConnection(panelUrl, apiKey);
    if (!result.ok) {
      return interaction.editReply({
        embeds: [E.error('Login Failed ❌', [
          '> Could not connect to your panel.',
          `> **Error:** \`${result.error}\``,
          '',
          '**Check:**',
          '> • Panel URL starts with `https://`',
          '> • API key is a **Client API key** (not Application)',
          '> • Panel is online',
          '> • Key is not expired',
        ].join('\n'))]
      });
    }
    store.setUser(interaction.user.id, { panelUrl, apiKey });
    return interaction.editReply({ embeds: [E.loginSuccess(panelUrl)] });
  }

  if (interaction.customId.startsWith('write_file:')) {
    const raw = interaction.customId.slice('write_file:'.length);
    const colonIdx = raw.indexOf(':');
    const serverId = raw.slice(0, colonIdx);
    const filePath = decodeURIComponent(raw.slice(colonIdx + 1));
    const content = interaction.fields.getTextInputValue('file_content');
    await interaction.deferReply({ ephemeral: true });
    const creds = store.resolveCredentials(interaction.user.id);
    if (!creds) return interaction.editReply({ embeds: [E.notLoggedIn()] });
    await ptero.writeFileContents(creds.panelUrl, creds.apiKey, serverId, filePath, content);
    return interaction.editReply({ embeds: [E.success('File Saved ✅', `> \`${filePath}\` saved to server \`${serverId}\`.`)] });
  }

  // ── ADMIN CREATE USER ────────────────────────────────────
  if (interaction.customId === 'admin_create_user') {
    await interaction.deferReply({ ephemeral: true });
    const creds = store.resolveCredentials(interaction.user.id);
    if (!creds) return interaction.editReply({ embeds: [E.notLoggedIn()] });
    try {
      const user = await ptero.appCreateUser(creds.panelUrl, creds.apiKey, {
        username: interaction.fields.getTextInputValue('username'),
        email: interaction.fields.getTextInputValue('email'),
        password: interaction.fields.getTextInputValue('password'),
        first_name: interaction.fields.getTextInputValue('first_name'),
        last_name: interaction.fields.getTextInputValue('last_name'),
        root_admin: false,
        language: 'en',
      });
      return interaction.editReply({ embeds: [E.adminCreateUserSuccess(user)] });
    } catch (err) {
      const msg = err?.response?.data?.errors?.[0]?.detail || err.message;
      return interaction.editReply({ embeds: [E.error('Create User Failed', `> \`\`\`${msg}\`\`\``)] });
    }
  }

  // ── ADMIN CREATE SERVER (step 1 modal) ───────────────────
  if (interaction.customId === 'admin_create_server_step1') {
    await interaction.deferReply({ ephemeral: true });
    const userId = interaction.user.id;
    const creds = store.resolveCredentials(userId);
    if (!creds) return interaction.editReply({ embeds: [E.notLoggedIn()] });
    try {
      const name = interaction.fields.getTextInputValue('name');
      const ownerEmail = interaction.fields.getTextInputValue('owner_email');
      const memory = parseInt(interaction.fields.getTextInputValue('memory'), 10);
      const disk = parseInt(interaction.fields.getTextInputValue('disk'), 10);
      const nestEgg = interaction.fields.getTextInputValue('nest_egg').trim();
      const [nestIdStr, eggIdStr] = nestEgg.split(':');
      const nestId = parseInt(nestIdStr, 10);
      const eggId = parseInt(eggIdStr, 10);

      if (isNaN(memory) || isNaN(disk) || isNaN(nestId) || isNaN(eggId)) {
        return interaction.editReply({ embeds: [E.error('Invalid Input', '> Memory, disk, nest ID, and egg ID must be numbers.\n> Nest/Egg format: `1:3` (nestId:eggId)')] });
      }

      // Fetch egg info for docker image and startup
      const [egg, users, nodes] = await Promise.all([
        ptero.appGetEgg(creds.panelUrl, creds.apiKey, nestId, eggId),
        ptero.appListUsers(creds.panelUrl, creds.apiKey),
        ptero.appListNodes(creds.panelUrl, creds.apiKey),
      ]);

      const ownerUser = users.find(u => u.attributes.email === ownerEmail);
      if (!ownerUser) return interaction.editReply({ embeds: [E.error('User Not Found', `> No panel user with email \`${ownerEmail}\`.\n> Use \`/mcmanager admin users\` to see emails.`)] });

      if (!nodes || nodes.length === 0) return interaction.editReply({ embeds: [E.error('No Nodes', '> No nodes found on this panel. Create a node first.')] });

      // Find first node with a free allocation
      let allocationId = null;
      let nodeId = null;
      for (const node of nodes) {
        const alloc = await ptero.appGetNodeFreeAllocation(creds.panelUrl, creds.apiKey, node.attributes.id);
        if (alloc) { allocationId = alloc.id; nodeId = node.attributes.id; break; }
      }
      if (!allocationId) return interaction.editReply({ embeds: [E.error('No Free Allocation', '> All allocations are in use.\n> Add a new allocation to a node first.')] });

      const environment = {};
      if (egg.relationships?.variables?.data) {
        for (const v of egg.relationships.variables.data) {
          environment[v.attributes.env_variable] = v.attributes.default_value || '';
        }
      }

      const serverData = {
        name,
        user: ownerUser.attributes.id,
        egg: eggId,
        docker_image: egg.docker_image,
        startup: egg.startup,
        environment,
        limits: { memory, swap: 0, disk, io: 500, cpu: 0 },
        feature_limits: { databases: 5, backups: 3, allocations: 1 },
        allocation: { default: allocationId },
      };

      const server = await ptero.appCreateServer(creds.panelUrl, creds.apiKey, serverData);
      return interaction.editReply({ embeds: [E.adminCreateServerSuccess(server)] });
    } catch (err) {
      const msg = err?.response?.data?.errors?.[0]?.detail || err.message;
      return interaction.editReply({ embeds: [E.error('Create Server Failed', `> \`\`\`${msg}\`\`\``)] });
    }
  }

  // ── ADMIN CREATE NODE ─────────────────────────────────────
  if (interaction.customId === 'admin_create_node') {
    await interaction.deferReply({ ephemeral: true });
    const creds = store.resolveCredentials(interaction.user.id);
    if (!creds) return interaction.editReply({ embeds: [E.notLoggedIn()] });
    try {
      const name = interaction.fields.getTextInputValue('name');
      const locationId = parseInt(interaction.fields.getTextInputValue('location_id'), 10);
      const fqdn = interaction.fields.getTextInputValue('fqdn');
      const memory = parseInt(interaction.fields.getTextInputValue('memory'), 10);
      const disk = parseInt(interaction.fields.getTextInputValue('disk'), 10);

      if (isNaN(locationId) || isNaN(memory) || isNaN(disk)) {
        return interaction.editReply({ embeds: [E.error('Invalid Input', '> Location ID, memory, and disk must be numbers.')] });
      }

      const node = await ptero.appCreateNode(creds.panelUrl, creds.apiKey, {
        name,
        location_id: locationId,
        fqdn,
        scheme: 'https',
        memory,
        memory_overallocate: 0,
        disk,
        disk_overallocate: 0,
        upload_size: 100,
        daemon_listen: 8080,
        daemon_sftp: 2022,
        behind_proxy: false,
        maintenance_mode: false,
        throttle: { enabled: false },
      });
      return interaction.editReply({ embeds: [E.adminCreateNodeSuccess(node)] });
    } catch (err) {
      const msg = err?.response?.data?.errors?.[0]?.detail || err.message;
      return interaction.editReply({ embeds: [E.error('Create Node Failed', `> \`\`\`${msg}\`\`\``)] });
    }
  }

  // ── ADMIN CREATE NEST ─────────────────────────────────────
  if (interaction.customId === 'admin_create_nest') {
    await interaction.deferReply({ ephemeral: true });
    const creds = store.resolveCredentials(interaction.user.id);
    if (!creds) return interaction.editReply({ embeds: [E.notLoggedIn()] });
    try {
      const nest = await ptero.appCreateNest(creds.panelUrl, creds.apiKey, {
        name: interaction.fields.getTextInputValue('name'),
        description: interaction.fields.getTextInputValue('description') || '',
      });
      return interaction.editReply({ embeds: [E.success('Nest Created 🥚', [
        `> ✅ Nest **${nest.name || nest.id}** created successfully!`,
        `> 🆔 **Nest ID:** \`${nest.id}\``,
        `> 📝 **Description:** ${nest.description || '—'}`,
        `> Use this ID in \`/mcmanager admin create-egg\` to add eggs.`,
      ].join('\n'))] });
    } catch (err) {
      const msg = err?.response?.data?.errors?.[0]?.detail || err.message;
      const is404 = err?.response?.status === 404 || err?.response?.status === 405;
      return interaction.editReply({ embeds: [E.error('Create Nest Failed', is404
        ? '> ❌ Your panel version does not support creating nests via API.\n> Please create nests directly from the panel web UI.'
        : `> \`\`\`${msg}\`\`\``)] });
    }
  }

  // ── ADMIN CREATE EGG ──────────────────────────────────────
  if (interaction.customId === 'admin_create_egg') {
    await interaction.deferReply({ ephemeral: true });
    const creds = store.resolveCredentials(interaction.user.id);
    if (!creds) return interaction.editReply({ embeds: [E.notLoggedIn()] });
    try {
      const nestId = parseInt(interaction.fields.getTextInputValue('nest_id'), 10);
      if (isNaN(nestId)) return interaction.editReply({ embeds: [E.error('Invalid Input', '> Nest ID must be a number.')] });
      const egg = await ptero.appCreateEgg(creds.panelUrl, creds.apiKey, nestId, {
        name: interaction.fields.getTextInputValue('name'),
        description: interaction.fields.getTextInputValue('description') || '',
        dockerImage: interaction.fields.getTextInputValue('docker_image'),
        startup: interaction.fields.getTextInputValue('startup'),
      });
      return interaction.editReply({ embeds: [E.success('Egg Created 🦕', [
        `> ✅ Egg **${egg.name || egg.id}** created in Nest \`${nestId}\`!`,
        `> 🆔 **Egg ID:** \`${egg.id}\``,
        `> 🐳 **Docker Image:** \`${egg.docker_image || '—'}\``,
        `> 🚀 **Startup:** \`${String(egg.startup || '—').slice(0, 80)}\``,
        `> Use this in \`/mcmanager admin create-server\` with Nest \`${nestId}\` Egg \`${egg.id}\`.`,
      ].join('\n'))] });
    } catch (err) {
      const msg = err?.response?.data?.errors?.[0]?.detail || err.message;
      const is404 = err?.response?.status === 404 || err?.response?.status === 405;
      return interaction.editReply({ embeds: [E.error('Create Egg Failed', is404
        ? '> ❌ Your panel version does not support creating eggs via API.\n> Please import eggs directly from the panel web UI (Admin → Nests → Import Egg).'
        : `> \`\`\`${msg}\`\`\``)] });
    }
  }

  // ── CONSOLE SEND COMMAND (from modal) ──────────────────────
  if (interaction.customId.startsWith('console_send_cmd:')) {
    const sid = interaction.customId.split(':')[1];
    const command = interaction.fields.getTextInputValue('command');
    await interaction.deferReply({ ephemeral: true });
    const creds = store.resolveCredentials(interaction.user.id);
    if (!creds) return interaction.editReply({ embeds: [E.notLoggedIn()] });
    try {
      await ptero.sendCommand(creds.panelUrl, creds.apiKey, sid, command);
      return interaction.editReply({ embeds: [E.success('Command Sent ✅', `> 📤 Sent to \`${sid}\`:\n> \`\`\`${command}\`\`\``)] });
    } catch (err) {
      return interaction.editReply({ embeds: [E.error('Command Failed', `> \`${err.message}\``)] });
    }
  }

  // ── CONSOLE SAY MESSAGE (from modal) ──────────────────────
  if (interaction.customId.startsWith('console_send_say:')) {
    const sid = interaction.customId.split(':')[1];
    const message = interaction.fields.getTextInputValue('message');
    await interaction.deferReply({ ephemeral: true });
    const creds = store.resolveCredentials(interaction.user.id);
    if (!creds) return interaction.editReply({ embeds: [E.notLoggedIn()] });
    try {
      await ptero.sendCommand(creds.panelUrl, creds.apiKey, sid, `say ${message}`);
      return interaction.editReply({ embeds: [E.success('Message Broadcast ✅', `> 💬 Sent in-game:\n> **"${message}"**`)] });
    } catch (err) {
      return interaction.editReply({ embeds: [E.error('Say Failed', `> \`${err.message}\``)] });
    }
  }
}

// ── BUTTON HANDLER ─────────────────────────────────────────────────────────

async function handleButton(interaction) {
  const userId = interaction.user.id;
  const cid = interaction.customId;

  const creds = store.resolveCredentials(userId);
  if (!creds) return interaction.reply({ embeds: [E.notLoggedIn()], ephemeral: true });
  const { panelUrl, apiKey } = creds;

  // ── CONSOLE BUTTONS — must NOT defer, show modal or reply directly ──
  if (cid.startsWith('console_')) {
    const parts = cid.split('_'); // ['console', 'cmd'/'say'/'logs'/'<id>']
    // console_cmd_{serverId}
    if (parts[1] === 'cmd') {
      const sid = parts.slice(2).join('_');
      const modal = new ModalBuilder().setCustomId(`console_send_cmd:${sid}`).setTitle(`📤 Send Command — ${sid}`);
      modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('command').setLabel('Server Command').setPlaceholder('say Hello! / give player diamond 64 / etc').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(512)));
      return interaction.showModal(modal);
    }
    // console_say_{serverId}
    if (parts[1] === 'say') {
      const sid = parts.slice(2).join('_');
      const modal = new ModalBuilder().setCustomId(`console_send_say:${sid}`).setTitle(`💬 Broadcast Message — ${sid}`);
      modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('message').setLabel('In-game Message').setPlaceholder('Hello everyone!').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(256)));
      return interaction.showModal(modal);
    }
    // console_logs_{serverId}
    if (parts[1] === 'logs') {
      const sid = parts.slice(2).join('_');
      await interaction.deferReply({ ephemeral: true });
      try {
        const logs = await ptero.getConsoleOutput(panelUrl, apiKey, sid);
        const lines = Array.isArray(logs) ? logs.slice(-20).join('\n') : String(logs).slice(-2000);
        return interaction.editReply({ embeds: [E.info(`📜 Console Logs — \`${sid}\``, `\`\`\`\n${lines.slice(0, 3900) || 'No output.'}\n\`\`\``)] });
      } catch (err) {
        return interaction.editReply({ embeds: [E.error('Logs Error', `> \`${err.message}\``)] });
      }
    }
    // console_{serverId} — show console panel
    const sid = parts.slice(1).join('_');
    return interaction.reply({ embeds: [E.consolePanelEmbed(sid)], components: [E.consolePanelButtons(sid)], ephemeral: true });
  }

  // ── SWITCH SERVER BUTTON (inline server switcher) ────────
  if (cid === 'switch_server') {
    await interaction.deferUpdate();
    try {
      const servers = await ptero.listServers(panelUrl, apiKey);
      const selected = store.getSelectedServer(userId);
      return interaction.editReply(buildServerPage(servers, 0, selected));
    } catch (err) {
      return interaction.editReply({ embeds: [E.error('Error', `> \`${err.message}\``)], components: [] });
    }
  }

  // ── MANAGE PAGE BUTTONS (must use deferUpdate) ───────────
  if (cid.startsWith('manage_page_')) {
    const pageStr = cid.replace('manage_page_', '');
    if (pageStr === 'info') return interaction.deferUpdate();
    const page = parseInt(pageStr, 10);
    if (isNaN(page)) return interaction.deferUpdate();
    await interaction.deferUpdate();
    try {
      const servers = await ptero.listServers(panelUrl, apiKey);
      const selected = store.getSelectedServer(userId);
      return interaction.editReply(buildServerPage(servers, page, selected));
    } catch (err) {
      return interaction.editReply({ embeds: [E.error('Error', `> \`${err.message}\``)], components: [] });
    }
  }

  await interaction.deferReply({ ephemeral: true });

  try {
    // ── POWER BUTTONS ────────────────────────────────────────
    if (cid.startsWith('power_')) {
      const parts = cid.split('_'); const signal = parts[1]; const sid = parts.slice(2).join('_');
      await ptero.sendPowerAction(panelUrl, apiKey, sid, signal);
      return interaction.editReply({ embeds: [E.success('Signal Sent', `> ⚡ **${signal.toUpperCase()}** sent to \`${sid}\`.`)] });
    }

    // ── STATUS / FILES / BACKUPS QUICK BUTTONS ───────────────
    if (cid.startsWith('status_')) {
      const sid = cid.replace('status_', '');
      const [servers, resources] = await Promise.all([ptero.listServers(panelUrl, apiKey), ptero.getServerResources(panelUrl, apiKey, sid)]);
      const server = servers.find(s => s.attributes.identifier === sid);
      return interaction.editReply({ embeds: [E.serverStatus(server, resources)] });
    }
    if (cid.startsWith('files_')) {
      const sid = cid.replace('files_', '');
      const [servers, files] = await Promise.all([ptero.listServers(panelUrl, apiKey), ptero.listFiles(panelUrl, apiKey, sid, '/')]);
      const sName = servers.find(s => s.attributes.identifier === sid)?.attributes?.name || sid;
      const { items, page: p, totalPages } = paginateList(files, 0, PER_PAGE.files);
      return interaction.editReply(withPagination(E.fileList(items, '/', sName, p, totalPages, files.length), [], 'files', p, totalPages, sid));
    }
    if (cid.startsWith('backups_')) {
      const sid = cid.replace('backups_', '');
      const [servers, backups] = await Promise.all([ptero.listServers(panelUrl, apiKey), ptero.listBackups(panelUrl, apiKey, sid)]);
      const sName = servers.find(s => s.attributes.identifier === sid)?.attributes?.name || sid;
      const { items, page: p, totalPages } = paginateList(backups, 0, PER_PAGE.backup);
      return interaction.editReply(withPagination(E.backupList(items, sName, p, totalPages, backups.length), [], 'backup', p, totalPages, sid));
    }

    // ── PAGINATION BUTTONS ───────────────────────────────────
    // Format: pg_{type}_{page}_{serverId}
    if (cid.startsWith('pg_')) {
      const parts = cid.split('_');
      // pg_ prefix = parts[0]='pg', type=parts[1], page=parts[2], rest=serverId
      const type = parts[1];
      const pageStr = parts[2];
      if (pageStr === 'info') return; // disabled info button, do nothing
      const page = parseInt(pageStr, 10);
      if (isNaN(page)) return;
      const serverId = parts.slice(3).join('_') || null;

      if (type === 'manage') {
        const servers = await ptero.listServers(panelUrl, apiKey);
        const selected = store.getSelectedServer(userId);
        return interaction.editReply(buildServerPage(servers, page, selected));
      }

      if (type === 'serverlist') {
        const servers = await ptero.listServers(panelUrl, apiKey);
        const { items, page: p, totalPages } = paginateList(servers, page, PER_PAGE.serverlist);
        const selectRow = E.serverSelectMenuPage(items, servers.length);
        return interaction.editReply(withPagination(E.serverList(items, p, totalPages, servers.length), [selectRow], 'serverlist', p, totalPages));
      }

      if (type === 'files' && serverId) {
        const [servers, files] = await Promise.all([ptero.listServers(panelUrl, apiKey), ptero.listFiles(panelUrl, apiKey, serverId, '/')]);
        const sName = servers.find(s => s.attributes.identifier === serverId)?.attributes?.name || serverId;
        const { items, page: p, totalPages } = paginateList(files, page, PER_PAGE.files);
        return interaction.editReply(withPagination(E.fileList(items, '/', sName, p, totalPages, files.length), [], 'files', p, totalPages, serverId));
      }

      if (type === 'backup' && serverId) {
        const [servers, backups] = await Promise.all([ptero.listServers(panelUrl, apiKey), ptero.listBackups(panelUrl, apiKey, serverId)]);
        const sName = servers.find(s => s.attributes.identifier === serverId)?.attributes?.name || serverId;
        const { items, page: p, totalPages } = paginateList(backups, page, PER_PAGE.backup);
        return interaction.editReply(withPagination(E.backupList(items, sName, p, totalPages, backups.length), [], 'backup', p, totalPages, serverId));
      }

      if (type === 'db' && serverId) {
        const [servers, dbs] = await Promise.all([ptero.listServers(panelUrl, apiKey), ptero.listDatabases(panelUrl, apiKey, serverId)]);
        const sName = servers.find(s => s.attributes.identifier === serverId)?.attributes?.name || serverId;
        const { items, page: p, totalPages } = paginateList(dbs, page, PER_PAGE.db);
        return interaction.editReply(withPagination(E.databaseList(items, sName, p, totalPages, dbs.length), [], 'db', p, totalPages, serverId));
      }

      if (type === 'schedule' && serverId) {
        const [servers, scheds] = await Promise.all([ptero.listServers(panelUrl, apiKey), ptero.listSchedules(panelUrl, apiKey, serverId)]);
        const sName = servers.find(s => s.attributes.identifier === serverId)?.attributes?.name || serverId;
        const { items, page: p, totalPages } = paginateList(scheds, page, PER_PAGE.schedule);
        return interaction.editReply(withPagination(E.scheduleList(items, sName, p, totalPages, scheds.length), [], 'schedule', p, totalPages, serverId));
      }

      if (type === 'subuser' && serverId) {
        const [servers, users] = await Promise.all([ptero.listServers(panelUrl, apiKey), ptero.listSubusers(panelUrl, apiKey, serverId)]);
        const sName = servers.find(s => s.attributes.identifier === serverId)?.attributes?.name || serverId;
        const { items, page: p, totalPages } = paginateList(users, page, PER_PAGE.subuser);
        return interaction.editReply(withPagination(E.subuserList(items, sName, p, totalPages, users.length), [], 'subuser', p, totalPages, serverId));
      }

      if (type === 'network' && serverId) {
        const [servers, allocs] = await Promise.all([ptero.listServers(panelUrl, apiKey), ptero.listAllocations(panelUrl, apiKey, serverId)]);
        const sName = servers.find(s => s.attributes.identifier === serverId)?.attributes?.name || serverId;
        const { items, page: p, totalPages } = paginateList(allocs, page, PER_PAGE.network);
        return interaction.editReply(withPagination(E.allocationList(items, sName, p, totalPages, allocs.length), [], 'network', p, totalPages, serverId));
      }

      if (type === 'adminservers') {
        const s = await ptero.appListServers(panelUrl, apiKey);
        const { items, page: p, totalPages } = paginateList(s, page, PER_PAGE.adminservers);
        return interaction.editReply(withPagination(E.adminServerList(items, p, totalPages, s.length), [], 'adminservers', p, totalPages));
      }

      if (type === 'adminusers') {
        const u = await ptero.appListUsers(panelUrl, apiKey);
        const { items, page: p, totalPages } = paginateList(u, page, PER_PAGE.adminusers);
        return interaction.editReply(withPagination(E.adminUserList(items, p, totalPages, u.length), [], 'adminusers', p, totalPages));
      }

      if (type === 'adminnodes') {
        const n = await ptero.appListNodes(panelUrl, apiKey);
        const { items, page: p, totalPages } = paginateList(n, page, PER_PAGE.adminnodes);
        return interaction.editReply(withPagination(E.adminNodeList(items, p, totalPages, n.length), [], 'adminnodes', p, totalPages));
      }
    }

    // ── FILE DELETE CONFIRMATION ─────────────────────────────
    if (cid === 'cancel_delete') {
      return interaction.editReply({ embeds: [E.info('Cancelled ❌', '> File delete **cancelled**. Nothing was deleted.')], components: [] });
    }
    if (cid === 'confirm_delete') {
      const pending = store.getExtra(userId, 'pendingDelete');
      if (!pending) return interaction.editReply({ embeds: [E.error('Expired', '> This delete request has expired. Please run the command again.')], components: [] });
      store.setExtra(userId, 'pendingDelete', null);
      await ptero.deleteFiles(panelUrl, apiKey, pending.serverId, pending.root, [pending.fileName]);
      return interaction.editReply({ embeds: [E.success('File Deleted 🗑️', `> Deleted \`${pending.filePath}\` successfully.`)], components: [] });
    }

    // ── SOFTWARE INSTALL ──────────────────────────────────────
    if (cid === 'install_jar') {
      const pending = store.getExtra(userId, 'pendingInstall');
      if (!pending) return interaction.editReply({ embeds: [E.error('Expired', '> Install session expired. Please select the version again.')], components: [] });
      const serverId = store.getSelectedServer(userId);
      if (!serverId) return interaction.editReply({ embeds: [E.error('No Server', '> No active server selected.\n> Use `/mcmanager server manage` to select a server first.')], components: [] });
      await interaction.editReply({ embeds: [E.info('Installing... ⏳', `> Downloading **${pending.software} ${pending.version}**...\n> Uploading \`${pending.fileName}\` to server root \`/\`.\n> This may take 30–60 seconds.`)], components: [] });
      await ptero.uploadDiscordFile(panelUrl, apiKey, serverId, pending.installUrl, pending.fileName, '/');
      store.setExtra(userId, 'pendingInstall', null);
      return interaction.editReply({ embeds: [E.success('JAR Installed ✅', [
        `> 📦 **${pending.software} ${pending.version}** installed!`,
        `> 📄 File: \`/${pending.fileName}\``,
        `> 🔁 Restart your server to apply changes.`,
        `> ⚠️ Make sure your startup command uses \`${pending.fileName}\` as the JAR file.`,
      ].join('\n'))], components: [] });
    }

  } catch (err) {
    const OFFLINE = ['ECONNREFUSED', 'ETIMEDOUT', 'ENOTFOUND', 'ECONNRESET', 'EHOSTUNREACH'];
    const isOffline = OFFLINE.includes(err.code) || (err.message || '').toLowerCase().includes('timeout');
    const title = isOffline ? '🔴 Panel Offline' : 'Error';
    const msg = isOffline
      ? '> Panel is **offline or unreachable**.'
      : `> \`${err.message}\``;
    return interaction.editReply({ embeds: [E.error(title, msg)] });
  }
}

// ── SELECT MENU HANDLER ────────────────────────────────────────────────────

async function handleSelectMenu(interaction) {
  const userId = interaction.user.id;

  // ── SERVER SELECT (manage dropdown) ──────────────────────
  if (interaction.customId === 'server_select') {
    const serverId = interaction.values[0];
    const creds = store.resolveCredentials(userId);
    if (!creds) return interaction.reply({ embeds: [E.notLoggedIn()], ephemeral: true });
    store.setSelectedServer(userId, serverId);
    await interaction.deferUpdate();
    try {
      const [servers, resources] = await Promise.all([ptero.listServers(creds.panelUrl, creds.apiKey), ptero.getServerResources(creds.panelUrl, creds.apiKey, serverId)]);
      const server = servers.find(s => s.attributes.identifier === serverId);
      const components = [E.powerButtons(serverId), E.serverActionButtons(serverId)];
      if (servers.length > 1) components.push(E.serverInlineSwitcher(servers, serverId));
      return interaction.editReply({ embeds: [E.serverStatus(server, resources)], components });
    } catch (err) {
      return interaction.editReply({ embeds: [E.error('Error', `> \`${err.message}\``)], components: [] });
    }
  }

  // ── MC SOFTWARE SELECT ────────────────────────────────────
  if (interaction.customId === 'mc_software') {
    const softwareId = interaction.values[0];
    await interaction.deferUpdate();
    try {
      const versions = await mcVersions.fetchVersions(softwareId);
      if (!versions || versions.length === 0) {
        return interaction.editReply({ embeds: [E.error('No Versions', `> Could not fetch versions for **${softwareId}**. Try again later.`)], components: [] });
      }
      return interaction.editReply({
        embeds: [E.versionSelectEmbed(softwareId)],
        components: [E.versionMenu(softwareId, versions)],
      });
    } catch (err) {
      return interaction.editReply({ embeds: [E.error('Fetch Error', `> \`${err.message}\``)], components: [] });
    }
  }

  // ── MC VERSION SELECT ─────────────────────────────────────
  if (interaction.customId.startsWith('mc_version_')) {
    const softwareId = interaction.customId.replace('mc_version_', '');
    const version = interaction.values[0];
    await interaction.deferUpdate();
    try {
      const info = await mcVersions.getDownloadInfo(softwareId, version);
      const components = [];
      if (info.directDownload && info.installUrl && info.fileName) {
        store.setExtra(interaction.user.id, 'pendingInstall', {
          installUrl: info.installUrl,
          fileName: info.fileName,
          software: info.software,
          version: info.version,
        });
        components.push(new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('install_jar').setLabel('🚀 Install on Active Server').setStyle(ButtonStyle.Success),
        ));
      }
      return interaction.editReply({ embeds: [E.versionInfoEmbed(info)], components });
    } catch (err) {
      return interaction.editReply({ embeds: [E.error('Error', `> \`${err.message}\``)], components: [] });
    }
  }
}

module.exports = { data, execute, handleModal, handleButton, handleSelectMenu };
