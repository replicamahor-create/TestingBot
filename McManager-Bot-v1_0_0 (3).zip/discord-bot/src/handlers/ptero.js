const axios = require('axios');

function createClient(panelUrl, apiKey) {
  const base = panelUrl.replace(/\/$/, '');
  const client = axios.create({
    baseURL: `${base}/api/client`,
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
    timeout: 15000,
  });
  const app = axios.create({
    baseURL: `${base}/api/application`,
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
    timeout: 15000,
  });
  return { client, app, base };
}

async function testConnection(panelUrl, apiKey) {
  try {
    const { client } = createClient(panelUrl, apiKey);
    const res = await client.get('/account');
    return { ok: true, data: res.data };
  } catch (err) {
    const status = err.response?.status;
    const detail = err.response?.data?.errors?.[0]?.detail;
    if (status === 401) {
      return { ok: false, error: 'Invalid API key. Make sure you are using a CLIENT API key (starts with ptlc_), not an Application key. Generate it from: Panel → Account → API Credentials.' };
    }
    if (status === 403) {
      return { ok: false, error: 'Access denied (403). Your API key does not have permission to access this resource. Make sure you are using a CLIENT API key (ptlc_) with full access.' };
    }
    if (status === 404) {
      return { ok: false, error: 'Panel URL not found (404). Double-check your panel URL is correct.' };
    }
    if (err.code === 'ECONNREFUSED' || err.code === 'ENOTFOUND' || err.code === 'ETIMEDOUT') {
      return { ok: false, error: `Cannot reach panel. Make sure the URL is correct and the panel is online. (${err.code})` };
    }
    return { ok: false, error: detail || err.message };
  }
}

// ── CLIENT API ──────────────────────────────────────────────

async function listServers(panelUrl, apiKey) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.get('/');
  return res.data.data;
}

async function getServerResources(panelUrl, apiKey, serverId) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.get(`/servers/${serverId}/resources`);
  return res.data.attributes;
}

async function sendPowerAction(panelUrl, apiKey, serverId, action) {
  const { client } = createClient(panelUrl, apiKey);
  await client.post(`/servers/${serverId}/power`, { signal: action });
}

async function sendCommand(panelUrl, apiKey, serverId, command) {
  const { client } = createClient(panelUrl, apiKey);
  await client.post(`/servers/${serverId}/command`, { command });
}

async function getConsoleOutput(panelUrl, apiKey, serverId) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.get(`/servers/${serverId}/websocket`);
  return res.data;
}

// ── FILES ───────────────────────────────────────────────────

async function listFiles(panelUrl, apiKey, serverId, dir = '/') {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.get(`/servers/${serverId}/files/list`, { params: { directory: dir } });
  return res.data.data;
}

async function getFileContents(panelUrl, apiKey, serverId, filePath) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.get(`/servers/${serverId}/files/contents`, { params: { file: filePath } });
  return res.data;
}

async function writeFileContents(panelUrl, apiKey, serverId, filePath, content) {
  const { client } = createClient(panelUrl, apiKey);
  await client.post(`/servers/${serverId}/files/write`, content, {
    params: { file: filePath },
    headers: { 'Content-Type': 'text/plain' },
  });
}

async function deleteFiles(panelUrl, apiKey, serverId, root, files) {
  const { client } = createClient(panelUrl, apiKey);
  await client.post(`/servers/${serverId}/files/delete`, { root, files });
}

async function renameFile(panelUrl, apiKey, serverId, root, files) {
  const { client } = createClient(panelUrl, apiKey);
  await client.put(`/servers/${serverId}/files/rename`, { root, files });
}

async function createFolder(panelUrl, apiKey, serverId, root, name) {
  const { client } = createClient(panelUrl, apiKey);
  await client.post(`/servers/${serverId}/files/create-folder`, { root, name });
}

async function copyFile(panelUrl, apiKey, serverId, location) {
  const { client } = createClient(panelUrl, apiKey);
  await client.post(`/servers/${serverId}/files/copy`, { location });
}

async function compressFiles(panelUrl, apiKey, serverId, root, files) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.post(`/servers/${serverId}/files/compress`, { root, files });
  return res.data.attributes;
}

async function decompressFile(panelUrl, apiKey, serverId, root, file) {
  const { client } = createClient(panelUrl, apiKey);
  await client.post(`/servers/${serverId}/files/decompress`, { root, file });
}

async function getUploadUrl(panelUrl, apiKey, serverId) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.get(`/servers/${serverId}/files/upload`);
  return res.data.attributes.url;
}

async function uploadDiscordFile(panelUrl, apiKey, serverId, discordUrl, fileName, uploadPath) {
  const FormData = require('form-data');
  const { client } = createClient(panelUrl, apiKey);

  const uploadRes = await client.get(`/servers/${serverId}/files/upload`);
  const signedUrl = uploadRes.data.attributes.url;

  const fileRes = await axios.get(discordUrl, { responseType: 'arraybuffer', timeout: 60000 });
  const fileBuffer = Buffer.from(fileRes.data);
  const contentType = fileRes.headers['content-type'] || 'application/octet-stream';

  const form = new FormData();
  form.append('files', fileBuffer, { filename: fileName, contentType });

  const dir = (uploadPath || '/').replace(/\/$/, '') || '/';
  const sep = signedUrl.includes('?') ? '&' : '?';
  const fullUrl = `${signedUrl}${sep}directory=${encodeURIComponent(dir)}`;

  await axios.post(fullUrl, form, {
    headers: form.getHeaders(),
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    timeout: 120000,
  });

  return { fileName, size: fileBuffer.length, path: dir };
}

async function getDownloadUrl(panelUrl, apiKey, serverId, filePath) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.get(`/servers/${serverId}/files/download`, { params: { file: filePath } });
  return res.data.attributes.url;
}

// ── BACKUPS ─────────────────────────────────────────────────

async function listBackups(panelUrl, apiKey, serverId) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.get(`/servers/${serverId}/backups`);
  return res.data.data;
}

async function createBackup(panelUrl, apiKey, serverId, name = null, locked = false) {
  const { client } = createClient(panelUrl, apiKey);
  const body = { locked };
  if (name) body.name = name;
  const res = await client.post(`/servers/${serverId}/backups`, body);
  return res.data.attributes;
}

async function deleteBackup(panelUrl, apiKey, serverId, backupId) {
  const { client } = createClient(panelUrl, apiKey);
  await client.delete(`/servers/${serverId}/backups/${backupId}`);
}

async function restoreBackup(panelUrl, apiKey, serverId, backupId, truncate = false) {
  const { client } = createClient(panelUrl, apiKey);
  await client.post(`/servers/${serverId}/backups/${backupId}/restore`, { truncate });
}

async function getBackupDownload(panelUrl, apiKey, serverId, backupId) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.get(`/servers/${serverId}/backups/${backupId}/download`);
  return res.data.attributes.url;
}

async function toggleBackupLock(panelUrl, apiKey, serverId, backupId) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.post(`/servers/${serverId}/backups/${backupId}/lock`);
  return res.data.attributes;
}

// ── DATABASES ───────────────────────────────────────────────

async function listDatabases(panelUrl, apiKey, serverId) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.get(`/servers/${serverId}/databases`);
  return res.data.data;
}

async function createDatabase(panelUrl, apiKey, serverId, database, remote = '%') {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.post(`/servers/${serverId}/databases`, { database, remote });
  return res.data.attributes;
}

async function deleteDatabase(panelUrl, apiKey, serverId, databaseId) {
  const { client } = createClient(panelUrl, apiKey);
  await client.delete(`/servers/${serverId}/databases/${databaseId}`);
}

async function rotateDatabasePassword(panelUrl, apiKey, serverId, databaseId) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.post(`/servers/${serverId}/databases/${databaseId}/rotate-password`);
  return res.data.attributes;
}

// ── SCHEDULES ───────────────────────────────────────────────

async function listSchedules(panelUrl, apiKey, serverId) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.get(`/servers/${serverId}/schedules`);
  return res.data.data;
}

async function getSchedule(panelUrl, apiKey, serverId, scheduleId) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.get(`/servers/${serverId}/schedules/${scheduleId}`);
  return res.data.attributes;
}

async function createSchedule(panelUrl, apiKey, serverId, data) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.post(`/servers/${serverId}/schedules`, data);
  return res.data.attributes;
}

async function deleteSchedule(panelUrl, apiKey, serverId, scheduleId) {
  const { client } = createClient(panelUrl, apiKey);
  await client.delete(`/servers/${serverId}/schedules/${scheduleId}`);
}

async function triggerSchedule(panelUrl, apiKey, serverId, scheduleId) {
  const { client } = createClient(panelUrl, apiKey);
  await client.post(`/servers/${serverId}/schedules/${scheduleId}/execute`);
}

async function updateSchedule(panelUrl, apiKey, serverId, scheduleId, data) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.post(`/servers/${serverId}/schedules/${scheduleId}`, data);
  return res.data.attributes;
}

// ── SUBUSERS ────────────────────────────────────────────────

async function listSubusers(panelUrl, apiKey, serverId) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.get(`/servers/${serverId}/users`);
  return res.data.data;
}

async function addSubuser(panelUrl, apiKey, serverId, email, permissions) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.post(`/servers/${serverId}/users`, { email, permissions });
  return res.data.attributes;
}

async function removeSubuser(panelUrl, apiKey, serverId, userId) {
  const { client } = createClient(panelUrl, apiKey);
  await client.delete(`/servers/${serverId}/users/${userId}`);
}

async function updateSubuser(panelUrl, apiKey, serverId, userId, permissions) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.post(`/servers/${serverId}/users/${userId}`, { permissions });
  return res.data.attributes;
}

// ── ALLOCATIONS ─────────────────────────────────────────────

async function listAllocations(panelUrl, apiKey, serverId) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.get(`/servers/${serverId}/network/allocations`);
  return res.data.data;
}

async function assignAllocation(panelUrl, apiKey, serverId) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.post(`/servers/${serverId}/network/allocations`);
  return res.data.attributes;
}

async function removeAllocation(panelUrl, apiKey, serverId, allocationId) {
  const { client } = createClient(panelUrl, apiKey);
  await client.delete(`/servers/${serverId}/network/allocations/${allocationId}`);
}

async function setPrimaryAllocation(panelUrl, apiKey, serverId, allocationId) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.post(`/servers/${serverId}/network/allocations/${allocationId}/primary`);
  return res.data.attributes;
}

async function setAllocationNote(panelUrl, apiKey, serverId, allocationId, notes) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.post(`/servers/${serverId}/network/allocations/${allocationId}`, { notes });
  return res.data.attributes;
}

// ── APPLICATION API ─────────────────────────────────────────

async function appListServers(panelUrl, apiKey) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.get('/servers');
  return res.data.data;
}

async function appGetServer(panelUrl, apiKey, serverId) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.get(`/servers/${serverId}`);
  return res.data.attributes;
}

async function appSuspendServer(panelUrl, apiKey, serverId) {
  const { app } = createClient(panelUrl, apiKey);
  await app.post(`/servers/${serverId}/suspend`);
}

async function appUnsuspendServer(panelUrl, apiKey, serverId) {
  const { app } = createClient(panelUrl, apiKey);
  await app.post(`/servers/${serverId}/unsuspend`);
}

async function appReinstallServer(panelUrl, apiKey, serverId) {
  const { app } = createClient(panelUrl, apiKey);
  await app.post(`/servers/${serverId}/reinstall`);
}

async function appRebuildServer(panelUrl, apiKey, serverId) {
  const { app } = createClient(panelUrl, apiKey);
  await app.post(`/servers/${serverId}/rebuild`);
}

async function appDeleteServer(panelUrl, apiKey, serverId, force = false) {
  const { app } = createClient(panelUrl, apiKey);
  await app.delete(`/servers/${serverId}${force ? '/force' : ''}`);
}

async function appListUsers(panelUrl, apiKey) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.get('/users');
  return res.data.data;
}

async function appGetUser(panelUrl, apiKey, userId) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.get(`/users/${userId}`);
  return res.data.attributes;
}

async function appCreateUser(panelUrl, apiKey, data) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.post('/users', data);
  return res.data.attributes;
}

async function appDeleteUser(panelUrl, apiKey, userId) {
  const { app } = createClient(panelUrl, apiKey);
  await app.delete(`/users/${userId}`);
}

async function appUpdateUser(panelUrl, apiKey, userId, data) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.patch(`/users/${userId}`, data);
  return res.data.attributes;
}

async function appListNodes(panelUrl, apiKey) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.get('/nodes');
  return res.data.data;
}

async function appGetNode(panelUrl, apiKey, nodeId) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.get(`/nodes/${nodeId}`);
  return res.data.attributes;
}

async function appGetNodeConfig(panelUrl, apiKey, nodeId) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.get(`/nodes/${nodeId}/configuration`);
  return res.data;
}

async function appListNodeAllocations(panelUrl, apiKey, nodeId) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.get(`/nodes/${nodeId}/allocations`);
  return res.data.data;
}

async function appListLocations(panelUrl, apiKey) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.get('/locations');
  return res.data.data;
}

async function appCreateLocation(panelUrl, apiKey, short, long) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.post('/locations', { short, long });
  return res.data.attributes;
}

async function appDeleteLocation(panelUrl, apiKey, locationId) {
  const { app } = createClient(panelUrl, apiKey);
  await app.delete(`/locations/${locationId}`);
}

async function appListNests(panelUrl, apiKey) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.get('/nests');
  return res.data.data;
}

async function appGetNest(panelUrl, apiKey, nestId) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.get(`/nests/${nestId}`);
  return res.data.attributes;
}

async function appListEggs(panelUrl, apiKey, nestId) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.get(`/nests/${nestId}/eggs`);
  return res.data.data;
}

async function appGetEgg(panelUrl, apiKey, nestId, eggId) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.get(`/nests/${nestId}/eggs/${eggId}`);
  return res.data.attributes;
}

async function appCreateNest(panelUrl, apiKey, { name, description }) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.post('/nests', { name, description: description || '' });
  return res.data.attributes;
}

async function appCreateEgg(panelUrl, apiKey, nestId, { name, description, dockerImage, startup }) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.post(`/nests/${nestId}/eggs`, {
    name,
    description: description || '',
    docker_image: dockerImage,
    startup,
    config: {
      files: {},
      startup: { done: ']$' },
      logs: {},
      stop: '^C',
    },
    script: {
      privileged: true,
      install: '#!/bin/ash\necho "Egg installed."',
      entry: 'ash',
      container: 'alpine:3.4',
      extends: null,
    },
  });
  return res.data.attributes;
}

// ── FILE COPY ────────────────────────────────────────────────
async function copyFile(panelUrl, apiKey, serverId, location) {
  const { client } = createClient(panelUrl, apiKey);
  await client.post(`/servers/${serverId}/files/copy`, { location });
}

// ── FILE STATS ────────────────────────────────────────────────
async function getFileStats(panelUrl, apiKey, serverId, filePath) {
  const { client } = createClient(panelUrl, apiKey);
  const parts = filePath.split('/'); const name = parts.pop(); const dir = parts.join('/') || '/';
  const res = await client.get(`/servers/${serverId}/files/list?directory=${encodeURIComponent(dir)}`);
  return (res.data.data || []).find(f => f.attributes.name === name) || null;
}

// ── BACKUP INFO ───────────────────────────────────────────────
async function getBackupInfo(panelUrl, apiKey, serverId, uuid) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.get(`/servers/${serverId}/backups/${uuid}`);
  return res.data.attributes;
}

// ── DATABASE INFO (with password) ────────────────────────────
async function getDatabaseInfo(panelUrl, apiKey, serverId, dbId) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.get(`/servers/${serverId}/databases/${dbId}?include=password`);
  return res.data.attributes;
}

// ── TOGGLE SCHEDULE ───────────────────────────────────────────
async function toggleSchedule(panelUrl, apiKey, serverId, scheduleId, active) {
  const { client } = createClient(panelUrl, apiKey);
  const cur = await client.get(`/servers/${serverId}/schedules/${scheduleId}`);
  const a = cur.data.attributes;
  const res = await client.post(`/servers/${serverId}/schedules/${scheduleId}`, {
    name: a.name, minute: a.cron.minute, hour: a.cron.hour,
    day_of_week: a.cron.day_of_week, day_of_month: a.cron.day_of_month,
    month: a.cron.month || '*', is_active: active,
  });
  return res.data.attributes;
}

// ── SCHEDULE TASKS ────────────────────────────────────────────
async function getScheduleTasks(panelUrl, apiKey, serverId, scheduleId) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.get(`/servers/${serverId}/schedules/${scheduleId}`);
  return { schedule: res.data.attributes, tasks: res.data.attributes.relationships?.tasks?.data || [] };
}

// ── CREATE SCHEDULE TASK ──────────────────────────────────────
async function createScheduleTask(panelUrl, apiKey, serverId, scheduleId, action, payload, timeOffset = 0) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.post(`/servers/${serverId}/schedules/${scheduleId}/tasks`, {
    action, payload, time_offset: timeOffset,
  });
  return res.data.attributes;
}

// ── SUBUSER PERMISSIONS ───────────────────────────────────────
async function getSubuserPermissions(panelUrl, apiKey, serverId, subuserUuid) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.get(`/servers/${serverId}/users/${subuserUuid}`);
  return res.data.attributes;
}

// ── APP GET SINGLE SERVER ─────────────────────────────────────
async function appGetServer(panelUrl, apiKey, serverId) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.get(`/servers/${serverId}`);
  return res.data.attributes;
}

// ── APP GET SINGLE USER ───────────────────────────────────────
async function appGetUser(panelUrl, apiKey, userId) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.get(`/users/${userId}`);
  return res.data.attributes;
}

// ── APP UPDATE SERVER BUILD ───────────────────────────────────
async function appUpdateServerBuild(panelUrl, apiKey, serverId, { memory, swap, disk, io, cpu }) {
  const { app } = createClient(panelUrl, apiKey);
  const cur = await app.get(`/servers/${serverId}`);
  const a = cur.data.attributes;
  const res = await app.patch(`/servers/${serverId}/build`, {
    allocation: a.allocation,
    memory: memory ?? a.limits.memory,
    swap: swap ?? a.limits.swap,
    disk: disk ?? a.limits.disk,
    io: io ?? a.limits.io,
    cpu: cpu ?? a.limits.cpu,
    threads: a.limits.threads || null,
    feature_limits: a.feature_limits,
    oom_disabled: a.limits.oom_disabled ?? false,
  });
  return res.data.attributes;
}

// ── STARTUP VARIABLES ────────────────────────────────────────
async function getServerVariables(panelUrl, apiKey, serverId) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.get(`/servers/${serverId}/startup`);
  return { variables: res.data.data, startup: res.data.meta?.startup_command || '' };
}

async function updateServerVariable(panelUrl, apiKey, serverId, key, value) {
  const { client } = createClient(panelUrl, apiKey);
  const res = await client.put(`/servers/${serverId}/startup/variable`, { key, value });
  return res.data.attributes;
}

// ── APP RENAME SERVER ─────────────────────────────────────────
async function appRenameServer(panelUrl, apiKey, intServerId, name, description) {
  const { app } = createClient(panelUrl, apiKey);
  const cur = await app.get(`/servers/${intServerId}`);
  const attr = cur.data.attributes;
  const res = await app.patch(`/servers/${intServerId}/details`, {
    name,
    user: attr.user,
    description: description || attr.description || '',
    external_id: attr.external_id || null,
  });
  return res.data.attributes;
}

// ── APP TRANSFER SERVER ───────────────────────────────────────
async function appTransferServer(panelUrl, apiKey, intServerId, nodeId, allocationId) {
  const { app } = createClient(panelUrl, apiKey);
  await app.post(`/servers/${intServerId}/transfer`, { node_id: nodeId, allocation_id: allocationId });
}

// ── CLIENT API REINSTALL (uses identifier, not integer ID) ──
async function clientReinstallServer(panelUrl, apiKey, serverId) {
  const { client } = createClient(panelUrl, apiKey);
  await client.post(`/servers/${serverId}/settings/reinstall`);
}

// ── APP CREATE SERVER ────────────────────────────────────────
async function appCreateServer(panelUrl, apiKey, data) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.post('/servers', data);
  return res.data.attributes;
}

// ── APP CREATE NODE ──────────────────────────────────────────
async function appCreateNode(panelUrl, apiKey, data) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.post('/nodes', data);
  return res.data.attributes;
}

// ── APP CREATE LOCATION ──────────────────────────────────────
async function appGetNodeFreeAllocation(panelUrl, apiKey, nodeId) {
  const { app } = createClient(panelUrl, apiKey);
  const res = await app.get(`/nodes/${nodeId}/allocations`);
  const free = res.data.data.find(a => !a.attributes.assigned);
  return free?.attributes || null;
}

module.exports = {
  testConnection,
  listServers,
  getServerResources,
  sendPowerAction,
  sendCommand,
  getConsoleOutput,
  listFiles,
  getFileContents,
  writeFileContents,
  deleteFiles,
  renameFile,
  createFolder,
  copyFile,
  compressFiles,
  decompressFile,
  getUploadUrl,
  uploadDiscordFile,
  getDownloadUrl,
  listBackups,
  createBackup,
  deleteBackup,
  restoreBackup,
  getBackupDownload,
  toggleBackupLock,
  listDatabases,
  createDatabase,
  deleteDatabase,
  rotateDatabasePassword,
  listSchedules,
  getSchedule,
  createSchedule,
  deleteSchedule,
  triggerSchedule,
  updateSchedule,
  listSubusers,
  addSubuser,
  removeSubuser,
  updateSubuser,
  listAllocations,
  assignAllocation,
  removeAllocation,
  setPrimaryAllocation,
  setAllocationNote,
  appListServers,
  appGetServer,
  appSuspendServer,
  appUnsuspendServer,
  appReinstallServer,
  appRebuildServer,
  appDeleteServer,
  appListUsers,
  appGetUser,
  appCreateUser,
  appDeleteUser,
  appUpdateUser,
  appListNodes,
  appGetNode,
  appGetNodeConfig,
  appListNodeAllocations,
  appListLocations,
  appCreateLocation,
  appDeleteLocation,
  appListNests,
  appGetNest,
  appListEggs,
  appGetEgg,
  appCreateNest,
  appCreateEgg,
  clientReinstallServer,
  appCreateServer,
  appCreateNode,
  appGetNodeFreeAllocation,
  getServerVariables,
  updateServerVariable,
  appRenameServer,
  appTransferServer,
  copyFile,
  getFileStats,
  getBackupInfo,
  getDatabaseInfo,
  toggleSchedule,
  getScheduleTasks,
  createScheduleTask,
  getSubuserPermissions,
  appGetServer,
  appGetUser,
  appUpdateServerBuild,
};
