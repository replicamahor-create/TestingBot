const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '../../data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE, '{}');

function readAll() {
  try { return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8')); } catch { return {}; }
}

function writeAll(data) {
  fs.writeFileSync(USERS_FILE, JSON.stringify(data, null, 2));
}

function getUser(userId) { return readAll()[userId] || null; }

function setUser(userId, data) {
  const all = readAll();
  all[userId] = { ...all[userId], ...data, updatedAt: Date.now() };
  writeAll(all);
}

function deleteUser(userId) {
  const all = readAll(); delete all[userId]; writeAll(all);
}

function isLoggedIn(userId) {
  const u = getUser(userId);
  return !!(u && u.panelUrl && u.apiKey);
}

function getSelectedServer(userId) {
  const u = getUser(userId);
  return u ? u.selectedServer || null : null;
}

function setSelectedServer(userId, serverIdentifier) {
  setUser(userId, { selectedServer: serverIdentifier });
}

function clearSelectedServer(userId) {
  const all = readAll();
  if (all[userId]) { delete all[userId].selectedServer; writeAll(all); }
}

function totalUsers() { return Object.keys(readAll()).length; }

// ── TRUST SYSTEM ────────────────────────────────────────────────────────────

function addTrustedUser(ownerId, trustedId, trustedTag) {
  const all = readAll();
  if (!all[ownerId]) return false;
  if (!all[ownerId].trustedUsers) all[ownerId].trustedUsers = [];
  all[ownerId].trustedUsers = all[ownerId].trustedUsers.filter(u => u.id !== trustedId);
  all[ownerId].trustedUsers.push({ id: trustedId, tag: trustedTag, addedAt: Date.now() });
  writeAll(all);
  return true;
}

function removeTrustedUser(ownerId, trustedId) {
  const all = readAll();
  if (!all[ownerId]?.trustedUsers) return false;
  const before = all[ownerId].trustedUsers.length;
  all[ownerId].trustedUsers = all[ownerId].trustedUsers.filter(u => u.id !== trustedId);
  writeAll(all);
  return all[ownerId].trustedUsers.length < before;
}

function getTrustedUsers(ownerId) {
  return getUser(ownerId)?.trustedUsers || [];
}

function getTruster(trustedId) {
  const all = readAll();
  for (const [ownerId, data] of Object.entries(all)) {
    if (data.trustedUsers?.some(u => u.id === trustedId)) {
      return { ownerId, ownerData: data };
    }
  }
  return null;
}

// Returns credentials for userId — own login OR trusted panel
function resolveCredentials(userId) {
  const user = getUser(userId);
  if (user?.panelUrl && user?.apiKey) return { ...user, isTrusted: false };
  const truster = getTruster(userId);
  if (truster?.ownerData?.panelUrl) {
    return { ...truster.ownerData, isTrusted: true, trusterId: truster.ownerId };
  }
  return null;
}

function hasAccess(userId) {
  return !!resolveCredentials(userId);
}

// ── EXTRA KEY/VALUE STORAGE ──────────────────────────────────
function setExtra(userId, key, value) {
  const all = readAll();
  if (!all[userId]) all[userId] = {};
  if (!all[userId].extra) all[userId].extra = {};
  all[userId].extra[key] = value;
  writeAll(all);
}

function getExtra(userId, key) {
  return getUser(userId)?.extra?.[key] ?? null;
}

module.exports = {
  getUser, setUser, deleteUser,
  isLoggedIn, hasAccess, resolveCredentials,
  getSelectedServer, setSelectedServer, clearSelectedServer,
  totalUsers,
  addTrustedUser, removeTrustedUser, getTrustedUsers, getTruster,
  setExtra, getExtra,
};
