const axios = require('axios');

const SOFTWARE = [
  { id: 'paper',      label: '📄 Paper',       desc: 'High performance Spigot fork (recommended)' },
  { id: 'purpur',     label: '🟣 Purpur',      desc: 'Paper fork with extra mob features' },
  { id: 'fabric',     label: '🔵 Fabric',      desc: 'Lightweight modding toolchain' },
  { id: 'forge',      label: '🔨 Forge',       desc: 'Most popular mod loader' },
  { id: 'neoforge',   label: '🆕 NeoForge',    desc: 'Modern Forge fork' },
  { id: 'vanilla',    label: '⚪ Vanilla',     desc: 'Official Mojang server' },
  { id: 'quilt',      label: '🟤 Quilt',       desc: 'Community Fabric fork' },
  { id: 'spigot',     label: '🟡 Spigot',      desc: 'CraftBukkit fork' },
  { id: 'bungeecord', label: '🔗 BungeeCord',  desc: 'Proxy for multiple servers' },
  { id: 'velocity',   label: '⚡ Velocity',    desc: 'Modern high-performance proxy' },
  { id: 'waterfall',  label: '💧 Waterfall',   desc: 'BungeeCord fork' },
  { id: 'sponge',     label: '🧽 SpongeVanilla', desc: 'Sponge on Vanilla' },
];

async function fetchVersions(softwareId) {
  try {
    switch (softwareId) {
      case 'paper': {
        const r = await axios.get('https://api.papermc.io/v2/projects/paper', { timeout: 8000 });
        return [...r.data.versions].reverse().slice(0, 25);
      }
      case 'purpur': {
        const r = await axios.get('https://api.purpurmc.org/v2/purpur', { timeout: 8000 });
        return [...r.data.versions].reverse().slice(0, 25);
      }
      case 'fabric': {
        const r = await axios.get('https://meta.fabricmc.net/v2/versions/game', { timeout: 8000 });
        return r.data.filter(v => v.stable).map(v => v.version).slice(0, 25);
      }
      case 'quilt': {
        const r = await axios.get('https://meta.quiltmc.org/v3/versions/game', { timeout: 8000 });
        return r.data.filter(v => !v.version.includes('pre') && !v.version.includes('rc')).map(v => v.version).slice(0, 25);
      }
      case 'vanilla':
      case 'spigot':
      case 'sponge': {
        const r = await axios.get('https://launchermeta.mojang.com/mc/game/version_manifest.json', { timeout: 8000 });
        return r.data.versions.filter(v => v.type === 'release').map(v => v.id).slice(0, 25);
      }
      case 'forge': {
        const r = await axios.get('https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json', { timeout: 8000 });
        const promos = r.data.promos;
        const versions = [...new Set(Object.keys(promos).map(k => k.split('-')[0]))];
        return versions.reverse().slice(0, 25);
      }
      case 'neoforge': {
        const r = await axios.get('https://maven.neoforged.net/releases/net/neoforged/neoforge/maven-metadata.xml', { timeout: 8000 });
        const matches = [...r.data.matchAll(/<version>([\d.]+)<\/version>/g)];
        return matches.map(m => m[1]).reverse().slice(0, 25);
      }
      case 'waterfall': {
        const r = await axios.get('https://api.papermc.io/v2/projects/waterfall', { timeout: 8000 });
        return [...r.data.versions].reverse().slice(0, 25);
      }
      case 'bungeecord':
        return ['Latest Build', '1.20', '1.19', '1.18', '1.17', '1.16', '1.15', '1.14', '1.13', '1.12', '1.11', '1.10', '1.9', '1.8'];
      case 'velocity': {
        const r = await axios.get('https://api.papermc.io/v2/projects/velocity', { timeout: 8000 });
        return [...r.data.versions].reverse().slice(0, 25);
      }
      default:
        return ['Latest'];
    }
  } catch {
    return ['1.21.4', '1.21.3', '1.21.1', '1.21', '1.20.6', '1.20.4', '1.20.2', '1.20.1', '1.20', '1.19.4', '1.19.2', '1.18.2', '1.17.1', '1.16.5'];
  }
}

async function getDownloadInfo(softwareId, version) {
  const info = { software: softwareId, version, links: [], directDownload: false, installUrl: null, fileName: null };

  switch (softwareId) {
    case 'paper':
      try {
        const r = await axios.get(`https://api.papermc.io/v2/projects/paper/versions/${version}`, { timeout: 8000 });
        const build = r.data.builds[r.data.builds.length - 1];
        const url = `https://api.papermc.io/v2/projects/paper/versions/${version}/builds/${build}/downloads/paper-${version}-${build}.jar`;
        const fileName = `paper-${version}-${build}.jar`;
        info.links.push({ label: `📥 Paper ${version} (Build #${build})`, url });
        info.directDownload = true;
        info.installUrl = url;
        info.fileName = fileName;
      } catch {}
      break;

    case 'purpur': {
      const url = `https://api.purpurmc.org/v2/purpur/${version}/latest/download`;
      const fileName = `purpur-${version}.jar`;
      info.links.push({ label: `📥 Purpur ${version}`, url });
      info.directDownload = true;
      info.installUrl = url;
      info.fileName = fileName;
      break;
    }

    case 'velocity':
      try {
        const r = await axios.get(`https://api.papermc.io/v2/projects/velocity/versions/${version}`, { timeout: 8000 });
        const build = r.data.builds[r.data.builds.length - 1];
        const url = `https://api.papermc.io/v2/projects/velocity/versions/${version}/builds/${build}/downloads/velocity-${version}-${build}.jar`;
        const fileName = `velocity-${version}-${build}.jar`;
        info.links.push({ label: `📥 Velocity ${version} (Build #${build})`, url });
        info.directDownload = true;
        info.installUrl = url;
        info.fileName = fileName;
      } catch {}
      break;

    case 'waterfall':
      try {
        const r = await axios.get(`https://api.papermc.io/v2/projects/waterfall/versions/${version}`, { timeout: 8000 });
        const build = r.data.builds[r.data.builds.length - 1];
        const url = `https://api.papermc.io/v2/projects/waterfall/versions/${version}/builds/${build}/downloads/waterfall-${version}-${build}.jar`;
        const fileName = `waterfall-${version}-${build}.jar`;
        info.links.push({ label: `📥 Waterfall ${version} (Build #${build})`, url });
        info.directDownload = true;
        info.installUrl = url;
        info.fileName = fileName;
      } catch {}
      break;

    case 'fabric':
      info.links.push({ label: `🌐 Fabric Server Installer`, url: 'https://fabricmc.net/use/server/' });
      break;

    default:
      info.links.push({ label: `🌐 Official Download Page`, url: `https://www.google.com/search?q=${softwareId}+${version}+server+jar+download` });
  }

  return info;
}

module.exports = { SOFTWARE, fetchVersions, getDownloadInfo };
