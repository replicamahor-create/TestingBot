const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const { COLORS, EMOJIS, AUTHOR, FOOTER, BOT_VERSION, PROGRESS_BAR, FORMAT_BYTES, FORMAT_UPTIME, SERVER_STATUS } = require('./constants');

function base(color = COLORS.PRIMARY) {
  return new EmbedBuilder()
    .setColor(color)
    .setAuthor({ name: AUTHOR.name })
    .setFooter({ text: `${FOOTER.text} • ${BOT_VERSION}` })
    .setTimestamp();
}

// ── GENERIC ─────────────────────────────────────────────────

function success(title, description) {
  return base(COLORS.SUCCESS)
    .setTitle(`${EMOJIS.SUCCESS} ${title}`)
    .setDescription(description);
}

function error(title, description) {
  return base(COLORS.ERROR)
    .setTitle(`${EMOJIS.ERROR} ${title}`)
    .setDescription(description || 'An unexpected error occurred. Please try again.');
}

function warning(title, description) {
  return base(COLORS.WARNING)
    .setTitle(`${EMOJIS.WARNING} ${title}`)
    .setDescription(description);
}

function info(title, description) {
  return base(COLORS.INFO)
    .setTitle(`${EMOJIS.INFO} ${title}`)
    .setDescription(description);
}

function loading(title) {
  return base(COLORS.DARK)
    .setTitle(`${EMOJIS.LOADING} ${title}`)
    .setDescription('> Fetching data from Pterodactyl panel...\n> Please wait a moment.');
}

function notLoggedIn() {
  return base(COLORS.ERROR)
    .setTitle(`${EMOJIS.LOCK} Not Logged In`)
    .setDescription(
      '> You haven\'t connected your Pterodactyl panel yet!\n\n' +
      `**Use \`/mcmanager login\` to get started.**\n\n` +
      '📋 **You will need:**\n' +
      '• Your Pterodactyl Panel URL (e.g. `https://panel.yourhost.com`)\n' +
      '• Your Client API Key (from Panel → Account → API Credentials)\n\n' +
      '> Your credentials are stored privately and only accessible by you.'
    );
}

// ── BOT INFO ─────────────────────────────────────────────────

function botInfo(client, totalUsers) {
  return base(COLORS.PTERODACTYL)
    .setTitle(`${EMOJIS.PTERODACTYL} McManager — Pterodactyl Discord Manager`)
    .setDescription(
      '> The most powerful Pterodactyl panel manager for Discord!\n> Made with ❤️ by **DipuXPro**'
    )
    .addFields(
      { name: `${EMOJIS.BOT} Bot Name`, value: `\`${client.user.tag}\``, inline: true },
      { name: `${EMOJIS.STATS} Version`, value: `\`${BOT_VERSION}\``, inline: true },
      { name: `${EMOJIS.SERVER} Servers`, value: `\`${client.guilds.cache.size}\``, inline: true },
      { name: `${EMOJIS.UPTIME} Uptime`, value: `\`${FORMAT_UPTIME(client.uptime)}\``, inline: true },
      { name: `${EMOJIS.USERS} Total Users`, value: `\`${totalUsers}\``, inline: true },
      { name: `${EMOJIS.PING} Ping`, value: `\`${client.ws.ping}ms\``, inline: true },
      { name: `${EMOJIS.DIAMOND} Features`, value: '`150+ Commands` • `Per-User Data` • `File Manager` • `Real-Time Stats`', inline: false },
      { name: `${EMOJIS.CROWN} Author`, value: '**DipuXPro** — Building the best Discord tools', inline: false }
    )
    .setThumbnail(client.user.displayAvatarURL());
}

function pingEmbed(client) {
  return base(COLORS.SUCCESS)
    .setTitle(`${EMOJIS.PING} McManager — Latency`)
    .addFields(
      { name: '🤖 Bot Latency', value: `\`${client.ws.ping}ms\``, inline: true },
      { name: '⏱️ Uptime', value: `\`${FORMAT_UPTIME(client.uptime)}\``, inline: true },
      { name: '✅ Status', value: '`Online & Ready`', inline: true }
    );
}

// ── LOGIN ────────────────────────────────────────────────────

function loginSuccess(panelUrl) {
  return base(COLORS.SUCCESS)
    .setTitle(`${EMOJIS.SUCCESS} Login Successful!`)
    .setDescription(
      `> ✅ Connected to your Pterodactyl panel!\n\n` +
      `**${EMOJIS.LINK} Panel URL:**\n\`\`\`${panelUrl}\`\`\`` +
      `\n**Your API key has been saved securely.**\n\n` +
      `${EMOJIS.ARROW} Use \`/mcmanager servers\` to see your server list.\n` +
      `${EMOJIS.ARROW} Use \`/mcmanager help\` to see all commands.`
    );
}

function logoutSuccess() {
  return base(COLORS.SUCCESS)
    .setTitle(`${EMOJIS.SUCCESS} Logged Out`)
    .setDescription('> Your credentials have been removed.\n> Use `/mcmanager login` to connect again.');
}

function profileEmbed(user, creds) {
  const maskedKey = user.apiKey.slice(0, 6) + '••••••••••••••••••••' + user.apiKey.slice(-4);
  const isTrusted = creds?.isTrusted || false;
  const embed = base(COLORS.CYAN)
    .setTitle(`${EMOJIS.USER} Your Panel Profile`)
    .addFields(
      { name: `${EMOJIS.LINK} Panel URL`, value: `\`${user.panelUrl}\``, inline: false },
      { name: `${EMOJIS.KEY} API Key`, value: `\`${maskedKey}\``, inline: false },
      { name: `${EMOJIS.CLOCK} Last Updated`, value: `<t:${Math.floor((user.updatedAt || Date.now()) / 1000)}:R>`, inline: true },
      { name: `${EMOJIS.SERVER} Active Server`, value: user.selectedServer ? `\`${user.selectedServer}\`` : '`None selected`', inline: true },
      { name: `🔑 Access Type`, value: isTrusted ? `\`Trusted User\`` : `\`Panel Owner\``, inline: true },
      {
        name: `⚙️ Setup (12 cmds)`,
        value: '`login` `logout` `profile` `ping` `info` `help` `panel-status` `invite` `changelog` `trust-add` `trust-remove` `trust-list`',
        inline: false,
      },
      {
        name: `🖥️ Server (25 cmds)`,
        value: '`list` `manage` `deselect` `status` `start` `stop` `restart` `kill` `reinstall` `suspend` `unsuspend` `bulk-start` `bulk-stop` `bulk-restart` `sftp` `all-status` `limits` `rename` `variables` `variable-set` `info` `notes` `startup` `resources` `pin`',
        inline: false,
      },
      {
        name: `💻 Console (7 cmds)`,
        value: '`view` `cmd` `say` `latest-log` `broadcast` `send-all` `logs-link`',
        inline: false,
      },
      {
        name: `📁 Files (15 cmds)`,
        value: '`list` `read` `write` `delete` `rename` `mkdir` `upload` `download` `compress` `decompress` `search` `copy` `move` `stats` `bulk-delete`',
        inline: false,
      },
      {
        name: `💾 Backup (7 cmds)`,
        value: '`list` `create` `delete` `restore` `download` `lock` `info`',
        inline: false,
      },
      {
        name: `🗄️ Database (5 cmds)`,
        value: '`list` `create` `delete` `password` `info`',
        inline: false,
      },
      {
        name: `📅 Schedule (6 cmds)`,
        value: '`list` `run` `delete` `toggle` `tasks` `add-task`',
        inline: false,
      },
      {
        name: `👥 Subuser (5 cmds)`,
        value: '`list` `add` `remove` `permissions` `count`',
        inline: false,
      },
      {
        name: `📡 Network (5 cmds)`,
        value: '`list` `add` `remove` `primary` `status`',
        inline: false,
      },
      {
        name: `👑 Admin (22 cmds)`,
        value: '`servers` `users` `nodes` `locations` `nests` `eggs` `suspend` `unsuspend` `rebuild` `create-user` `create-server` `create-node` `delete-server` `delete-user` `node-stats` `transfer` `server-info` `user-info` `node-info` `update-build` `create-nest` `create-egg`',
        inline: false,
      },
      {
        name: `⛏️ Minecraft (13 cmds)`,
        value: '`op` `deop` `ban` `kick` `pardon` `whitelist-add` `whitelist-remove` `save` `software` `ping` `time` `weather` `gamemode`',
        inline: false,
      },
      {
        name: `📊 Total`,
        value: '> 🎯 **122 Commands** across **11 categories**\n> Use `/mcmanager setup help` for full details.',
        inline: false,
      }
    );
  return embed;
}

// ── SERVER LIST ──────────────────────────────────────────────

function pageFooter(page, totalPages, total, label) {
  if (totalPages <= 1) return `${total} ${label} • ${FOOTER.text} • ${BOT_VERSION}`;
  return `Page ${page + 1}/${totalPages} — ${total} ${label} total • ${FOOTER.text}`;
}

function serverList(servers, page = 0, totalPages = 1, total = null) {
  const t = total ?? servers.length;
  const embed = base(COLORS.PTERODACTYL)
    .setTitle(`${EMOJIS.SERVER} Your Pterodactyl Servers (${t})`)
    .setDescription('> Select a server from the dropdown, or use commands directly.\n\u200b')
    .setFooter({ text: pageFooter(page, totalPages, t, 'servers') });

  if (servers.length === 0) {
    embed.setDescription('> ❌ No servers found on your panel.\n> Make sure your API key has access to servers.');
    return embed;
  }

  servers.forEach((s, i) => {
    const attr = s.attributes;
    const statusKey = attr.status || 'offline';
    const st = SERVER_STATUS[statusKey] || SERVER_STATUS.offline;
    embed.addFields({
      name: `${st.emoji} ${page * 8 + i + 1}. ${attr.name}`,
      value: `> **ID:** \`${attr.identifier}\` • **Node:** \`${attr.node}\`\n> **Status:** \`${st.label}\` • **RAM Limit:** \`${FORMAT_BYTES(attr.limits?.memory * 1024 * 1024)}\``,
      inline: false,
    });
  });

  return embed;
}

function serverSelectMenu(servers) {
  const options = servers.slice(0, 25).map(s => ({
    label: s.attributes.name.slice(0, 100),
    description: `ID: ${s.attributes.identifier} • Node: ${s.attributes.node}`.slice(0, 100),
    value: s.attributes.identifier,
    emoji: '🖥️',
  }));

  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('server_select')
      .setPlaceholder('🖥️ Select a server to manage...')
      .addOptions(options)
  );
}

function serverSelectMenuPage(pageServers, total) {
  const statusEmoji = (s) => {
    const st = s.attributes?.status;
    if (st === 'running') return '🟢';
    if (st === 'offline' || st === 'stopped') return '🔴';
    return '🟡';
  };
  const options = pageServers.slice(0, 25).map(s => ({
    label: s.attributes.name.slice(0, 100),
    description: `${statusEmoji(s)} ${s.attributes.status || 'unknown'} | ID: ${s.attributes.identifier}`.slice(0, 100),
    value: s.attributes.identifier,
    emoji: '🖥️',
  }));

  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('server_select')
      .setPlaceholder(`🖥️ Select a server... (${total} total)`)
      .addOptions(options)
  );
}

// ── SERVER STATUS ─────────────────────────────────────────────

function serverStatus(server, resources) {
  const attr = server.attributes;
  const res = resources;
  const state = res.current_state || 'offline';
  const st = SERVER_STATUS[state] || SERVER_STATUS.offline;
  const stats = res.resources || {};

  const cpuPct = attr.limits?.cpu ? Math.round((stats.cpu_absolute / attr.limits.cpu) * 100) : Math.round(stats.cpu_absolute || 0);
  const ramUsed = stats.memory_bytes || 0;
  const ramLimit = (attr.limits?.memory || 0) * 1024 * 1024;
  const diskUsed = stats.disk_bytes || 0;
  const diskLimit = (attr.limits?.disk || 0) * 1024 * 1024;
  const ramPct = ramLimit > 0 ? Math.round((ramUsed / ramLimit) * 100) : 0;
  const diskPct = diskLimit > 0 ? Math.round((diskUsed / diskLimit) * 100) : 0;

  return base(st.color)
    .setTitle(`${EMOJIS.SERVER} ${attr.name} — Server Status`)
    .setDescription(
      `> ${st.emoji} Server is currently **${st.label}**\n` +
      `> **ID:** \`${attr.identifier}\` • **Node:** \`${attr.node}\``
    )
    .addFields(
      {
        name: `${EMOJIS.CPU} CPU Usage`,
        value: `${PROGRESS_BAR(cpuPct)}\n\`${stats.cpu_absolute?.toFixed(1) || 0}% / ${attr.limits?.cpu || '∞'}%\``,
        inline: false,
      },
      {
        name: `${EMOJIS.RAM} RAM Usage`,
        value: `${PROGRESS_BAR(ramPct)}\n\`${FORMAT_BYTES(ramUsed)} / ${FORMAT_BYTES(ramLimit)}\``,
        inline: false,
      },
      {
        name: `${EMOJIS.DISK} Disk Usage`,
        value: `${PROGRESS_BAR(diskPct)}\n\`${FORMAT_BYTES(diskUsed)} / ${FORMAT_BYTES(diskLimit)}\``,
        inline: false,
      },
      { name: `${EMOJIS.UPTIME} Uptime`, value: `\`${FORMAT_UPTIME(stats.uptime_seconds * 1000)}\``, inline: true },
      { name: `${EMOJIS.NETWORK} Network In`, value: `\`${FORMAT_BYTES(stats.network_rx_bytes)}\``, inline: true },
      { name: `${EMOJIS.NETWORK} Network Out`, value: `\`${FORMAT_BYTES(stats.network_tx_bytes)}\``, inline: true },
      { name: `${EMOJIS.IP} IP : Port`, value: `\`${attr.relationships?.allocations?.data?.[0]?.attributes?.ip_alias || 'N/A'}:${attr.relationships?.allocations?.data?.[0]?.attributes?.port || 'N/A'}\``, inline: true },
      { name: `${EMOJIS.ALLOCATION} Egg`, value: `\`${attr.relationships?.egg?.attributes?.name || 'Unknown'}\``, inline: true },
      { name: `${EMOJIS.SETTINGS} SFTP`, value: `\`${attr.sftp_details?.ip || 'N/A'}:${attr.sftp_details?.port || 'N/A'}\``, inline: true }
    );
}

// ── FILE MANAGER ─────────────────────────────────────────────

function fileList(files, dir, serverName, page = 0, totalPages = 1, total = null) {
  const t = total ?? files.length;
  const embed = base(COLORS.WARNING)
    .setTitle(`${EMOJIS.FOLDER} File Manager — ${serverName}`)
    .setDescription(`> 📂 **Path:** \`${dir || '/'}\`\n> **${t}** items in directory\n\u200b`)
    .setFooter({ text: pageFooter(page, totalPages, t, 'items') });

  if (files.length === 0) {
    embed.addFields({ name: 'Empty Directory', value: '> This directory is empty.', inline: false });
    return embed;
  }

  const dirs = files.filter(f => f.attributes.is_directory);
  const fileItems = files.filter(f => !f.attributes.is_directory);

  if (dirs.length > 0) {
    const dirList = dirs.map(f => `\`📁\` **${f.attributes.name}/**`).join('\n') || '—';
    embed.addFields({ name: `${EMOJIS.FOLDER} Folders (${dirs.length})`, value: dirList.slice(0, 1024), inline: false });
  }

  if (fileItems.length > 0) {
    const fList = fileItems.map(f => `\`📄\` **${f.attributes.name}** • \`${FORMAT_BYTES(f.attributes.size)}\``).join('\n') || '—';
    embed.addFields({ name: `${EMOJIS.FILE} Files (${fileItems.length})`, value: fList.slice(0, 1024), inline: false });
  }

  return embed;
}

function fileContent(filePath, content, serverName) {
  const truncated = content.length > 3800;
  const display = truncated ? content.slice(0, 3800) + '\n...(truncated)' : content;
  const ext = filePath.split('.').pop()?.toLowerCase() || '';
  const lang = ['js', 'ts', 'json', 'yaml', 'yml', 'py', 'sh', 'properties', 'toml', 'xml', 'conf', 'cfg'].includes(ext) ? ext : '';

  return base(COLORS.CYAN)
    .setTitle(`${EMOJIS.FILE} File Viewer — ${filePath.split('/').pop()}`)
    .setDescription(
      `> **Server:** \`${serverName}\` • **Path:** \`${filePath}\`\n\n` +
      `\`\`\`${lang}\n${display}\n\`\`\``
    );
}

// ── BACKUPS ───────────────────────────────────────────────────

function backupList(backups, serverName, page = 0, totalPages = 1, total = null) {
  const t = total ?? backups.length;
  const embed = base(COLORS.PURPLE)
    .setTitle(`${EMOJIS.BACKUP} Backups — ${serverName} (${t} total)`)
    .setDescription('> Manage your server backups below.\n\u200b')
    .setFooter({ text: pageFooter(page, totalPages, t, 'backups') });

  if (backups.length === 0) {
    embed.addFields({ name: 'No Backups', value: '> No backups found. Use `/mcmanager backup create` to create one.', inline: false });
    return embed;
  }

  backups.forEach(b => {
    const attr = b.attributes;
    const date = attr.created_at ? `<t:${Math.floor(new Date(attr.created_at).getTime() / 1000)}:R>` : 'Unknown';
    const status = attr.is_successful ? `${EMOJIS.SUCCESS} Complete` : attr.completed_at ? `${EMOJIS.ERROR} Failed` : `${EMOJIS.LOADING} In Progress`;
    embed.addFields({
      name: `${EMOJIS.BACKUP} ${attr.name || 'Unnamed Backup'}`,
      value: `> **UUID:** \`${attr.uuid.slice(0, 8)}...\`\n> **Size:** \`${FORMAT_BYTES(attr.bytes)}\` • **Status:** ${status}\n> **Created:** ${date} ${attr.is_locked ? '• 🔒 Locked' : ''}`,
      inline: false,
    });
  });

  return embed;
}

// ── DATABASES ─────────────────────────────────────────────────

function databaseList(databases, serverName, page = 0, totalPages = 1, total = null) {
  const t = total ?? databases.length;
  const embed = base(COLORS.GOLD)
    .setTitle(`${EMOJIS.DATABASE} Databases — ${serverName} (${t})`)
    .setDescription('> Manage your MySQL databases below.\n\u200b')
    .setFooter({ text: pageFooter(page, totalPages, t, 'databases') });

  if (databases.length === 0) {
    embed.addFields({ name: 'No Databases', value: '> No databases found. Use `/mcmanager db create` to create one.', inline: false });
    return embed;
  }

  databases.forEach(db => {
    const attr = db.attributes;
    embed.addFields({
      name: `${EMOJIS.DATABASE} ${attr.name}`,
      value: [
        `> **ID:** \`${attr.id}\``,
        `> **Host:** \`${attr.relationships?.host?.attributes?.address}:${attr.relationships?.host?.attributes?.port}\``,
        `> **Database:** \`${attr.name}\` • **Username:** \`${attr.username}\``,
      ].join('\n'),
      inline: false,
    });
  });

  return embed;
}

// ── SCHEDULES ─────────────────────────────────────────────────

function scheduleList(schedules, serverName, page = 0, totalPages = 1, total = null) {
  const t = total ?? schedules.length;
  const embed = base(COLORS.CYAN)
    .setTitle(`${EMOJIS.SCHEDULE} Schedules — ${serverName} (${t})`)
    .setDescription('> Your automated task schedules.\n\u200b')
    .setFooter({ text: pageFooter(page, totalPages, t, 'schedules') });

  if (schedules.length === 0) {
    embed.addFields({ name: 'No Schedules', value: '> No schedules configured yet.', inline: false });
    return embed;
  }

  schedules.forEach(sc => {
    const attr = sc.attributes;
    const nextRun = attr.next_run_at ? `<t:${Math.floor(new Date(attr.next_run_at).getTime() / 1000)}:R>` : 'N/A';
    const status = attr.is_active ? `${EMOJIS.ONLINE} Active` : `${EMOJIS.OFFLINE} Inactive`;
    embed.addFields({
      name: `${EMOJIS.SCHEDULE} ${attr.name || `Schedule #${attr.id}`}`,
      value: `> **Status:** ${status}\n> **Cron:** \`${attr.cron.minute} ${attr.cron.hour} ${attr.cron.day_of_month} ${attr.cron.month} ${attr.cron.day_of_week}\`\n> **Next Run:** ${nextRun}`,
      inline: false,
    });
  });

  return embed;
}

// ── SUBUSERS ──────────────────────────────────────────────────

function subuserList(users, serverName, page = 0, totalPages = 1, total = null) {
  const t = total ?? users.length;
  const embed = base(COLORS.PRIMARY)
    .setTitle(`${EMOJIS.USERS} Subusers — ${serverName} (${t})`)
    .setDescription('> Users with access to this server.\n\u200b')
    .setFooter({ text: pageFooter(page, totalPages, t, 'subusers') });

  if (users.length === 0) {
    embed.addFields({ name: 'No Subusers', value: '> No subusers added yet.', inline: false });
    return embed;
  }

  users.forEach(u => {
    const attr = u.attributes;
    embed.addFields({
      name: `${EMOJIS.USER} ${attr.email}`,
      value: `> **UUID:** \`${attr.uuid.slice(0, 8)}...\`\n> **2FA:** \`${attr['2fa_enabled'] ? 'Enabled' : 'Disabled'}\`\n> **Permissions:** \`${attr.permissions?.length || 0} granted\``,
      inline: false,
    });
  });

  return embed;
}

// ── ALLOCATIONS ───────────────────────────────────────────────

function allocationList(allocations, serverName, page = 0, totalPages = 1, total = null) {
  const t = total ?? allocations.length;
  const embed = base(COLORS.GREEN)
    .setTitle(`${EMOJIS.ALLOCATION} Network Allocations — ${serverName} (${t})`)
    .setDescription('> IP allocations assigned to this server.\n\u200b')
    .setFooter({ text: pageFooter(page, totalPages, t, 'allocations') });

  if (allocations.length === 0) {
    embed.addFields({ name: 'No Allocations', value: '> No allocations found.', inline: false });
    return embed;
  }

  allocations.forEach(a => {
    const attr = a.attributes;
    embed.addFields({
      name: `${attr.is_default ? '⭐' : EMOJIS.ALLOCATION} ${attr.ip}:${attr.port}`,
      value: `> **ID:** \`${attr.id}\`\n> **Alias:** \`${attr.ip_alias || 'None'}\`\n> **Note:** \`${attr.notes || 'None'}\`\n> **Primary:** ${attr.is_default ? '`Yes`' : '`No`'}`,
      inline: false,
    });
  });

  return embed;
}

// ── ADMIN SERVERS ─────────────────────────────────────────────

function adminServerList(servers, page = 0, totalPages = 1, total = null) {
  const t = total ?? servers.length;
  const embed = base(COLORS.RED)
    .setTitle(`${EMOJIS.CROWN} Admin — All Panel Servers (${t})`)
    .setDescription('> **Admin View** — All servers on the panel.\n\u200b')
    .setFooter({ text: pageFooter(page, totalPages, t, 'servers') });

  servers.forEach((s, i) => {
    const attr = s.attributes;
    embed.addFields({
      name: `${EMOJIS.SERVER} ${page * 8 + i + 1}. ${attr.name}`,
      value: `> **ID:** \`${attr.id}\` • **UUID:** \`${attr.identifier}\`\n> **User:** \`${attr.user}\` • **Node:** \`${attr.node}\`\n> **RAM:** \`${FORMAT_BYTES(attr.limits?.memory * 1024 * 1024)}\` • **Disk:** \`${FORMAT_BYTES(attr.limits?.disk * 1024 * 1024)}\``,
      inline: false,
    });
  });

  return embed;
}

function adminUserList(users, page = 0, totalPages = 1, total = null) {
  const t = total ?? users.length;
  const embed = base(COLORS.RED)
    .setTitle(`${EMOJIS.CROWN} Admin — All Panel Users (${t})`)
    .setDescription('> **Admin View** — All users on the panel.\n\u200b')
    .setFooter({ text: pageFooter(page, totalPages, t, 'users') });

  users.forEach((u, i) => {
    const attr = u.attributes;
    embed.addFields({
      name: `${EMOJIS.USER} ${page * 8 + i + 1}. ${attr.username}`,
      value: `> **Email:** \`${attr.email}\`\n> **Admin:** \`${attr.root_admin ? 'Yes 👑' : 'No'}\` • **2FA:** \`${attr['2fa'] ? 'Enabled' : 'Disabled'}\`\n> **Created:** <t:${Math.floor(new Date(attr.created_at).getTime() / 1000)}:R>`,
      inline: false,
    });
  });

  return embed;
}

function adminNodeList(nodes, page = 0, totalPages = 1, total = null) {
  const t = total ?? nodes.length;
  const embed = base(COLORS.ORANGE)
    .setTitle(`${EMOJIS.NETWORK} Admin — All Nodes (${t})`)
    .setDescription('> **Admin View** — All Wings nodes.\n\u200b')
    .setFooter({ text: pageFooter(page, totalPages, t, 'nodes') });

  nodes.forEach((n, i) => {
    const attr = n.attributes;
    embed.addFields({
      name: `🌐 ${page * 8 + i + 1}. ${attr.name}`,
      value: `> **FQDN:** \`${attr.fqdn}\`\n> **RAM:** \`${FORMAT_BYTES(attr.memory * 1024 * 1024)}\` • **Disk:** \`${FORMAT_BYTES(attr.disk * 1024 * 1024)}\`\n> **Location:** \`${attr.location_id}\` • **Servers:** \`${attr.allocated_resources?.server_count || 0}\``,
      inline: false,
    });
  });

  return embed;
}

// ── POWER BUTTONS ─────────────────────────────────────────────

function powerButtons(serverId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`power_start_${serverId}`).setLabel('Start').setEmoji('▶️').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`power_stop_${serverId}`).setLabel('Stop').setEmoji('⏹️').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId(`power_restart_${serverId}`).setLabel('Restart').setEmoji('🔄').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(`power_kill_${serverId}`).setLabel('Kill').setEmoji('💀').setStyle(ButtonStyle.Danger),
  );
}

function serverActionButtons(serverId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`status_${serverId}`).setLabel('Stats').setEmoji('📊').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`files_${serverId}`).setLabel('Files').setEmoji('📁').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`backups_${serverId}`).setLabel('Backups').setEmoji('💾').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`console_${serverId}`).setLabel('Console').setEmoji('💻').setStyle(ButtonStyle.Secondary),
  );
}

// ── SERVER INLINE SWITCHER ────────────────────────────────────

function serverInlineSwitcher(servers, selectedId) {
  const statusEmoji = (s) => {
    const st = s.attributes?.status;
    if (st === 'running') return '🟢';
    if (st === 'offline' || st === 'stopped') return '🔴';
    return '🟡';
  };
  const options = servers.slice(0, 25).map(s => {
    const opt = {
      label: s.attributes.name.slice(0, 100),
      description: `${statusEmoji(s)} ${s.attributes.status || 'unknown'} | ID: ${s.attributes.identifier}`.slice(0, 100),
      value: s.attributes.identifier,
      emoji: '🖥️',
    };
    if (s.attributes.identifier === selectedId) opt.default = true;
    return opt;
  });
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('server_select')
      .setPlaceholder('🔄 Switch to another server...')
      .addOptions(options)
  );
}

function switchServerButton() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('switch_server')
      .setLabel('Switch Server')
      .setEmoji('🔄')
      .setStyle(ButtonStyle.Secondary)
  );
}

// ── HELP ──────────────────────────────────────────────────────

function helpEmbed() {
  return base(COLORS.PTERODACTYL)
    .setTitle(`${EMOJIS.PTERODACTYL} McManager — Help & Commands`)
    .setDescription(
      '> **The ultimate Pterodactyl panel manager for Discord!**\n> Made with ❤️ by **DipuXPro**\n\u200b'
    )
    .addFields(
      {
        name: `${EMOJIS.SETTINGS} ⟦ Setup ⟧`,
        value: '`/mcmanager login` • `/mcmanager logout` • `/mcmanager profile` • `/mcmanager ping`',
        inline: false,
      },
      {
        name: `${EMOJIS.SERVER} ⟦ Servers ⟧`,
        value: '`servers` • `select` • `status` • `stats` • `start` • `stop` • `restart` • `kill`',
        inline: false,
      },
      {
        name: `${EMOJIS.CONSOLE} ⟦ Console ⟧`,
        value: '`console` • `cmd` • `say` • `logs` • `logs-tail`',
        inline: false,
      },
      {
        name: `${EMOJIS.FOLDER} ⟦ Files ⟧`,
        value: '`files` • `read` • `write` • `upload` • `download` • `delete` • `rename` • `mkdir` • `copy` • `move` • `compress` • `decompress`',
        inline: false,
      },
      {
        name: `${EMOJIS.BACKUP} ⟦ Backups ⟧`,
        value: '`backups` • `backup-create` • `backup-delete` • `backup-restore` • `backup-download` • `backup-lock`',
        inline: false,
      },
      {
        name: `${EMOJIS.DATABASE} ⟦ Databases ⟧`,
        value: '`databases` • `db-create` • `db-delete` • `db-password` • `db-info`',
        inline: false,
      },
      {
        name: `${EMOJIS.SCHEDULE} ⟦ Schedules ⟧`,
        value: '`schedules` • `schedule-info` • `schedule-create` • `schedule-delete` • `schedule-toggle` • `schedule-run`',
        inline: false,
      },
      {
        name: `${EMOJIS.USERS} ⟦ Subusers ⟧`,
        value: '`subusers` • `subuser-add` • `subuser-remove` • `subuser-perms` • `subuser-update`',
        inline: false,
      },
      {
        name: `${EMOJIS.CROWN} ⟦ Admin ⟧`,
        value: '`admin-servers` • `admin-users` • `admin-nodes` • `admin-locations` • `admin-nests` • `admin-eggs` and more...',
        inline: false,
      },
      {
        name: `${EMOJIS.FIRE} ⟦ Extended ⟧`,
        value: '`whitelist-add/remove` • `op/deop` • `ban/kick` • `bulk-start/stop/restart` • `panel-status` and more...',
        inline: false,
      },
      {
        name: `${EMOJIS.INFO} Tip`,
        value: '> Run `/mcmanager login` first to connect your panel.\n> All data is stored **privately per user**.',
        inline: false,
      }
    );
}

function changelogEmbed() {
  return base(COLORS.PTERODACTYL)
    .setTitle(`📋 McManager — Changelog`)
    .setDescription([
      '**v1.0.0** — Initial Release',
      '> • 150+ commands across 10 command groups',
      '> • Per-user credential storage (private per Discord user)',
      '> • File manager: list, read, write, upload, download, compress',
      '> • Real-time server stats with progress bars',
      '> • Backup management (create, restore, lock, download)',
      '> • Database management',
      '> • Schedule management',
      '> • Subuser & allocation management',
      '> • Admin Application API commands',
      '> • Bulk power: start/stop/restart all servers',
      '> • Quick MC commands: op, ban, kick, whitelist',
      '> • Graceful no-server handling with picker menu',
      '> • Works on GitHub, VPS, Railway, Replit anywhere',
      '',
      '> Made with ❤️ by **DipuXPro**',
    ].join('\n'));
}

function inviteEmbed(clientId) {
  const id = clientId || 'YOUR_CLIENT_ID';
  const url = `https://discord.com/api/oauth2/authorize?client_id=${id}&permissions=277025770560&scope=bot%20applications.commands`;
  return base(COLORS.PRIMARY)
    .setTitle('🔗 Invite McManager')
    .setDescription(`> Add McManager to your Discord server!\n\n> **[Click here to invite the bot](${url})**\n\n> **Permissions needed:**\n> • Send Messages\n> • Embed Links\n> • Attach Files\n> • Use Slash Commands`);
}

// ── CONSOLE PANEL ────────────────────────────────────────────

function consolePanelEmbed(serverId) {
  return base(COLORS.INFO)
    .setTitle(`${EMOJIS.CONSOLE} Console Panel — \`${serverId}\``)
    .setDescription([
      '> 💻 **Live console access for your server**',
      '',
      `**Server ID:** \`${serverId}\``,
      '',
      '**Available actions:**',
      '> 📤 **Send Command** — Send any server command',
      '> 💬 **Say Message** — Broadcast in-game message',
      '> 📜 **View Logs** — See last console output',
      '',
      '> Use the buttons below to interact with your server console.',
    ].join('\n'));
}

function consolePanelButtons(serverId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`console_cmd_${serverId}`).setLabel('Send Command').setEmoji('📤').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(`console_say_${serverId}`).setLabel('Say Message').setEmoji('💬').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`console_logs_${serverId}`).setLabel('View Logs').setEmoji('📜').setStyle(ButtonStyle.Secondary),
  );
}

// ── TRUST SYSTEM ─────────────────────────────────────────────

function trustListEmbed(trustedUsers, ownerTag) {
  const lines = trustedUsers.length
    ? trustedUsers.map((u, i) => `> \`${i + 1}.\` <@${u.id}> — **${u.tag}**\n>  ⏰ Added: <t:${Math.floor(u.addedAt / 1000)}:R>`)
    : ['> *No users trusted yet.*'];
  return base(COLORS.PTERODACTYL)
    .setTitle('🤝 Trust List')
    .setDescription([
      `> **Owner:** ${ownerTag}`,
      `> **Trusted users:** ${trustedUsers.length}`,
      '',
      '**Trusted Users:**',
      ...lines,
      '',
      '> Trusted users can use all commands with your panel credentials.',
      '> Use `/mcmanager setup trust-add @user` to add someone.',
    ].join('\n'));
}

// ── MC SOFTWARE MENU ─────────────────────────────────────────

function softwareSelectEmbed() {
  return base(COLORS.SUCCESS)
    .setTitle('📦 Minecraft Server Software')
    .setDescription([
      '> Choose your preferred server software from the dropdown below.',
      '> The bot will fetch available versions from official APIs.',
      '',
      '**Available Software:**',
      '> 📄 **Paper** — High performance Spigot fork (recommended)',
      '> 🟣 **Purpur** — Paper fork with extra mob features',
      '> 🔵 **Fabric** — Lightweight modding toolchain',
      '> 🔨 **Forge** — Most popular mod loader',
      '> 🆕 **NeoForge** — Modern Forge fork',
      '> ⚪ **Vanilla** — Official Mojang server',
      '> 🟤 **Quilt** — Community Fabric fork',
      '> 🟡 **Spigot** — CraftBukkit fork',
      '> 🔗 **BungeeCord** — Proxy for multiple servers',
      '> ⚡ **Velocity** — Modern high-performance proxy',
      '> 💧 **Waterfall** — BungeeCord fork',
      '> 🧽 **SpongeVanilla** — Sponge on Vanilla',
    ].join('\n'));
}

function softwareSelectMenu(software) {
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('mc_software')
      .setPlaceholder('📦 Select server software...')
      .addOptions(software.map(s => ({
        label: s.label,
        description: s.desc,
        value: s.id,
      })))
  );
}

function versionSelectEmbed(softwareId) {
  return base(COLORS.SUCCESS)
    .setTitle(`📋 ${softwareId.charAt(0).toUpperCase() + softwareId.slice(1)} — Select Version`)
    .setDescription([
      `> Showing available versions for **${softwareId}**.`,
      '> Select a version from the dropdown to get download info.',
      '',
      '> ℹ️ Versions fetched live from official APIs.',
    ].join('\n'));
}

function versionMenu(softwareId, versions) {
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`mc_version_${softwareId}`)
      .setPlaceholder('🏷️ Select version...')
      .addOptions(versions.slice(0, 25).map(v => ({
        label: String(v).slice(0, 100),
        value: String(v).slice(0, 100),
      })))
  );
}

function versionInfoEmbed(info) {
  const linkLines = info.links.length
    ? info.links.map(l => `> [${l.label}](${l.url})`)
    : ['> No direct download link available. Visit the official site.'];
  const installNote = info.directDownload
    ? '\n> 🚀 Click **Install on Active Server** to auto-upload the JAR.'
    : '';
  return base(COLORS.SUCCESS)
    .setTitle(`📥 ${info.software.charAt(0).toUpperCase() + info.software.slice(1)} ${info.version}`)
    .setDescription([
      `> **Software:** \`${info.software}\``,
      `> **Version:** \`${info.version}\``,
      '',
      '**Download:**',
      ...linkLines,
      '',
      '> ⚠️ Always backup your server before updating!',
      '> Use `/mcmanager backup create` to backup first.' + installNote,
    ].join('\n'));
}

function deleteConfirmEmbed(fp) {
  return base(COLORS.ERROR)
    .setTitle('🗑️ Confirm File Delete')
    .setDescription([
      `> **File:** \`${fp}\``,
      '',
      '> ⚠️ This action **cannot be undone**.',
      '> Click **Yes, Delete** to permanently delete this file.',
      '> Click **Cancel** (or do nothing) to abort.',
    ].join('\n'));
}

// ── ADMIN CREATE EMBEDS ──────────────────────────────────────

function adminCreateUserSuccess(user) {
  return base(COLORS.SUCCESS)
    .setTitle(`${EMOJIS.SUCCESS} Panel User Created`)
    .addFields(
      { name: '👤 Username', value: `\`${user.username}\``, inline: true },
      { name: '📧 Email', value: `\`${user.email}\``, inline: true },
      { name: '🆔 User ID', value: `\`${user.id}\``, inline: true },
      { name: '👑 Admin', value: user.root_admin ? '✅ Yes' : '❌ No', inline: true },
    );
}

function adminCreateServerSuccess(server) {
  return base(COLORS.SUCCESS)
    .setTitle(`${EMOJIS.SUCCESS} Server Created`)
    .addFields(
      { name: '🖥️ Name', value: `\`${server.name}\``, inline: true },
      { name: '🆔 UUID', value: `\`${server.uuid?.slice(0, 8)}...\``, inline: true },
      { name: '🔑 Identifier', value: `\`${server.identifier}\``, inline: true },
    )
    .setDescription('> ✅ Server created successfully! It may take a moment to initialize.');
}

function adminCreateNodeSuccess(node) {
  return base(COLORS.SUCCESS)
    .setTitle(`${EMOJIS.SUCCESS} Node Created`)
    .addFields(
      { name: '🌐 Name', value: `\`${node.name}\``, inline: true },
      { name: '🆔 Node ID', value: `\`${node.id}\``, inline: true },
      { name: '📡 FQDN', value: `\`${node.fqdn}\``, inline: true },
      { name: '💾 Memory', value: `\`${node.memory} MB\``, inline: true },
      { name: '💿 Disk', value: `\`${node.disk} MB\``, inline: true },
    );
}

// ── SFTP DETAILS ─────────────────────────────────────────────

function sftpEmbed(server, panelUrl) {
  const attr = server.attributes;
  const sftp = attr.sftp_details || {};
  const host = sftp.ip || new URL(panelUrl).hostname;
  const port = sftp.port || 2022;
  const username = `${attr.server_owner || '?'}.${attr.identifier}`;
  return base(COLORS.INFO)
    .setTitle(`${EMOJIS.SERVER} SFTP Details — ${attr.name}`)
    .setDescription('> Connect to your server via SFTP to manage files directly.')
    .addFields(
      { name: '🌐 Host', value: `\`${host}\``, inline: true },
      { name: '🔌 Port', value: `\`${port}\``, inline: true },
      { name: '👤 Username', value: `\`${username}\``, inline: false },
      { name: '🔑 Password', value: '`Your panel account password`', inline: false },
      { name: '💡 Quick Connect', value: `\`\`\`sftp ${username}@${host}:${port}\`\`\``, inline: false },
      { name: '📱 Recommended Clients', value: '> **FileZilla**, **WinSCP**, **Cyberduck**, **Termius**', inline: false },
    );
}

// ── ALL STATUS ────────────────────────────────────────────────

function allStatusEmbed(servers, resourcesMap) {
  const STATUS_EMOJI = { running: '🟢', starting: '🟡', stopping: '🟡', offline: '🔴', suspended: '⛔' };
  const lines = servers.map(s => {
    const a = s.attributes;
    const r = resourcesMap[a.identifier];
    const status = r?.current_state || 'offline';
    const emoji = STATUS_EMOJI[status] || '❓';
    const cpu = r?.resources?.cpu_absolute?.toFixed(1) ?? '?';
    const ram = r ? `${(r.resources.memory_bytes / 1024 / 1024).toFixed(0)}MB` : '?';
    return `${emoji} **${a.name.slice(0, 22)}** \`${a.identifier}\` — CPU: \`${cpu}%\` RAM: \`${ram}\``;
  });
  const running = Object.values(resourcesMap).filter(r => r?.current_state === 'running').length;
  return base(COLORS.PTERODACTYL)
    .setTitle(`${EMOJIS.SERVER} All Servers Status`)
    .setDescription(lines.join('\n') || '> No servers found.')
    .setFooter({ text: `🟢 Running: ${running} / ${servers.length} total • ${FOOTER.text}` });
}

// ── SERVER LIMITS ─────────────────────────────────────────────

function serverLimitsEmbed(server) {
  const a = server.attributes;
  const l = a.limits || {};
  const fl = a.feature_limits || {};
  const bar = (used, max) => {
    if (!max) return '`Unlimited`';
    const pct = Math.min(100, Math.round((used / max) * 100));
    const filled = Math.round(pct / 10);
    return `${'█'.repeat(filled)}${'░'.repeat(10 - filled)} \`${pct}%\``;
  };
  return base(COLORS.INFO)
    .setTitle(`⚖️ Resource Limits — ${a.name}`)
    .setDescription(`> **Server:** \`${a.identifier}\`\n> **Status:** ${a.status || 'active'}`)
    .addFields(
      { name: '🧠 Memory', value: l.memory ? `\`${l.memory} MB\`` : '`Unlimited`', inline: true },
      { name: '💾 Disk', value: l.disk ? `\`${l.disk} MB\`` : '`Unlimited`', inline: true },
      { name: '⚡ CPU', value: l.cpu ? `\`${l.cpu}%\`` : '`Unlimited`', inline: true },
      { name: '🔄 Swap', value: `\`${l.swap ?? 0} MB\``, inline: true },
      { name: '📡 Allocations', value: `\`${fl.allocations ?? 0}\``, inline: true },
      { name: '🗄️ Databases', value: `\`${fl.databases ?? 0}\``, inline: true },
      { name: '💾 Backups', value: `\`${fl.backups ?? 0}\``, inline: true },
      { name: '🔒 OOM Killer', value: a.limits?.oom_disabled ? '`Disabled`' : '`Enabled`', inline: true },
      { name: '📦 IO Weight', value: `\`${l.io ?? 500}\``, inline: true },
    );
}

// ── STARTUP VARIABLES ─────────────────────────────────────────

function serverVariablesEmbed(data, serverId) {
  const vars = data.variables || [];
  if (!vars.length) {
    return base(COLORS.INFO)
      .setTitle('🔧 Startup Variables')
      .setDescription(`> No startup variables for \`${serverId}\`.`);
  }
  const lines = vars.map(v => {
    const a = v.attributes;
    const editable = a.rules?.includes('nullable') || !a.rules?.includes('required') ? '📝' : '🔒';
    const current = a.server_value ?? a.default_value ?? '—';
    return `${editable} **${a.name}**\n> Key: \`${a.env_variable}\` → Value: \`${String(current).slice(0, 80)}\``;
  });
  return base(COLORS.INFO)
    .setTitle(`🔧 Startup Variables — \`${serverId}\``)
    .setDescription([
      `> **Startup:** \`${String(data.startup || '').slice(0, 300)}\``,
      '',
      '**Variables:**',
      ...lines.slice(0, 15),
      vars.length > 15 ? `\n> ... and ${vars.length - 15} more` : '',
    ].join('\n'))
    .setFooter({ text: `📝 Editable  🔒 Required • Use /mcmanager server variable-set to change • ${FOOTER.text}` });
}

// ── NODE STATS ────────────────────────────────────────────────

function nodeStatsEmbed(nodes) {
  if (!nodes.length) return base(COLORS.WARNING).setTitle('🌐 Node Stats').setDescription('> No nodes found.');
  const fields = nodes.map(n => {
    const a = n.attributes;
    const memUsedPct = a.allocated_resources?.memory
      ? Math.round((a.allocated_resources.memory / a.memory) * 100)
      : 0;
    const diskUsedPct = a.allocated_resources?.disk
      ? Math.round((a.allocated_resources.disk / a.disk) * 100)
      : 0;
    const memBar = `${'█'.repeat(Math.round(memUsedPct / 10))}${'░'.repeat(10 - Math.round(memUsedPct / 10))}`;
    const diskBar = `${'█'.repeat(Math.round(diskUsedPct / 10))}${'░'.repeat(10 - Math.round(diskUsedPct / 10))}`;
    return {
      name: `🌐 ${a.name} (ID: ${a.id})`,
      value: [
        `> **FQDN:** \`${a.fqdn}\` | **Location:** ${a.location_id}`,
        `> 🧠 RAM: ${memBar} \`${a.allocated_resources?.memory ?? 0}/${a.memory} MB\` (${memUsedPct}%)`,
        `> 💿 Disk: ${diskBar} \`${a.allocated_resources?.disk ?? 0}/${a.disk} MB\` (${diskUsedPct}%)`,
        `> 🔌 Daemon: \`${a.fqdn}:${a.daemon_listen}\` | SFTP: \`${a.daemon_sftp}\``,
        `> ⚡ Status: ${a.maintenance_mode ? '🔴 Maintenance' : '🟢 Online'}`,
      ].join('\n'),
      inline: false,
    };
  });
  return base(COLORS.PTERODACTYL)
    .setTitle('🌐 Node Statistics')
    .setDescription(`> **Total Nodes:** ${nodes.length}`)
    .addFields(...fields.slice(0, 5));
}

// ── FILE SEARCH ───────────────────────────────────────────────

function fileSearchEmbed(query, results, dir, sName) {
  const lines = results.length
    ? results.map(f => {
        const a = f.attributes;
        const emoji = a.is_file ? '📄' : '📂';
        const size = a.is_file && a.size ? `\`${(a.size / 1024).toFixed(1)}KB\`` : '';
        return `${emoji} \`${a.name}\` ${size}`.trim();
      })
    : ['> No files matched your search.'];
  return base(COLORS.INFO)
    .setTitle(`🔍 File Search — "${query}"`)
    .setDescription([
      `> **Server:** ${sName}`,
      `> **Directory:** \`${dir}\``,
      `> **Found:** ${results.length} file(s)`,
      '',
      ...lines.slice(0, 25),
    ].join('\n'));
}

module.exports = {
  success, error, warning, info, loading,
  notLoggedIn, botInfo, pingEmbed,
  loginSuccess, logoutSuccess, profileEmbed,
  serverList, serverSelectMenu, serverSelectMenuPage,
  serverStatus,
  fileList, fileContent,
  backupList,
  databaseList,
  scheduleList,
  subuserList,
  allocationList,
  adminServerList, adminUserList, adminNodeList,
  powerButtons, serverActionButtons,
  helpEmbed, changelogEmbed, inviteEmbed,
  consolePanelEmbed, consolePanelButtons,
  trustListEmbed,
  softwareSelectEmbed, softwareSelectMenu, versionSelectEmbed, versionMenu, versionInfoEmbed, deleteConfirmEmbed,
  adminCreateUserSuccess, adminCreateServerSuccess, adminCreateNodeSuccess,
  sftpEmbed, allStatusEmbed, serverLimitsEmbed, serverVariablesEmbed, nodeStatsEmbed, fileSearchEmbed,
  serverInlineSwitcher, switchServerButton,
};
