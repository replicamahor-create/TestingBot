// ╔══════════════════════════════════════════════════════════╗
// ║         McManager Bot Constants - by DipuXPro            ║
// ╚══════════════════════════════════════════════════════════╝

const COLORS = {
  PRIMARY: 0x5865F2,
  SUCCESS: 0x57F287,
  ERROR: 0xED4245,
  WARNING: 0xFEE75C,
  INFO: 0x5865F2,
  DARK: 0x2B2D31,
  PTERODACTYL: 0x00E5FF,
  GOLD: 0xFFD700,
  ORANGE: 0xFF8C00,
  PURPLE: 0x9B59B6,
  CYAN: 0x00BCD4,
  GREEN: 0x2ECC71,
  RED: 0xE74C3C,
};

const EMOJIS = {
  // Status
  ONLINE: '🟢',
  OFFLINE: '🔴',
  STARTING: '🟡',
  STOPPING: '🟠',
  LOADING: '⏳',
  SUCCESS: '✅',
  ERROR: '❌',
  WARNING: '⚠️',
  INFO: 'ℹ️',

  // Server
  SERVER: '🖥️',
  CPU: '🔲',
  RAM: '💾',
  DISK: '💿',
  NETWORK: '🌐',
  UPTIME: '⏱️',
  POWER: '⚡',
  RESTART: '🔄',
  KILL: '💀',
  STOP: '⏹️',
  START: '▶️',
  STATUS: '📊',

  // Files
  FOLDER: '📁',
  FILE: '📄',
  UPLOAD: '📤',
  DOWNLOAD: '📥',
  DELETE: '🗑️',
  EDIT: '✏️',
  RENAME: '🏷️',
  MKDIR: '📂',

  // Backup
  BACKUP: '💾',
  RESTORE: '🔁',
  ARCHIVE: '🗜️',

  // Database
  DATABASE: '🗄️',
  PASSWORD: '🔐',
  KEY: '🔑',

  // Users
  USER: '👤',
  USERS: '👥',
  ADMIN: '👑',
  LOCK: '🔒',
  UNLOCK: '🔓',

  // Schedule
  SCHEDULE: '📅',
  CLOCK: '🕐',
  TASK: '📋',

  // Network
  IP: '🌍',
  PORT: '🔌',
  ALLOCATION: '📡',

  // Misc
  PTERODACTYL: '🦕',
  BOT: '🤖',
  SETTINGS: '⚙️',
  LINK: '🔗',
  STATS: '📈',
  CHART: '📉',
  ROCKET: '🚀',
  STAR: '⭐',
  FIRE: '🔥',
  DIAMOND: '💎',
  SHIELD: '🛡️',
  SWORD: '⚔️',
  CROWN: '👑',
  LIGHTNING: '⚡',
  PING: '📶',
  LOG: '📜',
  CONSOLE: '💻',
  ARROW: '➤',
  DOT: '•',
  LINE: '─',
  BARS: '▰▰▰',
  MINUS: '▱▱▱',
};

const SERVER_STATUS = {
  running: { emoji: '🟢', label: 'RUNNING', color: COLORS.SUCCESS },
  offline: { emoji: '🔴', label: 'OFFLINE', color: COLORS.ERROR },
  starting: { emoji: '🟡', label: 'STARTING', color: COLORS.WARNING },
  stopping: { emoji: '🟠', label: 'STOPPING', color: COLORS.ORANGE },
  installing: { emoji: '🔵', label: 'INSTALLING', color: COLORS.INFO },
};

const AUTHOR = {
  name: 'McManager • Made by DipuXPro',
  iconURL: 'https://i.imgur.com/wY9QWCF.png',
};

const FOOTER = {
  text: '🦕 McManager by DipuXPro • Pterodactyl Panel Manager',
};

const BOT_VERSION = 'v1.0.0';

const PROGRESS_BAR = (used, total, size = 10) => {
  if (!total || total === 0) return '`[──────────]` 0%';
  const pct = Math.min(Math.round((used / total) * 100), 100);
  const filled = Math.round((pct / 100) * size);
  const empty = size - filled;
  const bar = '█'.repeat(filled) + '░'.repeat(empty);
  return `\`[${bar}]\` **${pct}%**`;
};

const FORMAT_BYTES = (bytes) => {
  if (!bytes || bytes === 0) return '0 MB';
  const mb = bytes / 1024 / 1024;
  if (mb >= 1024) return `${(mb / 1024).toFixed(2)} GB`;
  return `${mb.toFixed(2)} MB`;
};

const FORMAT_UPTIME = (ms) => {
  if (!ms || ms === 0) return 'N/A';
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  if (days > 0) return `${days}d ${hours % 24}h ${minutes % 60}m`;
  if (hours > 0) return `${hours}h ${minutes % 60}m ${seconds % 60}s`;
  if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
  return `${seconds}s`;
};

const TIMESTAMP = () => Math.floor(Date.now() / 1000);

module.exports = {
  COLORS,
  EMOJIS,
  SERVER_STATUS,
  AUTHOR,
  FOOTER,
  BOT_VERSION,
  PROGRESS_BAR,
  FORMAT_BYTES,
  FORMAT_UPTIME,
  TIMESTAMP,
};
